// onload reCAPTCHA v2
var ovacrsRECAPTCHAv2 = function() {
    // Booking
    if ( document.getElementById('ovacrs-booking-recaptcha') ) {
        grecaptcha.render(document.getElementById('ovacrs-booking-recaptcha'), {
            'sitekey' : ovacrsRECAPTCHA.site_key,
            'callback': ovacrsBookingAddToken,
            'expired-callback': ovacrsBookingExpired,
            'error-callback': ovacrsBookingError
        });
    }

    // Request
    if ( document.getElementById('ovacrs-request-recaptcha') ) {
        grecaptcha.render(document.getElementById('ovacrs-request-recaptcha'), {
            'sitekey' : ovacrsRECAPTCHA.site_key,
            'callback': ovacrsRequestAddToken,
            'expired-callback': ovacrsRequestExpired,
            'error-callback': ovacrsRequestError
        });
    }
};
// End

// onload reCAPTCHA v3
var ovacrsRECAPTCHAv3 = function( $ = jQuery ) {
    // Booking
    var bookingTokenInput = $('input[name="ovacrs-booking-recaptcha-token"]');

    // Request
    var requestTokenInput = $('input[name="ovacrs-request-recaptcha-token"]');

    if ( bookingTokenInput.length > 0 || requestTokenInput.length > 0 ) {
        grecaptcha.ready(function() {
            try {
                grecaptcha.execute(ovacrsRECAPTCHA.site_key, {action: 'ovacrsVerifyForm'}).then(function(token) {
                    if ( token ) {
                        if ( bookingTokenInput.length > 0 ) {
                            bookingTokenInput.val( token );
                            bookingTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').hide();
                            bookingTokenInput.closest('form').find('button[type="submit"]').prop('disabled', false);
                        }

                        if ( requestTokenInput.length > 0 ) {
                            requestTokenInput.val( token );
                            requestTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').hide();
                            requestTokenInput.closest('form').find('button[type="submit"]').prop('disabled', false);
                        }
                    } else {
                        // Booking
                        if ( bookingTokenInput.length > 0 ) {
                            bookingTokenInput.val('');
                            bookingTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
                            bookingTokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
                        }

                        // Request
                        if ( requestTokenInput.length > 0 ) {
                            requestTokenInput.val('');
                            requestTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
                            requestTokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
                        }
                    }
                }).catch( function(error) {
                    // Booking
                    if ( bookingTokenInput.length > 0 ) {
                        bookingTokenInput.val('');
                        bookingTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
                        bookingTokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
                    }

                    // Request
                    if ( requestTokenInput.length > 0 ) {
                        requestTokenInput.val('');
                        requestTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
                        requestTokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
                    }

                    console.error('Unexpected error: ', error);
                });
            } catch (error) {
                // Booking
                if ( bookingTokenInput.length > 0 ) {
                    bookingTokenInput.val('');
                    bookingTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
                    bookingTokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
                }

                // Request
                if ( requestTokenInput.length > 0 ) {
                    requestTokenInput.val('');
                    requestTokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
                    requestTokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
                }

                console.error('Unexpected error: ', error);
            }
        });
    }
};
// End

// Booking Add Token
var ovacrsBookingAddToken = function( token, $ = jQuery ) {
    var tokenInput = $('input[name="ovacrs-booking-recaptcha-token"]');

    if ( tokenInput.length > 0 ) {
        if ( token ) {
            tokenInput.val( token );
            tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').hide();
            tokenInput.closest('form').find('button[type="submit"]').prop('disabled', false);
        } else {
            tokenInput.val('');
            tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
            tokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
        }
    }
}

// Booking Expired
var ovacrsBookingExpired = function( $ = jQuery ) {
    var tokenInput = $('input[name="ovacrs-booking-recaptcha-token"]');

    if ( tokenInput.length > 0 ) {
        tokenInput.val('');
        tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.expired).show();
        tokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
    }
}

// Booking Error
var ovacrsBookingError = function( $ = jQuery ) {
    var tokenInput  = $('input[name="ovacrs-booking-recaptcha-token"]');

    if ( tokenInput.length > 0 ) {
        tokenInput.val('');
        tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
        tokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
    }
}

// Request Add Token
var ovacrsRequestAddToken = function( token, $ = jQuery ) {
    var tokenInput = $('input[name="ovacrs-request-recaptcha-token"]');

    if ( tokenInput.length > 0 ) {
        if ( token ) {
            tokenInput.val( token );
            tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').hide();
            tokenInput.closest('form').find('button[type="submit"]').prop('disabled', false);
        } else {
            tokenInput.val('');
            tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
            tokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
        }
    }
}

// Request Expired
var ovacrsRequestExpired = function( $ = jQuery ) {
    var tokenInput = $('input[name="ovacrs-request-recaptcha-token"]');

    if ( tokenInput.length > 0 ) {
        tokenInput.val('');
        tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.expired).show();
        tokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
    }
}

// Request Error
var ovacrsRequestError = function( $ = jQuery ) {
    var tokenInput = $('input[name="ovacrs-request-recaptcha-token"]');

    if ( tokenInput.length > 0 ) {
        tokenInput.val('');
        tokenInput.closest('form').find('.ovacrs-recaptcha-error').html('').append(ovacrsRECAPTCHA.error).show();
        tokenInput.closest('form').find('button[type="submit"]').prop('disabled', true);
    }
}