<table class="wrap_petime_discount">
	<tbody>
		<tr class="tr_petime_discount">
																
			<td width="30%">
			    <input type="text" class="ovacrs_petime_discount_price " placeholder="<?php esc_html_e('Price', 'ova-crs') ?>" 
			    	name="ovacrs_petime_discount[ovacrs_key][price][]" value="" />
			</td>
			<td width="34.5%">
			    <input type="text" class="ovacrs_petime_discount_start_time datetimepicker" placeholder="<?php esc_html_e('Start Time', 'ova-crs') ?>" 
			    	name="ovacrs_petime_discount[ovacrs_key][start_time][]" value="" />
			</td>
			<td width="34.5%">
			    <input type="text" class="ovacrs_petime_discount_end_time datetimepicker" placeholder="<?php esc_html_e('End Time', 'ova-crs') ?>" 
			    	name="ovacrs_petime_discount[ovacrs_key][end_time][]" value="" />
			</td>

			
		<td width="1%"><a href="#" class="button delete_petime_discount">x</a></td>

		</tr> 



	</tbody>
</table>
