<?php $post_id = get_the_ID(); ?>

<div class="options_group show_if_ovacrs_car_rental">

	<!-- Price hour -->
	<?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_regul_price_hour',
			'class' 		=> 'short wc_input_price',
			'label' 		=> __( 'Regular price / Hour', 'ova-crs' ),
			'placeholder' 	=> '',
			'desc_tip'    	=> 'true',
			'description' 	=> __( 'Regular price by hour', 'ova-crs' ),
			'type' 			=> 'text'
	   	));
	?>

	<!-- Price Type -->
	<?php woocommerce_wp_select(
	  	array(
			'id' 			=> 'ovacrs_price_type',
			'label' 		=> __( 'Rental Type', 'ova-crs' ),
			'placeholder' 	=> '',
			'desc_tip'    	=> 'true',
			'description' 	=> __( 'Rent by Hour, Day, or Mixed (Hour and Day)', 'ova-crs' ),
			'options' 		=> array(
					'day'				=> esc_html__( '1: Any Day', 'ova-crs' ),
					'hour'				=> esc_html__( '2: Any Hour', 'ova-crs' ),
					'mixed'				=> esc_html__( '3: Mixed (Any Day and Any Hour)', 'ova-crs' ),
					'period_time'		=> esc_html__( '4: Period of Time ( 05:00 am - 10:00 am, 1 day, 2 days, 1 month, 6 months, 1 year... )', 'ova-crs' ),
					'transportation'	=> esc_html__( '5: Transportation', 'ova-crs' ),
			)
	   	));
	?>
	
	<!-- Unfixed time -->
	<?php woocommerce_wp_select(
	  	array(
			'id' 			=> 'ovacrs_unfixed_time',
			'label' 		=> __( 'Unfixed time', 'ova-crs' ),
			'placeholder' 	=> '',
			'options' 		=> array(
				'no'	=> esc_html__( 'No', 'ova-crs' ),
				'yes'	=> esc_html__( 'Yes', 'ova-crs' ),
			)
	   	));
	?>

	<!-- Total Vehicle -->
	<?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_amount_insurance',
			'class' 		=> 'short',
			'label' 		=> __( 'Amount of insurance', 'ova-crs' ),
			'desc_tip' 		=> 'true',
			'description' 	=> __( 'decimal use dot (.)', 'ova-crs' ),
			'placeholder' 	=> '0',
			'type' 			=> 'text'
	   	));
	?>

	<!-- Enable deposit -->
	<?php woocommerce_wp_select(
	  	array(
			'id' 		=> 'ovacrs_manage_store',
			'label' 	=> __( 'Manage Store', 'ova-crs' ),
			'default' 	=> 'vehicle',
			'options' 	=> array(
				'vehicle'	=> esc_html__( 'Manual', 'ova-crs' ),
				'store'		=> esc_html__( 'Automatic', 'ova-crs' ),
			)
	   	));
	?>

	<!-- Total Vehicle -->
	<?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_car_count',
			'class' 		=> 'short',
			'label' 		=> __( 'Total Vehicles in store', 'ova-crs' ),
			'placeholder' 	=> '0',
			'type' 			=> 'number'
	   	));
	?>

	<!-- Total Vehicle -->
	<?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_stock_quantity',
			'class' 		=> 'short',
			'label' 		=> __( 'Stock Quantity', 'ova-crs' ),
			'placeholder' 	=> '0',
			'type' 			=> 'number'
	   	));
	?>

	<!-- Enable deposit -->
	<?php woocommerce_wp_select(
	  	array(
			'id' 			=> 'ovacrs_enable_deposit',
			'label' 		=> __( 'Enable deposit', 'ova-crs' ),
			'placeholder' 	=> '',
			'options' 		=> array(
				'no'	=> esc_html__( 'No', 'ova-crs' ),
				'yes'	=> esc_html__( 'Yes', 'ova-crs' ),
			)
	   	));
	?>

	<!-- Force deposit -->
	<?php woocommerce_wp_select(
	  	array(
			'id' 			=> 'ovacrs_force_deposit',
			'label' 		=> __( 'Force deposit', 'ova-crs' ),
			'desc_tip' 		=> 'true',
			'description' 	=> __( 'Yes: Allow pay Full Amount, No: Only Deposit', 'ova-crs' ),
			'placeholder' 	=> '',
			'options' 		=> array(
				'no'	=> esc_html__( 'No', 'ova-crs' ),
				'yes'	=> esc_html__( 'Yes', 'ova-crs' ),
			)
	   	));
	?>

	<!-- Type deposit -->
	<?php woocommerce_wp_select(
	  	array(
			'id' 			=> 'ovacrs_type_deposit',
			'label' 		=> __( 'Type deposit', 'ova-crs' ),
			'placeholder' 	=> '',
			'options' 		=> array(
				'percent'	=> esc_html__( 'Percentage of price', 'ova-crs' ),
				'value'		=> esc_html__( 'Fixed value', 'ova-crs' ),
			)
	   	));
	?>
	
	<!-- amount deposit -->
	<?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_amount_deposit',
			'class' 		=> 'short',
			'label'  		=> __( 'Deposit amount', 'ova-crs' ),
			'placeholder' 	=> '',
			'desc_tip' 		=> 'true',
			'description' 	=> __( 'decimal use dot (.)', 'ova-crs' ),
			'type' 			=> 'text'
	   	));
	?>

	<!-- ID Vehicles -->
	<!-- Feature -->
	<div class="ovacrs-form-field ovacrs_id_vehicles_field">
  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_id_vehicle.php' ); ?>
	</div>
	
	<?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_prepare_vehicle',
			'class' 		=> 'short',
			'label' 		=> __( 'Time between 2 leases (Minutes)', 'ova-crs' ),
			'desc_tip'    	=> 'true',
			'description' 	=> __( ' For example: if the car is delivered at 9:00, I set 60 minutes to prepare the car so the car is available again to book at 10:00', 'ova-crs' ),
			'placeholder' 	=> '',
			'type' 			=> 'number'
	   	));
	?>
	
	 <?php woocommerce_wp_text_input(
	  	array(
			'id' 			=> 'ovacrs_car_order',
			'class' 		=> 'short ',
			'label' 		=> __( 'Order at frontend', 'ova-crs' ),
			'placeholder' 	=> '1',
			'desc_tip' 		=> 'true',
			'description' 	=> __( 'Use in some elements', 'ova-crs' ),
			'type' 			=> 'number'
	   	));
	?>
	
	<!-- Video Link -->
	<div class="ovacrs-form-field ">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Video', 'ova-crs'); ?></strong>
		<?php woocommerce_wp_text_input(
			array(
				'id' 			=> 'ovacrs_video_link',
				'class' 		=> 'short ',
				'label' 		=> esc_html__( 'Youtute Link', 'ova-crs' ),
				'placeholder' 	=> esc_html__( 'https://www.youtube.com/watch?v=YTT62UdAILs&t=3s', 'ova-crs' ),
				'description' 	=> esc_html__( 'Insert youtube link like: https://www.youtube.com/watch?v=YTT62UdAILs&t=3s', 'ova-crs' ),
				'desc_tip'    	=> 'true',
				'type' 			=> 'text'
			)); 
		?>
	</div>

	<div class="ovacrs-form-field ovacrs_setup_location">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Setup Locations', 'ova-crs'); ?></strong>
		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_st_locations.php' ); ?>
	</div>

	<div class="ovacrs-form-field ovacrs_local_price_wrap">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Location Fee', 'ova-crs'); ?></strong>
		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_location_price.php' ); ?>
	</div>

	<!-- Price by Period Time -->
	<div class="ovacrs-form-field price_period_time">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Setup Price for Rental Type: Period of time', 'ova-crs'); ?></strong>
		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_period_time.php' ); ?>
	</div>
	
	<!-- Feature -->
	<div class="ovacrs-form-field">
  		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Features', 'ova-crs'); ?></strong>
  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_features.php' ); ?>
	</div>

	<!-- Other Feature -->
	<div class="ovacrs-form-field">
  		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Other Features', 'ova-crs'); ?></strong>
  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_other_features.php' ); ?>
	</div>

	<!-- Global Discount -->
	<div class="ovacrs-form-field price_not_period_time">
  		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Setup price by rent duration (PD)', 'ova-crs'); ?></strong>
  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_global_discount.php' ); ?>
	</div>

	<!-- Price by range time -->
	<div class="ovacrs-form-field price_not_period_time">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Special Time (ST)', 'ova-crs'); ?></strong>
		<span class="ovacrs_right"><?php esc_html_e( 'Note: ST doesnt use PD, it will use PST', 'ova-crs' ); ?></span>
		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_rt.php' ); ?>
	</div>

	<!-- Resources -->
	<div class="ovacrs-form-field">
  		<br/><strong class="ovacrs_heading_section"><?php esc_html_e('Resources', 'ova-crs'); ?></strong>
  		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_resources.php' ); ?>
	</div>

	<!-- unavailable time -->
	<div class="ovacrs-form-field">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e( 'Unavailable Time (UT)', 'ova-crs' ); ?></strong>
		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_untime.php' ); ?>
	</div>

	<!-- Rent min -->
	<div class="ovacrs-form-field">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e( 'Rent Time Min', 'ova-crs' ); ?></strong>
		<?php include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_rent_time_min.php' ); ?>
	</div>	

	<!-- Contact form 7 shortcode -->
	<div class="ovacrs-form-field">
		<br/><strong class="ovacrs_heading_section"><?php esc_html_e( 'Contact form (shortcode)', 'ova-crs' ); ?></strong>
		<?php woocommerce_wp_textarea_input(
		    array(
		        'id' 			=> 'ovacrs_contact_form_shortcode',
		        'placeholder' 	=> 'Contact form',
		        'label' 		=> __('Contact form', 'ova-crs')
		    ));
		?>
	</div>

	<div class="ovacrs-form-field">
		<br/>
		<strong class="ovacrs_heading_section">
			<?php esc_html_e( 'Custom Checkout Field', 'ova-crs' ); ?>
		</strong>

		<?php woocommerce_wp_select(
			array(
				'id' 			=> 'ovacrs_manage_custom_checkout_field',
				'label' 		=> esc_html__( 'Use', 'ova-crs' ),
				'placeholder' 	=> '',
				'options' 		=> array(
					'all'	=> esc_html__( 'All', 'ova-crs' ),
					'new'	=> esc_html__( 'A Part', 'ova-crs' ),
				)
		   	));
		?>
		
		<br/>
		<?php woocommerce_wp_textarea_input(
		    array(
		        'id' 			=> 'ovacrs_product_custom_checkout_field',
		        'placeholder' 	=> esc_html__( '', 'ova-crs' ),
		        'label' 		=> esc_html__('Name Checkout Field', 'ova-crs'),
		        'description' 	=> esc_html__('Insert name in general custom checkout field. Example: ova_email_field, ova_address_field', 'ova-crs'),
			));
		?>
	</div>	
</div>