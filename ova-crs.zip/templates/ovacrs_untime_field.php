<tr class="tr_rt_untime">

    <td width="49%">
      <input type="text" name="ovacrs_untime_startdate[]" value="" placeholder="<?php esc_html_e( 'From YYYY-MM-DD ...', 'ova-crs' ); ?>" class="ovacrs_untime_startdate datetimepicker" autocomplete="off"/>
    </td>

    <td width="49%">
      <input type="text" name="ovacrs_untime_enddate[]" value="" placeholder="<?php esc_html_e( 'End YYYY-MM-DD ...', 'ova-crs' ); ?>" class="ovacrs_untime_enddate datetimepicker" autocomplete="off"/>
    </td>

    <td width="1%"><a href="#" class="button delete_untime">x</a></td>
    
</tr>