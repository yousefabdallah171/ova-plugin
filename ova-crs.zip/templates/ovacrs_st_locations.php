<?php $post_id = get_the_ID(); ?>

<div class="ovacrs_st_locations">
	<table class="widefat">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Pick-up Location', 'ova-crs' ); ?></th>
				<th><?php esc_html_e( 'Drop-off Location', 'ova-crs' ); ?></th>
				<th></th>
			</tr>
		</thead>
		<tbody class="wrap_resources">
			<!-- Append html here -->
			<?php 

			if ( class_exists('OVACRS') && class_exists('woocommerce') ){
			  	$location_arr = ovacrs_get_locations_array();
			} else {
			  	$location_arr = array();
			}

			$ovacrs_pickup_location 	= get_post_meta( $post_id, 'ovacrs_st_pickup_location', 'false' );
			$ovacrs_dropoff_location 	= get_post_meta( $post_id, 'ovacrs_st_dropoff_location', 'false' );

			if ( $ovacrs_pickup_location && ! empty( $location_arr ) ) {
				for( $i = 0 ; $i < count( $ovacrs_pickup_location ); $i++ ) {
			?>
				<tr class="tr_st_local">
				    <td width="49.5%">
				      <select name="ovacrs_st_pickup_location[]" data-number_loc="<?php echo esc_attr( count( $location_arr ) ) ?>" >
				      	<option value=""><?php echo esc_html__( 'Select Location', 'ova-crs' ); ?></option>
							<?php 
							if ( $location_arr ):
								foreach( $location_arr as $location ):
									$selected = ( isset( $ovacrs_pickup_location[$i] ) && $ovacrs_pickup_location[$i] == $location ) ? ' selected' : '';
								?>
								<option value="<?php echo esc_attr( $location ); ?>"<?php echo esc_attr( $selected ); ?>>
									<?php echo esc_html( $location ); ?>
								</option>
							<?php endforeach; endif ?>
					    </select>
				    </td>
				    <td width="49.50%">
				      <select name="ovacrs_st_dropoff_location[]" >
				      		<option value=""><?php echo esc_html__( 'Select Location', 'ova-crs' ); ?></option>
							<?php 
							if ( $location_arr ):
								foreach( $location_arr as $location ):
									$selected = ( isset( $ovacrs_dropoff_location[$i] ) && $ovacrs_dropoff_location[$i] == $location ) ? ' selected' : '';
								?>
								<option value="<?php echo esc_attr( $location ); ?>"<?php echo esc_attr( $selected ); ?>>
									<?php echo esc_html( $location ); ?>
								</option>
							<?php endforeach; endif ?>
					    </select>
				    </td>
				    <td width="1%"><a href="#" class="button delete_st_location">x</a></td>
				</tr>
			<?php } } ?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="6">
					<a href="#" class="button insert_st_location" data-row="
						<?php
							ob_start();
							include( OVACRS_PLUGIN_PATH.'/templates/ovacrs_st_location_field.php' );
							echo esc_attr( ob_get_clean() );
						?>

					">
					<?php esc_html_e( 'Add Location', 'ova-crs' ); ?></a>
					</a>
				</th>
			</tr>
		</tfoot>
	</table>
</div>