<?php

if ( class_exists('OVACRS') && class_exists('woocommerce') ){
    $location_arr = ovacrs_get_locations_array();
} else {
    $location_arr = array();
}

?>
<tr class="tr_st_local">
    <td width="49.5%">
        <select name="ovacrs_st_pickup_location[]">
            <option value=""><?php echo esc_html__( 'Select Location', 'ova-crs' ); ?></option>
        <?php 
        if( $location_arr ): 
            foreach( $location_arr as $location ):
        ?>
            <option value="<?php echo esc_attr( $location ); ?>"><?php echo esc_html( $location ); ?></option>
        <?php endforeach; endif ?>
      </select>
    </td>
    <td width="49.5%">
        <select  name="ovacrs_st_dropoff_location[]" disabled >
            <option value=""><?php echo esc_html__( 'Select Location', 'ova-crs' ); ?></option>
        <?php 
        if( $location_arr ):
            foreach( $location_arr as $location ):
        ?>
            <option value="<?php echo esc_attr( $location ); ?>"><?php echo esc_html( $location ); ?></option>
        <?php endforeach; endif ?>
      </select>
    </td>
    <td width="1%"><a href="#" class="button delete_st_location">x</a></td>
</tr>