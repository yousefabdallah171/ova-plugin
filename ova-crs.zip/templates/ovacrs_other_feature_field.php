<tr class="tr_rt_other_feature">

    <td width="99%">
      <input type="text" name="ovacrs_other_features_name[]" placeholder="<?php esc_html_e( 'Name', 'ova-crs' ); ?>" value="" />
    </td>

    <td width="11%"><a href="#" class="button delete_other_feature">x</a></td>
    
</tr>