<?php if ( ! defined( 'ABSPATH' ) ) exit();

/**
 * Returns every date between two dates as an array
 * @param string $startDate the start of the date range
 * @param string $endDate the end of the date range
 * @param string $format DateTime format, default is Y-m-d
 * @return array returns every date between $startDate and $endDate, formatted as "Y-m-d"
 */
if ( !function_exists( 'ovacrs_createDatefull' ) ) {
    function ovacrs_createDatefull( $start, $end, $format = "Y-m-d" ) {
        $dates = array();

        while ( $start <= $end ) {
            array_push( $dates, date( $format, $start ) );
            $start += 86400;
        }

        return $dates;
    }
}

// Get total between 2 days
if ( !function_exists( 'total_between_2_days' ) ) {
    function total_between_2_days( $start, $end ) {
        return floor( abs( strtotime($end) - strtotime($start) ) / (60*60*24) );
    }
}

// Get array flatten
if ( !function_exists( 'ovacrs_array_flatten' ) ) {
    function ovacrs_array_flatten( $array ) { 
        if ( !is_array( $array ) ) { 
            return false; 
        }

        $result = array(); 

        foreach ( $array as $key => $value ) { 
            if ( is_array( $value ) ) { 
                $result = array_merge( $result, ovacrs_array_flatten( $value ) ); 
            } else { 
              $result[$key] = $value; 
            } 
        }

        return $result; 
    }
}

// Get order rental time
if ( !function_exists( 'get_order_rent_time' ) ) {
    function get_order_rent_time( $product_id, $order_status = array( 'wc-completed' ) ) {
        global $wpdb;

        $order_date = $order_date_bg = $dates_avaiable = $total_each_day = $orders_ids = array();

        $count_car_in_store = get_post_meta( $product_id[0], 'ovacrs_car_count', true );

        // Get order ids
        $orders_ids = ovacrs_get_orders_ids_by_product_id( $product_id, $order_status );

        foreach ( $orders_ids as $key => $value ) {
            // Get Order Detail by Order ID
            $order = wc_get_order($value);

            // Get Meta Data type line_item of Order
            $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
           
            // For Meta Data
            foreach ( $order_line_items as $item_id => $item ) {
                $ovacrs_pickup_date_store   = $ovacrs_pickoff_date_store = '';
                $push_date_unavailable      = array();
                $quantity                   = 1;

                if ( in_array( $item->get_product_id(), $product_id ) ) {
                    // Get value of pickup date, pickoff date
                    $ovacrs_pickup_date_store   = strtotime( $item->get_meta( 'ovacrs_pickup_date' ) );
                    $ovacrs_pickoff_date_store  = strtotime( $item->get_meta( 'ovacrs_pickoff_date' ) );
                    $quantity                   = $item->get_meta( 'ovacrs_quantity' );
                }

                if ( $ovacrs_pickoff_date_store >= current_time( 'timestamp' ) ) {
                    for ( $i = 0; $i < $quantity; $i++ ) {
                        $push_date_unavailable  = push_date_unavailable( $ovacrs_pickup_date_store, $ovacrs_pickoff_date_store, $product_id );
                        $total_each_day         = array_merge_recursive( $total_each_day, $push_date_unavailable['total_each_day'] );
                        $dates_avaiable         = array_merge_recursive( $dates_avaiable, $push_date_unavailable['dates_avaiable'] );
                    }

                }
            }
        }

        // Check Unavaiable Time in Product
        $ovacrs_untime_startdate    = get_post_meta( $product_id[0], 'ovacrs_untime_startdate', true );
        $ovacrs_untime_enddate      = get_post_meta( $product_id[0], 'ovacrs_untime_enddate', true );

        if ( is_array( $ovacrs_untime_startdate ) && !empty( $ovacrs_untime_startdate ) ) {
            foreach ( $ovacrs_untime_startdate as $key => $value ) {
                $push_date_unavailable_untime =  array();
                $push_date_unavailable_untime = push_date_unavailable( strtotime( $ovacrs_untime_startdate[$key] ), strtotime( $ovacrs_untime_enddate[$key]  ), $product_id );

                for ( $i = 0; $i < $count_car_in_store; $i++ ) {
                    $total_each_day = array_merge_recursive( $total_each_day, $push_date_unavailable_untime['total_each_day'] );
                    $dates_avaiable = array_merge_recursive( $dates_avaiable, $push_date_unavailable_untime['dates_avaiable'] ) ;
                }
                
            }
        }

        // Check Unavaiable Time in each Vehicle ID
        $ovacrs_untime_vehicle_id = get_post_meta( $product_id[0], 'ovacrs_id_vehicles', true );

        if ( is_array( $ovacrs_untime_vehicle_id ) ) {
            foreach ( $ovacrs_untime_vehicle_id as $key => $value ) {
                $id_vehicle_untime  = array();
                $vehicle_avai       = ovacrs_get_vehicle_loc_title($value);

                $id_vehicle_untime_startday = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['startdate'] ) : '';
                $id_vehicle_untime_enddate  = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['enddate'] ) : ''; 

                if ( $id_vehicle_untime_startday != '' && $id_vehicle_untime_enddate != '' ) {
                    $id_vehicle_untime = push_date_unavailable( $id_vehicle_untime_startday, $id_vehicle_untime_enddate, $product_id );    
                }
                
                if ( !empty( $id_vehicle_untime ) ) {
                    $total_each_day = array_merge_recursive( $total_each_day, $id_vehicle_untime['total_each_day'] );
                    $dates_avaiable = array_merge_recursive( $dates_avaiable, $id_vehicle_untime['dates_avaiable'] ) ;
                }
            }
        }

        $order_date_bg  = $total_each_day;
        $count_values   = array_count_values( $order_date_bg );
        $bg_rented      = get_theme_mod( 'main_color', '#e9a31b' );

        foreach ( $count_values as $key => $value ) {
            if ( $value >= $count_car_in_store ) {
                $item = array(
                    'start'     => $key,
                    'end'       => $key,
                    'display'   => 'background',
                    'color'     => $bg_rented,
                    'overlap'   => false,
                    'title'     => '',
                );

                array_push( $dates_avaiable, $item );
            }
        }

        return json_encode( $dates_avaiable );
    }
}

// Get dates anavailable
if ( !function_exists( 'push_date_unavailable' ) ) {
    function push_date_unavailable( $ovacrs_pickup_date_store, $ovacrs_pickoff_date_store, $product_id = '' ) {
        $dates_avaiable             = $total_each_day = array();
        $ovacrs_prepare_vehicle     = get_post_meta( $product_id[0], 'ovacrs_prepare_vehicle', true );
        $ovacrs_prepare_vehicle     = (int)$ovacrs_prepare_vehicle * 60;
        $ovacrs_pickoff_date_store  += $ovacrs_prepare_vehicle;
        $start_date                 = date( 'Y-m-d', $ovacrs_pickup_date_store );
        $end_date                   = date( 'Y-m-d', $ovacrs_pickoff_date_store );
        $total_between_2_days       = total_between_2_days( $start_date, $end_date );

        if ( $total_between_2_days == 0 ) { // In a day
            $item = array(
                'start' => date( 'Y-m-d H:i', $ovacrs_pickup_date_store ),
                'end'   => date( 'Y-m-d H:i', $ovacrs_pickoff_date_store ),
                'title' => date_i18n( 'H:i', $ovacrs_pickup_date_store ).'-'.date_i18n( 'H:i', $ovacrs_pickoff_date_store )
            );

            array_push( $dates_avaiable, $item );
            array_push( $total_each_day, date( 'Y-m-d', $ovacrs_pickup_date_store ) );
        } elseif ( $total_between_2_days == 1 ) { // 2 day beside
            $item = array(
                'start' => date( 'Y-m-d H:i', $ovacrs_pickup_date_store ),
                'end'   => date( 'Y-m-d 24:00', $ovacrs_pickup_date_store ),
                'title' => date_i18n( 'H:i', $ovacrs_pickup_date_store ).esc_html__(' 24:00', 'ova-crs')
            );

            array_push( $dates_avaiable, $item );

            $item = array(
                'start' => date( 'Y-m-d 00:00', $ovacrs_pickoff_date_store ),
                'end'   => date( 'Y-m-d H:i', $ovacrs_pickoff_date_store ),
                'title' => esc_html__('00:00 ', 'ova-crs').date_i18n( 'H:i', $ovacrs_pickoff_date_store )
            );

            array_push( $dates_avaiable, $item );
            array_push( $total_each_day, date( 'Y-m-d', $ovacrs_pickup_date_store ) );
            array_push( $total_each_day, date( 'Y-m-d', $ovacrs_pickoff_date_store ) );
        } else { // from 3 days 
            $item = array(
                'start' => date( 'Y-m-d H:i', $ovacrs_pickup_date_store ),
                'end'   => date( 'Y-m-d 24:00', $ovacrs_pickup_date_store ),
                'title' => date_i18n( 'H:i', $ovacrs_pickup_date_store ).esc_html__(' 24:00', 'ova-crs')
            );

            array_push( $dates_avaiable, $item ); 

            $item = array(
                'start' => date( 'Y-m-d 00:00', $ovacrs_pickoff_date_store ),
                'end'   => date( 'Y-m-d H:i', $ovacrs_pickoff_date_store ),
                'title' => esc_html__('00:00 ', 'ova-crs').date_i18n( 'H:i', $ovacrs_pickoff_date_store )
            );

            array_push( $dates_avaiable, $item );
            array_push( $total_each_day, date( 'Y-m-d', $ovacrs_pickup_date_store ) );
            array_push( $total_each_day, date( 'Y-m-d', $ovacrs_pickoff_date_store ) );

            $date_between_start_end = ovacrs_createDatefull( strtotime( $start_date ), strtotime( $end_date ), $format = 'Y-m-d' );

            // Remove first and last array
            array_shift( $date_between_start_end ); 
            array_pop( $date_between_start_end );

            foreach ( $date_between_start_end as $key => $value ) {
                $item = array(
                    'start' => $value,
                    'end'   => $value,
                    'title' => esc_html__( '00:00 24:00 ', 'ova-crs' )
                );

                array_push( $dates_avaiable, $item );
                array_push( $total_each_day, $value  );
            }
        }

        return array(
            'dates_avaiable' => $dates_avaiable,
            'total_each_day' => $total_each_day
        );
    }
}

function ovacrs_get_orders_ids_by_product_id( $product_id, $order_status = array( 'wc-completed' ) ) {
    global $wpdb;
    $order_ids = array();

    if ( empty( $product_id ) ) return $order_ids;

    if ( is_array( $product_id ) ) {
        if ( ovacrs_wc_custom_orders_table_enabled() ) {
            $order_ids = $wpdb->get_col("
                SELECT DISTINCT o.id
                FROM {$wpdb->prefix}wc_orders AS o
                LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                ON o.id = oitems.order_id
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                ON oitems.order_item_id = oitem_meta.order_item_id
                WHERE oitems.order_item_type = 'line_item'
                AND oitem_meta.meta_key = '_product_id'
                AND oitem_meta.meta_value IN ( ".implode( ',', $product_id )." )
                AND o.status IN ( '" . implode( "','", $order_status ) . "' )
            ");
        } else {
            $order_ids = $wpdb->get_col("
                SELECT DISTINCT oitems.order_id
                FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                ON oitems.order_item_id = oitems.order_item_id
                LEFT JOIN {$wpdb->posts} AS posts ON oitems.order_id = posts.ID
                WHERE posts.post_type = 'shop_order'
                AND oitems.order_item_type = 'line_item'
                AND oitem_meta.meta_key = '_product_id'
                AND oitem_meta.meta_value IN ( ".implode( ',', $product_id )." )
                AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
            ");
        }
    } else {
        if ( ovacrs_wc_custom_orders_table_enabled() ) {
            $order_ids = $wpdb->get_col("
                SELECT DISTINCT o.id
                FROM {$wpdb->prefix}wc_orders AS o
                LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                ON o.id = oitems.order_id
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                ON oitems.order_item_id = oitem_meta.order_item_id
                WHERE oitems.order_item_type = 'line_item'
                AND oitem_meta.meta_key = '_product_id'
                AND oitem_meta.meta_value = $product_id
                AND o.status IN ( '" . implode( "','", $order_status ) . "' )
            ");
        } else {
            $order_ids = $wpdb->get_col("
                SELECT DISTINCT oitems.order_id
                FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                ON oitems.order_item_id = oitems.order_item_id
                LEFT JOIN {$wpdb->posts} AS posts ON oitems.order_id = posts.ID
                WHERE posts.post_type = 'shop_order'
                AND oitems.order_item_type = 'line_item'
                AND oitem_meta.meta_key = '_product_id'
                AND oitem_meta.meta_value = $product_id
                AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
            ");
        }  
    }

    return $order_ids;
}


// Search Form
function ovacrs_search_vehicle( $data_search ){
    $pickup_loc             = isset( $data_search['ovacrs_pickup_loc'] ) ? $data_search['ovacrs_pickup_loc']: '';
    $pickoff_loc            = isset( $data_search['ovacrs_pickoff_loc'] ) ? $data_search['ovacrs_pickoff_loc']: '';
    $ovacrs_pickup_date     = isset( $data_search['ovacrs_pickup_date'] )  ? strtotime( $data_search['ovacrs_pickup_date'] ) : '';
    $ovacrs_pickoff_date    = isset( $data_search['ovacrs_pickoff_date'] ) ? strtotime( $data_search['ovacrs_pickoff_date'] ) : '';
    $category               = isset( $data_search['cat'] ) ? $data_search['cat'] : '';
    $product_type           = isset( $data_search['product_type'] ) ? $data_search['product_type'] : '';
    $product_manufacturer   = isset( $data_search['product_manufacturer'] ) ? $data_search['product_manufacturer'] : '';
    $product_steering       = isset( $data_search['product_steering'] ) ? $data_search['product_steering'] : '';
    $product_gearbox        = isset( $data_search['product_gearbox'] ) ? $data_search['product_gearbox'] : '';
    $product_auto_park      = isset( $data_search['product_auto_park'] ) ? $data_search['product_auto_park'] : '';
    $s                      = isset( $data_search['s'] ) ? $data_search['s'] : '';

    $statuses       = ovacrs_order_status();
    $error          = array();
    $items_id       = array();
    $args_keyword   = array();

    if ( $s ) {
        $args_keyword = array(
            's' => $s
        );
    }

    $args_base = array(
        'post_type'         => 'product',
        'posts_per_page'    => '-1',
        'post_status'       => 'publish',
        'fields'            => 'ids',
        'tax_query'         => array(
            array(
                'taxonomy' => 'product_type',
                'field'    => 'slug',
                'terms'    => 'ovacrs_car_rental', 
            ),
        ),
    );

    $arg_cat = ( $category != '' ) ? array(
        'taxonomy'  => 'product_cat',
        'field'     => 'slug',
        'terms'     => $category
    ) : array('');

    $arg_type = ( $product_type != '' ) ? array(
        'taxonomy'  => 'type',
        'field'     => 'slug',
        'terms'     => $product_type
    ) : array('');

    $arg_manufacturer = ( $product_manufacturer != '' ) ? array(
        'taxonomy'  => 'manufacturer',
        'field'     => 'slug',
        'terms'     => $product_manufacturer
    ) : array('');

    $arg_steering = ( $product_steering != '' ) ? array(
        'taxonomy'  => 'steering',
        'field'     => 'slug',
        'terms'     => $product_steering
    ) : array('');

    $arg_gearbox = ( $product_gearbox != '' ) ? array(
        'taxonomy'  => 'gearbox',
        'field'     => 'slug',
        'terms'     => $product_gearbox
    ) : array('');

    $arg_auto_park = ( $product_auto_park != '' ) ? array(
        'taxonomy'  => 'auto_park',
        'field'     => 'slug',
        'terms'     => $product_auto_park
    ) : array('');

    $args_cus_tax = array(
        'tax_query' => array(
            'relation'  => 'AND',
            $arg_cat,
            $arg_type,
            $arg_manufacturer,
            $arg_steering,
            $arg_gearbox,
            $arg_auto_park
        )
    );
    
    $args = array_merge_recursive( $args_base, $args_keyword, $args_cus_tax );

    // Get All products
    $items = get_posts( $args );

    if ( ovacrs_is_array_exists( $items ) ) {
        foreach( $items as $product_id ) {
            if ( ovacrs_check_vehicle_available( $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date, $pickup_loc, $pickoff_loc ) ) {
                array_push( $items_id, $product_id );
            } else {
                if ( ovacrs_check_product_by_location( $product_id, $pickup_loc, $pickoff_loc ) ) {
                    array_push( $items_id, $product_id );
                }
            }
        }
    }

    if ( $items_id ) {

        $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
        
        $rl_search_items_page = get_theme_mod( 'rl_search_items_page', '9' ) ? get_theme_mod( 'rl_search_items_page', '9' ) : 9;

        $args_product = array(
            'post_type' => 'product',
            'posts_per_page' => $rl_search_items_page,
            'paged' => $paged,
            'post_status' => 'publish',
            'post__in' => $items_id,
            'order' => get_theme_mod( 'rl_search_order', 'asc' )
        );

        $search_order_by = get_theme_mod( 'rl_search_order_by', 'price' );


        if( $search_order_by == 'id' ){

            $args_orderby = array( 'orderby' => 'id' );

        }else if( $search_order_by == 'title' ){

            $args_orderby = array( 'orderby' => 'title' );

        } else if ( $search_order_by == 'order' ){

            $args_orderby = array( 'orderby' => 'meta_value_num', 'meta_key' => 'ovacrs_car_order' );

        } else if( $search_order_by == 'total_sales' ){

            $args_orderby = array( 'orderby' => 'meta_value_num', 'meta_key' => 'total_sales' );

        } else if( $search_order_by == 'rating' ){
            $args_orderby = array( 'orderby' => 'meta_value_num', 'meta_key' => '_wc_average_rating' );                                    
        } else if( $search_order_by == 'per_hour' ) {

            $args_orderby = array( 'orderby' => 'meta_value_num', 'meta_key' => 'ovacrs_regul_price_hour' );

        } else {

            $args_orderby = array( 'orderby' => 'meta_value_num', 'meta_key' => '_regular_price' );

        } 

       

        $args_product = array_merge( $args_product, $args_orderby );

        $rental_products = new WP_Query( $args_product );

        return $rental_products;

    }

    return false;


}




// Check Rent by Day or Hour or both
function ovacrs_get_price_type( $post_id ){
    return get_post_meta( $post_id, 'ovacrs_price_type', true ) ;
}

// Get value rent day
function ovacrs_get_price_day( $post_id ){
    return wc_price( get_post_meta( $post_id, '_regular_price', true ) );
}

// Get value hour day
function ovacrs_get_price_hour( $post_id ){
    return wc_price( get_post_meta( $post_id, 'ovacrs_regul_price_hour', true ) );
}



// Get all location
function ovacrs_get_locations(){
    $locations = new WP_Query(
        array(
            'post_type' => 'location',
            'post_status' => 'publish',
            'posts_per_page' => '-1'
        )
    );

    return $locations;

}

function ovacrs_get_locations_array() {
    $args = array(
        'post_type'         => 'location',
        'post_status'       => 'publish',
        'posts_per_page'    => '-1',
        'fields'            => 'ids'
    );

    if ( ovacrs_is_wpml_active() ) {
        $args['suppress_filters'] = false;
    }

    $locations = get_posts( $args );

    $html = array();

    if ( ! empty( $locations ) && is_array( $locations ) ) { 
        foreach ( $locations as $location_id ) {
            $html[trim( get_the_title( $location_id  ) )] = trim( get_the_title( $location_id ) );
        }
    }

    return $html;
}

if( ! function_exists( 'ovacrs_get_price_fee_location_by_pickup_dropoff' ) ) {
    function ovacrs_get_price_fee_location_by_pickup_dropoff( $id_product, $ovacrs_pickup, $ovacrs_dropoff ) {

        $ovacrs_pickup_location = get_post_meta( $id_product, 'ovacrs_pickup_location', 'false' );
        $ovacrs_dropoff_location = get_post_meta( $id_product, 'ovacrs_dropoff_location', 'false' );
        $ovacrs_price_location = get_post_meta( $id_product, 'ovacrs_price_location', 'false' );

        if( ! empty( $ovacrs_pickup_location ) && is_array( $ovacrs_pickup_location ) ) {
            foreach( $ovacrs_pickup_location as $key => $value ) {

                if( $ovacrs_pickup === $value && array_key_exists( $key , $ovacrs_dropoff_location ) &&  $ovacrs_dropoff === $ovacrs_dropoff_location[$key] ) {

                    if( array_key_exists( $key, $ovacrs_price_location ) ) {
                        return (float)$ovacrs_price_location[$key];
                    }
                }
            }
        }
        return 0;

    }
}

function ovacrs_get_list_pickup_dropoff_loc_transport( $id_product ) {
    if( ! $id_product ) return [];

    $list_location = ovacrs_get_locations_array();

    $ovacrs_pickup_location = get_post_meta( $id_product, 'ovacrs_pickup_location', 'false' );
    $ovacrs_dropoff_location = get_post_meta( $id_product, 'ovacrs_dropoff_location', 'false' );

    $list_loc_pickup_dropoff = [];
    if( ! empty( $ovacrs_pickup_location ) ) {
        foreach( $ovacrs_pickup_location as $key => $location ) {
            $list_loc_pickup_dropoff[$location][] = $ovacrs_dropoff_location[$key];
        }
    }
    return $list_loc_pickup_dropoff;
}

function ovacrs_get_locations_transport_html( $name = '', $required = 'required', $selected = '', $id_product = false, $type = 'pickup' ){

    $list_loc_pickup_dropoff = ovacrs_get_list_pickup_dropoff_loc_transport( $id_product );


    $html = '<select name="'.$name.'" class="ovacrs-transport '.$required.'" data-placeholder="'.esc_html__( 'Select Location', 'ova-crs' ).'">';
    $html .= '<option value="">'. esc_html__( 'Select Location', 'ova-crs' ).'</option>';

    if( $type == 'pickup' ) {
        
        if( $list_loc_pickup_dropoff ) {
            foreach( $list_loc_pickup_dropoff as $loc => $item_loc ) {
                $active = ( trim( $loc ) === trim( $selected ) ) ? 'selected="selected"' : '';
                $html .= '<option data-item_loc="'.esc_attr(json_encode($item_loc)).'" value="'.trim( $loc ).'" '.$active.'>'.trim( $loc ).'</option>';
            }
        }
    }
    
    $html .= '</select>';

    return $html;
}

if( ! function_exists( 'ovacrs_check_pickup_dropoff_loc_transport' ) ) {
    function ovacrs_check_pickup_dropoff_loc_transport( $product_id, $pick_loc, $type = 'pickup' ) {
        $list_loc_pickup_dropoff = ovacrs_get_list_pickup_dropoff_loc_transport( $product_id );

        if( empty( $list_loc_pickup_dropoff ) || ! is_array( $list_loc_pickup_dropoff ) ) return false;

        $flag = false;
        if( $type == 'pickup' ) {
            foreach( $list_loc_pickup_dropoff as $pickup_loc => $dropoff_loc ) {
                if( $pick_loc == $pickup_loc ) {
                    $flag = true;
                }
            }
        } else {
            foreach( $list_loc_pickup_dropoff as $pickup_loc => $dropoff_loc ) {
                if( is_array( $dropoff_loc ) && in_array( $pick_loc, $dropoff_loc ) ) {
                    $flag = true;
                }
            }
        }
        return $flag;
    }
}

if( ! function_exists( 'ovacrs_get_time_by_pick_up_off_loc_transport' ) ) {
    function ovacrs_get_time_by_pick_up_off_loc_transport( $product_id, $pickup_loc, $dropoff_loc ){
        if( ! $product_id ) return [];
        
        $list_time_pickup_dropoff_loc = ovacrs_get_list_time_loc_transport( $product_id );

        $time_complete = 0;
        if( $list_time_pickup_dropoff_loc && is_array( $list_time_pickup_dropoff_loc ) ) {
            foreach( $list_time_pickup_dropoff_loc as $pickup => $dropoff_arr ) {
                if( $pickup_loc == $pickup && is_array( $dropoff_arr ) ) {
                    foreach( $dropoff_arr as $dropoff => $time ) {
                        if( $dropoff == $dropoff_loc ) {
                            $time_complete = (float)$time;
                        }
                    }
                } 
            }
        }
        return $time_complete;
    }
}

if( ! function_exists( 'ovacrs_get_list_time_loc_transport' ) ) {
    function ovacrs_get_list_time_loc_transport( $product_id ) {
        if( ! $product_id ) return [];

        $ovacrs_pickup_location = get_post_meta( $product_id, 'ovacrs_pickup_location', 'false' );
        $ovacrs_dropoff_location = get_post_meta( $product_id, 'ovacrs_dropoff_location', 'false' );
        $ovacrs_location_time = get_post_meta( $product_id, 'ovacrs_location_time', 'false' );

        $list_time_pickup_dropoff_loc = [];
        if( ! empty( $ovacrs_pickup_location ) ) {
            foreach( $ovacrs_pickup_location as $key => $location ) {
                $list_time_pickup_dropoff_loc[$location][$ovacrs_dropoff_location[$key]] = $ovacrs_location_time[$key];
            }
        }

        return $list_time_pickup_dropoff_loc;

    }
}


if( ! function_exists( 'ovacrs_get_list_price_loc_transport' ) ) {
    function ovacrs_get_list_price_loc_transport( $product_id ) {
        if( ! $product_id ) return [];

        $ovacrs_pickup_location = get_post_meta( $product_id, 'ovacrs_pickup_location', 'false' );
        $ovacrs_dropoff_location = get_post_meta( $product_id, 'ovacrs_dropoff_location', 'false' );
        $ovacrs_price_location = get_post_meta( $product_id, 'ovacrs_price_location', 'false' );

        $list_price_pickup_dropoff_loc = [];
        if( ! empty( $ovacrs_pickup_location ) ) {
            foreach( $ovacrs_pickup_location as $key => $location ) {
                $list_price_pickup_dropoff_loc[$location][$ovacrs_dropoff_location[$key]] = $ovacrs_price_location[$key];
            }
        }

        return $list_price_pickup_dropoff_loc;

    }
}

function ovacrs_get_locations_slug( $product_id ) {
    // Get location for product
    $location_name = [];
    if ( $product_id ) {
        $slug_vehicles = get_post_meta( $product_id, 'ovacrs_id_vehicles', true );
        if ( $slug_vehicles ) {
            foreach ( $slug_vehicles as $vehicle ) {
                $args_vehicle = [
                    'post_type'   => 'vehicle',
                    'post_status' => 'publish',
                    'numberposts' => 1,
                    'meta_key'    => 'ireca_met_id_vehicle',
                    'meta_value'  => $vehicle,
                ];
                $post_vehicle = get_posts( $args_vehicle );
                if ( $post_vehicle ) {
                    $id_vehicle = $post_vehicle[0]->ID;
                    if ( $id_vehicle ) {
                        $location_slug = get_post_meta( $id_vehicle, 'ireca_met_id_vehicle_location', true );
                        if ( $location_slug && !in_array( $location_slug, $location_name ) ) {
                            array_push( $location_name, $location_slug );
                        }
                    }
                }
            }
        }
    }

    return $location_name;
}

function ovacrs_get_locations_html( $name = '', $required = 'required', $selected = '' , $lable = '', $product_id = false ){
    if ( ! $lable ) $lable = esc_html__( 'Select Location', 'ova-crs' );

    $locations = new WP_Query(
        array(
            'post_type' => 'location',
            'post_status' => 'publish',
            'posts_per_page' => '-1'
        )
    );

    // Check validate location
    $validate_location = get_theme_mod( 'use_loc_filter', true );
    if ( $validate_location === 'false' ) {
        $product_id = false;
    }

    // Get location name for product
    $location_name = array();
    if ( $product_id ) {
        $location_name = ovacrs_get_locations_slug( $product_id );
    }

    $html = '<select name="'.$name.'" class="'.$required.'">
        <option value="">'. esc_html__( $lable, 'ova-crs') .'</option>';

        if( $locations->have_posts() ) : while ( $locations->have_posts() ) : $locations->the_post();
            global $post;
            if ( $product_id ) {
                if ( $location_name && in_array( trim( get_the_title() ), $location_name ) ) {
                    $active = ( trim( get_the_title() ) === trim( $selected ) ) ? 'selected="selected"' : '';
                    $html .= '<option value="'.get_the_title().'" '.$active.'>'.get_the_title().'</option>';
                }
            } else {
                $active = ( trim( get_the_title() ) === trim( $selected ) ) ? 'selected="selected"' : '';
                $html .= '<option value="'.get_the_title().'" '.$active.'>'.get_the_title().'</option>';
            }
        endwhile; endif;wp_reset_postdata();
    $html .= '</select>';

    return $html;
}

// Get ST locations html
if ( ! function_exists( 'ovacrs_get_st_locations_html' ) ) {
    function ovacrs_get_st_locations_html( $name = '', $required = 'required', $selected = '', $product_id = false, $type = 'pickup' ) {
        $html = '<select name="'.$name.'" class="ovacrs-transport '.$required.'" data-placeholder="'.esc_html__( 'Select Location', 'ova-crs').'">
                <option value="">'. esc_html__( 'Select Location', 'ova-crs') .'</option>';

        // Check validate location
        $validate_location = get_theme_mod( 'use_loc_filter', true );

        if ( $validate_location === 'false' ) {
            $html = '<select name="'.$name.'" class="'.$required.'" data-placeholder="'.esc_html__( 'Select Location', 'ova-crs').'">
                <option value="">'. esc_html__( 'Select Location', 'ova-crs') .'</option>';

            $locations = new WP_Query(
                array(
                    'post_type'         => 'location',
                    'post_status'       => 'publish',
                    'posts_per_page'    => '-1'
                )
            );

            if ( $locations->have_posts() ) : while ( $locations->have_posts() ) : $locations->the_post();
                global $post;
                
                $active = ( trim( get_the_title() ) === trim( $selected ) ) ? ' selected="selected"' : '';
                $html .= '<option value="'.get_the_title().'"'.$active.'>'.get_the_title().'</option>';
            endwhile; endif; wp_reset_postdata();
        } else {
            $location_options = ovacrs_get_st_location_options( $product_id, $type );

            if ( ! empty( $location_options ) && is_array( $location_options ) ) {
                foreach( $location_options as $loc => $item_loc ) {
                    $active = ( trim( $loc ) === trim( $selected ) ) ? ' selected="selected"' : '';
                    $html .= '<option data-item_loc="'.esc_attr(json_encode($item_loc)).'" value="'.trim( $loc ).'"'.$active.'>'.trim( $loc ).'</option>';
                }
            }
        }

        $html .= '</select>';

        return $html;
    }
}

// Get ST location options
if ( ! function_exists( 'ovacrs_get_st_location_options' ) ) {
    function ovacrs_get_st_location_options( $product_id = false, $type = 'pickup' ) {
        $locations = array();

        if ( $product_id && $type === 'pickup' ) {
            $rental_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

            if ( $rental_type === 'day' || $rental_type === 'transportation' ) {
                $ovacrs_pickup_location     = get_post_meta( $product_id, 'ovacrs_pickup_location', true );
                $ovacrs_dropoff_location    = get_post_meta( $product_id, 'ovacrs_dropoff_location', true );

                if ( ! empty( $ovacrs_pickup_location ) ) {
                    foreach( $ovacrs_pickup_location as $key => $location ) {
                        $locations[$location][] = $ovacrs_dropoff_location[$key];
                    }
                }
            } else {
                $ovacrs_st_pickup_location  = get_post_meta( $product_id, 'ovacrs_st_pickup_location', true );
                $ovacrs_st_dropoff_location = get_post_meta( $product_id, 'ovacrs_st_dropoff_location', true );

                if ( ! empty( $ovacrs_st_pickup_location ) ) {
                    foreach( $ovacrs_st_pickup_location as $key => $location ) {
                        $locations[$location][] = $ovacrs_st_dropoff_location[$key];
                    }
                }
            }
        }

        return $locations;
    }
}

// Get all number plate
function ovacrs_get_all_id_vehicles(){
    $vehicle = new WP_Query(
        array(
            'post_type' => 'vehicle',
            'post_status' => 'publish',
            'posts_per_page' => '-1'
        )
    );

    return $vehicle;

}

function ovacrs_get_vehicle_loc_title( $id_metabox ){
    $vehicle_arr = array();
    $vehicle = new WP_Query(
        array(
            'post_type' => 'vehicle',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_query' => array(
                array(
                    'key'     => 'ireca_met_id_vehicle',
                    'value'   => $id_metabox,
                    'compare' => '=',
                ),
            ),
        )
    );
    if($vehicle->have_posts() ) : while ( $vehicle->have_posts() ) : $vehicle->the_post();
        $vehicle_arr['loc'] = get_post_meta( get_the_id(), 'ireca_met_id_vehicle_location', true );
        $vehicle_arr['untime'] = get_post_meta( get_the_id(), 'ireca_met_id_vehicle_untime_from_day', true );
        $vehicle_arr['id_vehicle'] = get_post_meta( get_the_id(), 'ireca_met_id_vehicle', true );
        $vehicle_arr['title'] = get_the_title();
    endwhile;endif;wp_reset_postdata();
    return $vehicle_arr;
}


/* Request for booking */
if ( !function_exists( 'ovacrs_request_booking' ) ) {
    function ovacrs_request_booking( $data ) {
        // Verify reCAPTCHA
        if ( ovacrs_recaptcha_enabled( 'request' ) ) {
            $recaptcha_token = isset( $data['ovacrs-request-recaptcha-token'] ) ? $data['ovacrs-request-recaptcha-token'] : '';

            if ( ovacrs_verify_recaptcha_token( $recaptcha_token ) ) {
                return false;
            }
        }
        // End

        // Date format
        $dateformat = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );

        // Time format
        $timeformat = get_theme_mod( 'rd_bf_timeformat', 'H:i' );

        // Subject
        $subject            = esc_html__( "Request For Booking", 'ova-crs' );
        $body               = '';
        $product_name       = isset( $data['product_name'] ) ? $data['product_name'] : '';
        $product_id         = isset( $data['product_id'] ) ? $data['product_id'] : '';
        $rental_type        = get_post_meta( $product_id, 'ovacrs_price_type', true );
        $name               = isset( $data['name'] ) ? $data['name'] : '';
        $email              = isset( $data['email'] ) ? $data['email'] : '';
        $number             = isset( $data['number'] ) ? $data['number'] : '';
        $address            = isset( $data['number'] ) ? $data['address'] : '';
        $pickup_location    = isset( $data['ovacrs_pickup_loc'] ) ? $data['ovacrs_pickup_loc'] : '';
        $pickoff_location   = isset( $data['ovacrs_pickoff_loc'] ) ? $data['ovacrs_pickoff_loc'] : '';
        $pickup_date        = isset( $data['pickup_date'] ) ? $data['pickup_date'] : '';
        $pickoff_date       = isset( $data['pickoff_date'] ) ? $data['pickoff_date'] : '';
        $extra              = isset( $data['extra'] ) ? $data['extra'] : '';

        // Resources
        $ovacrs_resource_checkboxs = isset( $data['ovacrs_resource_checkboxs'] ) ? $data['ovacrs_resource_checkboxs'] : '';
        
        // Package id
        $package_id     = isset( $data['ovacrs_period_package_id'] ) ? $data['ovacrs_period_package_id'] : '';
        $package_name   = '';

        // Quantity
        $ovacrs_quantity = isset( $data['ovacrs_quantity'] ) ? $data['ovacrs_quantity'] : 1;

        // Rental type: Transportation
        if ( 'transportation' === $rental_type ) {
            $time_dropoff = ovacrs_get_time_by_pick_up_off_loc_transport( $product_id, $pickup_location, $pickoff_location );

            // Get Second
            $time_dropoff_seconds   = 60 * $time_dropoff;
            $dropoff_date_timestamp =  strtotime( $pickup_date ) + $time_dropoff_seconds;
            $pickoff_date           = date( $dateformat . ' ' . $timeformat, $dropoff_date_timestamp );
        }

        // Rental type: Period Time
        if ( 'period_time' === $rental_type ) {
            $ovacrs_unfixed = get_post_meta( $product_id, 'ovacrs_unfixed_time', true );
            $date_format    = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );
            $time_format    = get_theme_mod( 'rd_bf_timeformat', 'H:i' );

            // Get rental period info
            $rental_info_period = get_rental_info_period( $product_id, $pickup_date, $rental_type, $package_id );

            if ( 'inday' === $rental_info_period['package_type'] || 'yes' === $ovacrs_unfixed ) {
                $date_time_format_start  = $date_format.' '.$time_format;    
                $date_time_format_endate = $date_format.' '.$time_format;
            } else {
                $date_time_format_start  = $date_format.' '.apply_filters( 'ovarcs_package_start_time' ,'00:00' );
                $date_time_format_endate = $date_format.' '.apply_filters( 'ovarcs_package_end_time' ,'23:59' );
            }

            $pickup_date    = $rental_info_period['start_time'] ? date( $date_time_format_start, $rental_info_period['start_time'] ) : '';
            $pickoff_date   = $rental_info_period['end_time'] ? date( $date_time_format_endate, $rental_info_period['end_time'] ) : '';
            $package_name   = $rental_info_period['period_label'];
        }

        // Product
        $body .= $product_id ? esc_html__( 'Product: ', 'ova-crs' ).'<a href="'.get_permalink( $product_id ).'">'.$product_name.'</a><br/>' : '';

        // Package name
        $body .= $package_name ? esc_html__( 'Package: ', 'ova-crs' ).$package_name.'<br/>' : '';

        // Customer name
        $body .= $name ? esc_html__( 'Name: ', 'ova-crs' ).$name.'<br/>' : '';

        // Customer email
        $body .= $email ? esc_html__( 'Email: ', 'ova-crs' ).$email.'<br/>' : '';

        // Customer phone
        if ( get_theme_mod( 'rd_rbf_show_number', 'true' ) == 'true' ) {
            $body .= $number ? esc_html__( 'Phone: ', 'ova-crs' ).$number.'<br/>' : '';
        }

        // Customer address
        if ( get_theme_mod( 'rd_rbf_show_address', 'true' ) == 'true' ) {
            $body .= $address ? esc_html__( 'Address: ', 'ova-crs' ).$address.'<br/>' : '';
        }

        // Pick-up location
        if ( 'true' == get_theme_mod( 'rd_rbf_show_pickup_loc', 'true' ) ) {
            $body .= $pickup_location ? esc_html__( 'Pick-up Location: ', 'ova-crs' ).$pickup_location.'<br/>' : '';
        }

        // Drop-off location
        if ( 'true' === get_theme_mod( 'rd_rbf_show_pickoff_loc', 'true' ) ) {
            $body .= $pickoff_location ? esc_html__( 'Drop-off Location: ', 'ova-crs' ).$pickoff_location.'<br/>' : '';
        }

        // Pick-up date
        $body .= $pickup_date ? esc_html__( 'Pick-up Date: ', 'ova-crs' ).$pickup_date.'<br/>' : '';

        // Drop-off date
        $body .= $pickoff_date ? esc_html__( 'Drop-off Date: ', 'ova-crs' ).$pickoff_date.'<br/>' : '';

        // Quantity
        if ( 'true' == get_theme_mod( 'rd_rbf_show_quantity', 'true' ) ) { 
            $body .= $ovacrs_quantity ? esc_html__( 'Quantity: ', 'ova-crs' ).$ovacrs_quantity.'<br/>' : '';
        }

        // Custom Checkout Fields
        $list_ckf = ovacrs_get_list_field_checkout( $product_id );

        if ( !empty( $list_ckf ) && is_array( $list_ckf ) ) {
            foreach ( $list_ckf as $k => $field ) {
                $label = isset( $field['label'] ) ? $field['label'] : '';
                $value = isset( $data[$k] ) ? $data[$k] : '';

                if ( $label && $value ) {
                    $body .= $label.': ';
                    $body .= $value.'<br/>';
                }
            }
        }
        
        // Resources
        if ( 'true' == get_theme_mod( 'rd_rbf_show_extra_source', 'true' ) && $ovacrs_resource_checkboxs ) {

            if ( 1 === count( $ovacrs_resource_checkboxs ) ) {
                $body .= esc_html__( 'Resource: ', 'ova-crs' ).implode( ', ', $ovacrs_resource_checkboxs ).'<br/>';
            } else {
                $body .= esc_html__( 'Resources: ', 'ova-crs' ).implode( ', ', $ovacrs_resource_checkboxs ).'<br/>';
            }
        }
        
        // Services
        if ( 'true' == get_theme_mod( 'rd_rbf_show_extra_info', 'true' ) ) {
            $body .= $extra ? esc_html__( 'Extra: ', 'ova-crs' ).$extra.'<br/>' : '';
        }

        $email_to   = get_theme_mod( 'use_email_send_to', false );
        $mail_to    = array( $data['email'] );

        if ( $email_to ) {
            $email_to   = explode( ',', $email_to );
            $mail_to    = array_merge( $mail_to, $email_to );
        } else {
            array_push( $mail_to, get_option('admin_email') );
        }

        // Remove duplicate email
        $mail_to    = array_unique( $mail_to );
        $mail_to    = apply_filters( 'ovacrs_mail_to_request_booking', $mail_to, $data );
        $subject    = apply_filters( 'ovacrs_subject_request_booking', $subject, $data );
        $body       = apply_filters( 'ovacrs_body_request_booking', $body, $data );

        return ovacrs_ovacrs_sendmail( $mail_to, $subject, $body );
    }
}

function ova_wp_mail_from(){
    return get_theme_mod( 'use_email_sender_filter', false ) ? get_theme_mod( 'use_email_sender_filter', false ) : get_option('admin_email');
}

function ova_wp_mail_from_name() {
    return esc_html__( "Request For Booking", 'ova-crs' );
}

function ovacrs_ovacrs_sendmail( $mail_to, $subject, $body ){

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=".get_bloginfo( 'charset' )."\r\n";
    
    add_filter( 'wp_mail_from', 'ova_wp_mail_from' );
    add_filter( 'wp_mail_from_name', 'ova_wp_mail_from_name' );


    if( wp_mail($mail_to, $subject, $body, $headers ) ){
        $result = true;
    }else{
        $result = false;
    }

    remove_filter( 'wp_mail_from', 'ova_wp_mail_from');
    remove_filter( 'wp_mail_from_name', 'ova_wp_mail_from_name' );

    return $result;
}



/* Select html Category Rental */
function ovacrs_cat_rental( $selected, $required, $exclude_id ){
    $args = array(
        'show_option_all'    => '',
        'show_option_none'   => esc_html__( 'All Categories', 'ova-crs' ),
        'option_none_value'  => '',
        'orderby'            => 'ID',
        'order'              => 'ASC',
        'show_count'         => 0,
        'hide_empty'         => 0,
        'child_of'           => 0,
        'exclude'            => $exclude_id,
        'include'            => '',
        'echo'               => 0,
        'selected'           => $selected,
        'hierarchical'       => 1,
        'name'               => 'cat',
        'id'                 => '',
        'class'              => 'postform '.$required,
        'depth'              => 0,
        'tab_index'          => 0,
        'taxonomy'           => 'product_cat',
        'hide_if_empty'      => false,
        'value_field'        => 'slug',
    );
   
   return wp_dropdown_categories($args);
}


function ovacrs_type_rental( $selected, $required, $exclude_id ){
    $args = array(
        'show_option_all'    => '',
        'show_option_none'   => esc_html__( 'All Type', 'ova-crs' ),
        'option_none_value'  => '',
        'orderby'            => 'ID',
        'order'              => 'ASC',
        'show_count'         => 0,
        'hide_empty'         => 0,
        'child_of'           => 0,
        'exclude'            => $exclude_id,
        'include'            => '',
        'echo'               => 0,
        'selected'           => $selected,
        'hierarchical'       => 1,
        'name'               => 'product_type',
        'id'                 => '',
        'class'              => 'postform '.$required,
        'depth'              => 0,
        'tab_index'          => 0,
        'taxonomy'           => 'type',
        'hide_if_empty'      => false,
        'value_field'        => 'slug',
    );
   
   return wp_dropdown_categories($args);
}

function ovacrs_manufacturer_rental( $selected, $required, $exclude_id ){
    $args = array(
        'show_option_all'    => '',
        'show_option_none'   => esc_html__( 'All Manufacturer', 'ova-crs' ),
        'option_none_value'  => '',
        'orderby'            => 'ID',
        'order'              => 'ASC',
        'show_count'         => 0,
        'hide_empty'         => 0,
        'child_of'           => 0,
        'exclude'            => $exclude_id,
        'include'            => '',
        'echo'               => 0,
        'selected'           => $selected,
        'hierarchical'       => 1,
        'name'               => 'product_manufacturer',
        'id'                 => '',
        'class'              => 'postform '.$required,
        'depth'              => 0,
        'tab_index'          => 0,
        'taxonomy'           => 'manufacturer',
        'hide_if_empty'      => false,
        'value_field'        => 'slug',
    );
   
   return wp_dropdown_categories($args);
}

function ovacrs_steering_rental( $selected, $required, $exclude_id ){
    $args = array(
        'show_option_all'    => '',
        'show_option_none'   => esc_html__( 'All Steering', 'ova-crs' ),
        'option_none_value'  => '',
        'orderby'            => 'ID',
        'order'              => 'ASC',
        'show_count'         => 0,
        'hide_empty'         => 0,
        'child_of'           => 0,
        'exclude'            => $exclude_id,
        'include'            => '',
        'echo'               => 0,
        'selected'           => $selected,
        'hierarchical'       => 1,
        'name'               => 'product_steering',
        'id'                 => '',
        'class'              => 'postform '.$required,
        'depth'              => 0,
        'tab_index'          => 0,
        'taxonomy'           => 'steering',
        'hide_if_empty'      => false,
        'value_field'        => 'slug',
    );
   
   return wp_dropdown_categories($args);
}

function ovacrs_gearbox_rental( $selected, $required, $exclude_id ){
    $args = array(
        'show_option_all'    => '',
        'show_option_none'   => esc_html__( 'All Gearbox', 'ova-crs' ),
        'option_none_value'  => '',
        'orderby'            => 'ID',
        'order'              => 'ASC',
        'show_count'         => 0,
        'hide_empty'         => 0,
        'child_of'           => 0,
        'exclude'            => $exclude_id,
        'include'            => '',
        'echo'               => 0,
        'selected'           => $selected,
        'hierarchical'       => 1,
        'name'               => 'product_gearbox',
        'id'                 => '',
        'class'              => 'postform '.$required,
        'depth'              => 0,
        'tab_index'          => 0,
        'taxonomy'           => 'gearbox',
        'hide_if_empty'      => false,
        'value_field'        => 'slug',
    );
   
   return wp_dropdown_categories($args);
}

function ovacrs_auto_park_rental( $selected, $required, $exclude_id ){
    $args = array(
        'show_option_all'    => '',
        'show_option_none'   => esc_html__( 'All Auto Park', 'ova-crs' ),
        'option_none_value'  => '',
        'orderby'            => 'ID',
        'order'              => 'ASC',
        'show_count'         => 0,
        'hide_empty'         => 0,
        'child_of'           => 0,
        'exclude'            => $exclude_id,
        'include'            => '',
        'echo'               => 0,
        'selected'           => $selected,
        'hierarchical'       => 1,
        'name'               => 'product_auto_park',
        'id'                 => '',
        'class'              => 'postform '.$required,
        'depth'              => 0,
        'tab_index'          => 0,
        'taxonomy'           => 'auto_park',
        'hide_if_empty'      => false,
        'value_field'        => 'slug',
    );
   
   return wp_dropdown_categories($args);
}





function ovacrs_pagination_theme($ovacrs_query = null) {
    

    

    /** Stop execution if there's only 1 page */
    if($ovacrs_query != null){
        if( $ovacrs_query->max_num_pages <= 1 )
        return; 
    }else if( $wp_query->max_num_pages <= 1 )
        return;



    $paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;


    

    if($ovacrs_query!=null){
        $max   = intval( $ovacrs_query->max_num_pages );
    }else{
        $max   = intval( $wp_query->max_num_pages );    
    }
    

    /** Add current page to the array */
    if ( $paged >= 1 )
        $links[] = $paged;

    /** Add the pages around the current page to the array */
    if ( $paged >= 3 ) {
        $links[] = $paged - 1;
        $links[] = $paged - 2;
    }

    if ( ( $paged + 2 ) <= $max ) {
        $links[] = $paged + 2;
        $links[] = $paged + 1;
    }


    echo '<nav class="woocommerce-pagination"><ul class="page-numbers">' . "\n";

    /** Previous Post Link */
    if ( get_previous_posts_link() )
        printf( '<li class="prev page-numbers">%s</li>' . "\n", get_previous_posts_link('<i class="arrow_carrot-left"></i>') );

    /** Link to first page, plus ellipses if necessary */
    if ( ! in_array( 1, $links ) ) {
        $class = 1 == $paged ? ' class="current"' : 'page-numbers';

        printf( '<li><a href="%s" %s>%s</a></li>' . "\n",  esc_url( get_pagenum_link( 1 ) ), $class, '1' );

        if ( ! in_array( 2, $links ) )
            echo '<li>...</li>';
    }

    /** Link to current page, plus 2 pages in either direction if necessary */
    sort( $links );
    foreach ( (array) $links as $link ) {
        $class = $paged == $link ? ' class="current"' : '';
        printf( '<li><a href="%s" %s>%s</a></li>' . "\n",  esc_url( get_pagenum_link( $link ) ), $class, $link );
    }

    /** Link to last page, plus ellipses if necessary */
    if ( ! in_array( $max, $links ) ) {
        if ( ! in_array( $max - 1, $links ) )
            echo '<li>...</li>' . "\n";

        $class = $paged == $max ? ' class="current"' : '';
        printf( '<li><a href="%s" %s>%s</a></li>' . "\n",  esc_url( get_pagenum_link( $max ) ), $class, $max );
    }

    /** Next Post Link */
    if ( get_next_posts_link() )
        printf( '<li class="next page-numbers">%s</li>' . "\n", get_next_posts_link('<i class="arrow_carrot-right"></i>') );

    echo '</ul></nav>' . "\n";

}

// Return start time, end time when retal is period hour or time
function get_rental_info_period( $car_id, $start_date, $ovacrs_rental_type, $ovacrs_period_package_id ){

    $rental_start_time = $rental_end_time = 0;
    $period_label = '';
    $period_price = 0;
    if ( !( is_numeric($start_date) && (int)$start_date == $start_date ) ) {
        $start_date_totime = strtotime($start_date);
    } else {
        $start_date_totime = $start_date;
    }


    if( trim( $ovacrs_rental_type ) == trim( 'period_time' ) ){

        $ovacrs_petime_id       = get_post_meta( $car_id, 'ovacrs_petime_id', true );
        $ovacrs_petime_price    = get_post_meta( $car_id, 'ovacrs_petime_price', true );
        $ovacrs_petime_days     = get_post_meta( $car_id, 'ovacrs_petime_days', true );
        $ovacrs_petime_label    = get_post_meta( $car_id, 'ovacrs_petime_label', true );
        $ovacrs_petime_discount = get_post_meta( $car_id, 'ovacrs_petime_discount', true );
        $ovacrs_package_type    = get_post_meta( $car_id, 'ovacrs_package_type', true );

        $ovacrs_unfixed = get_post_meta( $car_id, 'ovacrs_unfixed_time', true );

        $ovacrs_pehour_start_time   = get_post_meta( $car_id, 'ovacrs_pehour_start_time', true );
        $ovacrs_pehour_end_time     = get_post_meta( $car_id, 'ovacrs_pehour_end_time', true );

        $ovacrs_pehour_unfixed     = get_post_meta( $car_id, 'ovacrs_pehour_unfixed', true );
        
        $package_type = '';


        if( $ovacrs_petime_id ){ 
            foreach ( $ovacrs_petime_id as $key => $value ) {

                if( $ovacrs_petime_id[$key] ==  $ovacrs_period_package_id ){
  
                    // Check pakage type
                    if( $ovacrs_package_type[$key] == 'inday' ){

                        $rental_start_time = isset( $ovacrs_pehour_start_time[$key] ) ? strtotime( $start_date.' '.$ovacrs_pehour_start_time[$key] ) : 0;
                        $rental_end_time = isset( $ovacrs_pehour_end_time[$key] ) ? strtotime( $start_date.' '.$ovacrs_pehour_end_time[$key] ) : 0;

                        if( $ovacrs_unfixed == 'yes' ) {
                            $retal_pehour_unfixed = isset( $ovacrs_pehour_unfixed[$key] ) ? (float)$ovacrs_pehour_unfixed[$key] : 0;

                            $rental_start_time = $start_date_totime;
                            $rental_end_time = $start_date_totime + $retal_pehour_unfixed * 3600;
                        }
                       
                        $period_label = isset( $ovacrs_petime_label[$key] ) ? $ovacrs_petime_label[$key] : '';
                        $period_price = isset( $ovacrs_petime_price[$key] ) ? floatval( $ovacrs_petime_price[$key] ) : 0;
                        $package_type = 'inday';

                        if( isset($ovacrs_petime_discount[$key]) && $ovacrs_petime_discount[$key]['price'] ){
                            foreach ( $ovacrs_petime_discount[$key]['price'] as $k => $v) {
                                // Start Time Discount < Rental Time < End Time Discount
                                
                                $start_time_dis = strtotime( $ovacrs_petime_discount[$key]['start_time'][$k] );
                                $end_time_dis = strtotime( $ovacrs_petime_discount[$key]['end_time'][$k] );

                                if( $start_time_dis <= $start_date_totime && $start_date_totime <= $end_time_dis ){
                                    $period_price = floatval( $ovacrs_petime_discount[$key]['price'][$k] );
                                    break;
                                }
                            }    
                        }

                    }else if( $ovacrs_package_type[$key] == 'other' ){
                        if ( $ovacrs_unfixed == 'yes' ) {
                            $rental_start_time  = $start_date_totime;
                            $rental_end_time    = date( 'Y-m-d H:i', $start_date_totime + intval( $ovacrs_petime_days[$key] ) * 86400 );
                        } else {
                            $start_date_date = date( 'Y-m-d', $start_date_totime ) .' '.apply_filters( 'ovarcs_package_start_time' ,'00:00' );
                            $start_date_totime = strtotime( $start_date_date );

                            $rental_start_time = $start_date_totime;

                            $rental_end_time = date( 'Y-m-d', $start_date_totime + intval( $ovacrs_petime_days[$key] )*24*60*60 - 24*60*60 ) .' '.apply_filters( 'ovarcs_package_end_time' ,'23:59' );
                        }

                        $rental_end_time = strtotime( $rental_end_time );
                        $period_label = isset( $ovacrs_petime_label[$key] ) ? $ovacrs_petime_label[$key] : '';
                        $period_price = isset( $ovacrs_petime_price[$key] ) ? floatval( $ovacrs_petime_price[$key] ) : 0;
                        $package_type = 'other';

                        if( isset($ovacrs_petime_discount[$key]) && $ovacrs_petime_discount[$key]['price'] ){
                            foreach ( $ovacrs_petime_discount[$key]['price'] as $k => $v) {
                                // Start Time Discount < Rental Time < End Time Discount
                                
                                $start_time_dis = strtotime( $ovacrs_petime_discount[$key]['start_time'][$k] );
                                $end_time_dis = strtotime( $ovacrs_petime_discount[$key]['end_time'][$k] );

                                if( $start_time_dis <= $start_date_totime && $start_date_totime <= $end_time_dis ){
                                    $period_price = floatval( $ovacrs_petime_discount[$key]['price'][$k] );
                                    break;
                                }
                            }    
                        }

                    }

                    
                    

                    break;
                }
            }
        }

    }


    return array( 'start_time' => $rental_start_time, 'end_time' => $rental_end_time, 'period_label' => $period_label, 'period_price' => $period_price, 'package_type' => $package_type );

}

/**
 * Recursive array replace \\
 */
if( !function_exists('recursive_array_replace') ){
    function recursive_array_replace( $find, $replace, $array ) {
        if ( ! is_array( $array ) ) {
            return str_replace( $find, $replace, $array );
        }

        foreach ( $array as $key => $value ) {
            $array[$key] = recursive_array_replace( $find, $replace, $value );
        }

        return $array;
    }
}

/**
 * Get HTML Resources
 */
if( !function_exists('ovacrs_get_html_resources') ){
    function ovacrs_get_html_resources( $product_id ) {
        $html = '';

        $resource_name = get_post_meta( $product_id, 'ovacrs_resource_name', true );

        if ( !empty( $resource_name ) && is_array( $resource_name ) ) {
            $resource_price         = get_post_meta( $product_id, 'ovacrs_resource_price', true );
            $resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );
            $resource_id            = get_post_meta( $product_id, 'ovacrs_resource_id', true );
            $resource_desc          = get_post_meta( $product_id, 'ovacrs_resource_desc', true );

            $html .= '<div class="ovacrs_resource">';

            foreach( $resource_name as $key => $value ) {
                $rs_key = isset( $resource_id[$key] ) ? $resource_id[$key] : '';
                $rs_price = isset( $resource_price[$key] ) ? $resource_price[$key] : 0;
                $rs_duration_type = isset( $resource_duration_type[$key] ) ? $resource_duration_type[$key] : 'total';
                $rs_desc = isset( $resource_desc[$key] ) ? $resource_desc[$key] : '';

                $html .= '<div class="rs_wrap_item">';
                    $html .= '<div class="item col-lg-4 col-md-6">';
                        $html .= '<div class="left">';
                            $html .= '<input type="checkbox" data-resource_key="'.esc_attr( $rs_key ).'" name="ovacrs_resource_checkboxs['.$product_id.']['.esc_attr( $rs_key ).']" value="'.esc_attr( $value ).'" />';
                            $html .= esc_html( $value );
                        $html .= '</div>';

                        $html .= '<div class="right">';
                            $html .= '<div class="resource">';
                                $html .= '<span class="dur_price">'.wc_price( $rs_price ).'</span>';
                                $html .= '<span class="slash">/</span>';
                                $html .= '<span class="dur_type">';
                                    if ( $rs_duration_type === 'hours' ) {
                                        $html .= esc_html__( 'Hour(s)', 'ova-crs' );
                                    } elseif  ( $rs_duration_type === 'days' ) {
                                        $html .= esc_html__( 'Day(s)', 'ova-crs' );
                                    } elseif ( $rs_duration_type === 'total' ){
                                        $html .= esc_html__( 'Total', 'ova-crs' );
                                    }
                                $html .= '</span>';
                            $html .= '</div>';
                        $html .= '</div>';
                    $html .= '</div>';

                    if ( $rs_desc ) {
                        $html .= '<div class="desc">'.esc_html( $rs_desc ).'</div>';
                    }
                $html .= '</div>';
            }

            $html .= '</div>';
        }

        return $html;
    }
}

// Get dateformat placeholder
if ( ! function_exists( 'ovacrs_get_dateformat_placeholder' ) ) {
    function ovacrs_get_dateformat_placeholder( $dateformat = '' ) {
        $placeholder = '';

        if ( $dateformat === 'd-m-Y' ) {
            $placeholder = esc_html__( 'd-m-Y', 'ova-crs' );
        } elseif ( $dateformat === 'm/d/Y' ) {
            $placeholder = esc_html__( 'm/d/Y', 'ova-crs' );
        } elseif ( $dateformat === 'Y/m/d' ) {
            $placeholder = esc_html__( 'Y/m/d', 'ova-crs' );
        } elseif ( $dateformat === 'F j, Y' ) {
            $placeholder = esc_html__( 'F j, Y', 'ova-crs' );
        } else {
            $placeholder = esc_html__( 'Y-m-d', 'ova-crs' );
        }

        return $placeholder;
    }
}