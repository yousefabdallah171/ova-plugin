<?php defined( 'ABSPATH' ) || exit();





function woo_new_product_tab( $tabs ) {


	// Adds the new tab
	if( get_theme_mod( 'rd_show_request_booking', 'true' ) == 'true' ){
		$tabs['ovacrs_contact'] = array(
			'title' 	=> esc_html__( 'Request for booking', 'ova-crs' ),
			'priority' 	=> (int)get_theme_mod( 'rd_rbf_order_tab', 11 ),
			'callback' 	=> 'ovacrs_woo_new_product_tab_content'
		);
	}

	

	if (get_theme_mod('rd_ctf_update_show_hide') === 'true') {
		$tabs['ovacrs_contact_form_2'] = array(
			'title' 	=> esc_html__( 'Contact form', 'ova-crs' ),
			'priority' 	=> (int)get_theme_mod( 'rd_ctf_update_order_tab', 21 ),
			'callback' 	=> 'ova_new_product_tab_contact_content'
		);
	}
	

	return $tabs;

}

function ova_new_product_tab_contact_content() {
	
	?>
	<div>
		<h4 class="title-contact-form-update">
			<?php esc_html_e( 'Send your requirement to us. We will check email and contact you soon.', 'ova-crs' ); ?>
		</h4>
		<div class="ova-contact-form-tabs-update">
			<?php
				$product_id = get_the_id();
				$short_code_form_detail = get_post_meta( $product_id, 'ovacrs_contact_form_shortcode', true );
				$short_code_customize = get_theme_mod('rd_ctf_update_short_code', 'true');

				$short_code_form = ! empty($short_code_form_detail) ? $short_code_form_detail : $short_code_customize;

				echo do_shortcode($short_code_form) ;
			?>
		</div>
	</div>
	<?php
}

function ovacrs_woo_new_product_tab_content() { 
	wc_get_template_part( 'rental/ovacrs-request-booking' );
}



