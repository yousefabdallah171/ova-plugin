<?php
if ( ! defined( 'ABSPATH' ) ) exit();


add_action( 'wp_ajax_ovacrs_load_data_product_create_order', 'ovacrs_load_data_product_create_order' );
add_action( 'wp_ajax_nopriv_ovacrs_load_data_product_create_order', 'ovacrs_load_data_product_create_order' );
function ovacrs_load_data_product_create_order() {
	$name_product 				= isset($_POST['name_product']) ? sanitize_text_field( $_POST['name_product'] ) : '';
	$id_product 				= trim( sanitize_text_field( $name_product ) );
	$manage_store 				= get_post_meta( $id_product, 'ovacrs_manage_store', true );
	$rental_type 				= get_post_meta( $id_product, 'ovacrs_price_type', true );
	$petime_id 					= get_post_meta( $id_product, 'ovacrs_petime_id', true );
	$ovacrs_amount_insurance 	= get_post_meta( $id_product, 'ovacrs_amount_insurance', true );
	$ovacrs_id_vehicles 		= get_post_meta( $id_product, 'ovacrs_id_vehicles', true );

	if ( $manage_store === 'store' ) {
		$ovacrs_id_vehicles = false;
	}

	$product_price 				= get_post_meta( $id_product, '_regular_price', true);
	$resource_html 				= ovacrs_get_html_resources( $id_product );

	$data = [
		'rental_type' 				=> $rental_type,
		'petime_id' 				=> $petime_id,
		'ovacrs_amount_insurance' 	=> $ovacrs_amount_insurance,
		'ovacrs_id_vehicles' 		=> $ovacrs_id_vehicles,
		'product_price' 			=> $product_price,
		'resource_html' 			=> $resource_html,
	];

	echo json_encode( $data );

	wp_die();
}


add_action( 'wp_ajax_ovacrs_get_total_price_and_quantity', 'ovacrs_get_total_price_and_quantity' );
add_action( 'wp_ajax_nopriv_ovacrs_get_total_price_and_quantity', 'ovacrs_get_total_price_and_quantity' );
function ovacrs_get_total_price_and_quantity() {
	$id_product 	= isset($_POST['id_product']) ? trim( sanitize_text_field( $_POST['id_product'] ) ) : '';
	$rental_type 	= get_post_meta( $id_product, 'ovacrs_price_type', true );
	$start_date 	= isset($_POST['start_date']) ? trim( sanitize_text_field( $_POST['start_date'] ) ) : '';
	$end_date 		= isset($_POST['end_date']) ? trim( sanitize_text_field( $_POST['end_date'] ) ) : '';
	$id_package 	= isset($_POST['id_package']) ? trim( sanitize_text_field( $_POST['id_package'] ) ) : '';
	$qty 			= isset($_POST['qty']) ? trim( sanitize_text_field( $_POST['qty'] ) ) : 0;
	$resources 		= isset($_POST['resources']) ? str_replace( '\\', '', $_POST['resources'] )  : '';
	$resources_data = (array) json_decode( $resources );

	$rent_time = get_time_bew_2day( strtotime( $start_date ), strtotime( $end_date ) );

	$product_price = get_post_meta( $id_product, '_regular_price', true);
	
	$product_detail = get_real_price_detail( $product_price, $id_product, strtotime( $start_date ), strtotime( $end_date ) );

	if( $rental_type == 'period_time' ) {

		if( empty( $start_date ) ) {
			$data = [ 
				'error' => true,
				'start_date' => 'empty',
				'message' => esc_html__('Please choose Pick-up Date', 'ova-crs'),
			];
		} elseif( empty( $id_package ) ) {
			$data = [ 
				'error' => true,
				'id_package' => 'empty',
				'message' => esc_html__('Please Pick Package', 'ova-crs'),
			];
		} else {
			$total = ovacrs_get_total_price_by_start_end_date( $id_product, $start_date, $end_date, $id_package );
			$total['line_total'] = $total['line_total'];
            $total['product_price'] = $total['line_total'];
			$data = $total;
		}

	} else {
		if( empty( $start_date ) ) {
			$data = [ 
				'error' => true,
				'start_date' => 'empty',
				'message' => esc_html__('Please choose Pick-up Date', 'ova-crs'),
			];
		} elseif( empty( $end_date ) ) {
			$data = [ 
				'error' => true,
				'end_date' => 'empty',
				'message' => esc_html__('Please choose Drop-off Date', 'ova-crs'),
			];
		} else {
			$total = ovacrs_get_total_price_by_start_end_date( $id_product, $start_date, $end_date, $id_package );

			if( $rental_type == 'hour' ) {

                $total['quantity'] = $total['quantity'] .' '. esc_html__( 'Hour(s)', 'ova-crs' );

            } else if( $rental_type == 'mixed' ) {
            		
            	$get_time_bew_2day = get_time_bew_2day( strtotime( $start_date ), strtotime( $end_date ) );
            		
            	if( $get_time_bew_2day['rent_time_day_raw'] >= 1 ){

            	 	$label_mixed = esc_html__( 'Day(s)', 'ova-crs' );

            	}else{

            		$label_mixed = esc_html__( 'Hour(s)', 'ova-crs' );

            	}

            	$total['quantity'] = $total['quantity'].' '.$label_mixed;

            }else if( $rental_type == 'day' || $rental_type == 'transportation' ) {

                $total['quantity'] = $total['quantity'] .' '. esc_html__( 'Days', 'ova-crs' );

            }

            $total['line_total'] = $total['line_total'];
            $total['product_price'] = $product_detail;
			$data = $total;
		}
	}

	if ( !empty( $resources_data ) && is_array( $resources_data ) ) {
		$resource_id = get_post_meta( $id_product, 'ovacrs_resource_id', true );
        $resource_price = get_post_meta( $id_product, 'ovacrs_resource_price', true );
        $resource_duration_type = get_post_meta( $id_product, 'ovacrs_resource_duration_type', true );
        
        foreach( $resources_data as $key_c_re => $value_c_re ) {
            foreach( $resource_id as $key_id => $value_id ) {
                if ( $key_c_re ==  $value_id ) {
                    if ( $resource_duration_type[$key_id] == 'total' ) {
                        $total['line_total'] = $total['line_total'] + $resource_price[$key_id];
                    } elseif ( $resource_duration_type[$key_id] == 'days' ) {
                        $total['line_total'] = $total['line_total'] + $resource_price[$key_id] * $rent_time['rent_time_day'];
                    } elseif ( $resource_duration_type[$key_id] == 'hours' ) {
                        if ( $rent_time['rent_time_day_raw'] < 1 ) {
                            $total['line_total'] = $total['line_total'] + $resource_price[$key_id];
                        } else {
                            $total['line_total'] = $total['line_total'] + $resource_price[$key_id] * 24;
                        }
                    }
                }
            }
        }

        $data = $total;
	}

	if ( isset( $data['line_total'] ) && $data['line_total'] ) {
		$data['line_total'] *= absint( $qty );
	}

	echo json_encode( $data );

	wp_die();
}


add_action( 'wp_ajax_ovacrs_get_package_by_time', 'ovacrs_get_package_by_time_cus' );
add_action( 'wp_ajax_nopriv_ovacrs_get_package_by_time', 'ovacrs_get_package_by_time_cus' );
function ovacrs_get_package_by_time_cus() {

	$id = isset($_POST['post_id']) ? sanitize_text_field( $_POST['post_id'] ) : '';
	$start_date = isset($_POST['startdate']) ? sanitize_text_field( $_POST['startdate'] ) : '';

	$manage_store = get_post_meta( $id, 'ovacrs_manage_store', true );
	
	// Total Car in the Store
    $total_car_store = get_post_meta( $id, 'ovacrs_car_count', true ) ? get_post_meta( $id, 'ovacrs_car_count', true ) : 0;

    if ( $manage_store === 'store' ) {
        $total_car_store = absint( get_post_meta( $id, 'ovacrs_stock_quantity', true ) );
    }
    
    $post_array_id = get_arr_product_ids( $id );
    $statuses = ovacrs_order_status();
    $orders_ids = ovacrs_get_orders_ids_by_product_id( $post_array_id, $statuses );


    $car_using_this_time = array();

    // Get list package of period time
	$ovacrs_petime_id	= get_post_meta( $id, 'ovacrs_petime_id', true );

	$ovacrs_petime_label = get_post_meta( $id, 'ovacrs_petime_label', true );

    // For Order ID
    foreach ( $orders_ids as $key => $value ) {
        // Get Order Detail by Order ID
        $order = wc_get_order($value);

        // Get Meta Data type line_item of Order
        $order_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
       
        // For Meta Data
        foreach ( $order_items as $item_id => $item ) {

            $ovacrs_pickup_date_store = $ovacrs_pickoff_date_store = $id_vehicle = $quantity = '';

            // Check Line Item have item ID is Car_ID
            if( in_array( $item->get_product_id(), $post_array_id ) ){

                // Check time to Prepare before delivered
                $prepare_time = get_post_meta( $id, 'ovacrs_prepare_vehicle', true ) ? get_post_meta( $id, 'ovacrs_prepare_vehicle', true ) * 60 : 0;

                // Get value of pickup date, pickoff date
                $ovacrs_pickup_date_store 	= strtotime( $item->get_meta( 'ovacrs_pickup_date' ) );
                $ovacrs_pickoff_date_store 	= strtotime( $item->get_meta( 'ovacrs_pickoff_date' ) ) + $prepare_time;

                $id_vehicle = $item->get_meta( 'id_vehicle' );
                $quantity 	= $item->get_meta( 'ovacrs_quantity' );

                // Only compare date when "PickOff Date in Store" > "Current Time" becaue "PickOff Date Rent" have to > "Current Time"
                if( $ovacrs_pickoff_date_store >= current_time( 'timestamp' ) && $id_vehicle != '' ){
                    
                    
				    if( $ovacrs_petime_id ){ 
				        foreach ( $ovacrs_petime_id as $petime_id ) {

				        	$start_end_time_package = get_rental_info_period( $id, $start_date, 'period_time', $petime_id );
				        	$ovacrs_pickup_date = $start_end_time_package['start_time'];
				        	$ovacrs_pickoff_date = $start_end_time_package['end_time'];


				        	// Check rent time
		                    if( ! ($ovacrs_pickoff_date <= $ovacrs_pickup_date_store || $ovacrs_pickoff_date_store <= $ovacrs_pickup_date ) ){
		                    	for($i = 0; $i < $quantity; $i++ ) {
		                    		array_push( $car_using_this_time, $petime_id );
		                    	}
		                    }

				        }
				    }
                    

                }
                
            }

        }

    }

    // Package available
    $pack_avail = array( esc_html__( 'Select Package', 'ova-crs' ) );

    if( $ovacrs_petime_id ){ 
		foreach ( $ovacrs_petime_id as $key => $petime_id ) {

			$i = 0;
			foreach ($car_using_this_time as $v) {
				if( $petime_id == $v ){
					$i ++;
				}
			}
			if( $i < $total_car_store ){

				$pack_avail[ $petime_id ] = $ovacrs_petime_label[$key];
				
			} 
			
		}
	}

	
	echo json_encode( $pack_avail );

	wp_die();
}

// Remove Cart by Ajax
add_action( 'wp_ajax_ovacrs_remove_cart', 'ovacrs_remove_cart' );
add_action( 'wp_ajax_nopriv_ovacrs_remove_cart', 'ovacrs_remove_cart' );
function ovacrs_remove_cart() {
	$cart_item_key = isset( $_POST['cart_item_key'] ) ? sanitize_text_field( $_POST['cart_item_key'] ) : '';

	if ( $cart_item_key && false !== WC()->cart->remove_cart_item( $cart_item_key ) ) {
		$count = WC()->cart->get_cart_contents_count();

		echo absint( $count );
	} else {
		echo '';
	}

	wp_die();
}