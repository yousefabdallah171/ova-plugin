<?php 
defined( 'ABSPATH' ) || exit();


// Custom Calculate Total Add To Cart
add_action( 'woocommerce_before_calculate_totals',  'ovacrs_woocommerce_before_calculate_totals' , 10, 1); 
function ovacrs_woocommerce_before_calculate_totals( $cart_object ){
    // Deposit
    $has_deposit = false;
    WC()->cart->deposit_info = array();

    $deposit_amount = $remaining_amount = $insurance_amount = 0;

    foreach ( $cart_object->get_cart() as $cart_item_key => $cart_item ) {
        // Check custom product type is ovacrs_car_rental
        if ( ! $cart_item['data']->is_type( 'ovacrs_car_rental' ) ) continue;

        // Line total
        $line_total = 0;

        // Product id
        $product_id = $cart_item['data']->get_id();

        // Get rental type
        $rental_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

        // Pick-up date
        $pickup_date = isset( $cart_item['ovacrs_pickup_date'] ) ? strtotime( $cart_item['ovacrs_pickup_date'] ) : '';

        // Drop-off date
        $dropoff_date = isset( $cart_item['ovacrs_pickoff_date'] ) ? strtotime( $cart_item['ovacrs_pickoff_date'] ) : '';

        // Pick-up location
        $pickup_loccation = isset( $cart_item['ovacrs_pickup_loc'] ) ? $cart_item['ovacrs_pickup_loc'] : '';

        // Drop-off location
        $dropoff_location = isset( $cart_item['ovacrs_pickoff_loc'] ) ? $cart_item['ovacrs_pickoff_loc'] : '';

        // Rent time
        $rent_time = get_time_bew_2day( $pickup_date, $dropoff_date );

        // Get insurance amount
        $product_insurance = floatval( get_post_meta( $product_id, 'ovacrs_amount_insurance', true ) );
        $insurance_amount += $product_insurance;

        // Resources
        $cart_resources = isset( $cart_item['resources'] ) ? $cart_item['resources'] : '';

        // Quantity
        $cart_quantity = isset( $cart_item['ovacrs_quantity'] ) && $cart_item['ovacrs_quantity'] ? (int) $cart_item['ovacrs_quantity'] : 1;

        if ( 'period_time' === $rental_type ) {
            $line_total     = floatval( $cart_item['period_price'] );
            $line_total     += $product_insurance;

            // Calculate resource price
            if ( $cart_resources && is_array( $cart_resources ) ) {
                // Get resource ids
                $resource_ids = get_post_meta( $product_id, 'ovacrs_resource_id', true );
                if ( empty( $resource_ids ) || ! is_array( $resource_ids ) ) $resource_ids = array();

                // Get resource prices
                $resource_prices = get_post_meta( $product_id, 'ovacrs_resource_price', true );

                // Get resource durations
                $resource_durations = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );

                // Loop cart resources
                foreach ( $cart_resources as $res_id => $name ) {
                    $key = array_search( $res_id, $resource_ids );

                    if ( is_bool( $key ) ) continue;

                    $res_price      = isset( $resource_prices[$key] ) ? floatval( $resource_prices[$key] ) : 0;
                    $res_duration   = isset( $resource_durations[$key] ) ? $resource_durations[$key] : '';

                    if ( 'total' === $res_duration ) {
                        $line_total += $res_price;
                    } elseif ( 'days' === $res_duration ) {
                        $line_total += $res_price * $rent_time['rent_time_day'];
                    } elseif ( 'hours' === $res_duration ) {
                        if ( $rent_time['rent_time_day_raw'] < 1 ) {
                            $line_total += $res_price;
                        } else {
                            $line_total += $res_price * 24;
                        }
                    }
                }
            }
        } else {
            if ( 'transportation' === $rental_type ) {
                $get_price_by_date = ovacrs_get_total_price_by_start_date_transport( $product_id, $pickup_loccation, $dropoff_location, $cart_item );
            } else {
                $get_price_by_date = get_price_by_date( $product_id, $pickup_date, $dropoff_date ); 
            }

            $quantity   = $get_price_by_date['quantity'];
            $line_total = $get_price_by_date['line_total'];
            $line_total += $product_insurance;

            // Get location fee
            $location_fee = 0;
            if ( 'day' === $rental_type ) {
                $location_fee = ovacrs_get_price_fee_location_by_pickup_dropoff( $product_id, $pickup_loccation, $dropoff_location );
            }
            $line_total += $location_fee;

            // Calculate resource price
            if ( $cart_resources && is_array( $cart_resources ) ) {
                // Get resource ids
                $resource_ids = get_post_meta( $product_id, 'ovacrs_resource_id', true );
                if ( empty( $resource_ids ) || ! is_array( $resource_ids ) ) $resource_ids = array();

                // Get resource prices
                $resource_prices = get_post_meta( $product_id, 'ovacrs_resource_price', true );

                // Get resource durations
                $resource_durations = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );

                // Loop cart resources
                foreach ( $cart_resources as $res_id => $name ) {
                    $key = array_search( $res_id, $resource_ids );

                    if ( is_bool( $key ) ) continue;

                    $res_price      = isset( $resource_prices[$key] ) ? floatval( $resource_prices[$key] ) : 0;
                    $res_duration   = isset( $resource_durations[$key] ) ? $resource_durations[$key] : '';

                    if ( 'total' === $res_duration ) {
                        $line_total += $res_price;
                    } elseif ( 'days' === $res_duration ) {
                        $line_total += $res_price * $quantity;
                    } elseif ( 'hours' === $res_duration ) {
                        if ( $rent_time['rent_time_day_raw'] < 1 ) {
                            $line_total += $res_price * $quantity;
                        } else {
                            $line_total += $res_price * $quantity * 24;
                        }
                    }
                }
            }
        }

        // Deposit
        $cart_deposit   = isset( $cart_item['ova_type_deposit'] ) ? $cart_item['ova_type_deposit'] : '';
        $deposit_enable = get_post_meta ( $product_id, 'ovacrs_enable_deposit', true );

        if ( 'deposit' === $cart_deposit && 'yes' == $deposit_enable ) {
            $has_deposit = true;
            $sub_deposit = $sub_remaining = 0;

            // Get deposit data
            $deposit_value  = floatval( get_post_meta ( $product_id, 'ovacrs_amount_deposit', true ) );
            $deposit_type   = get_post_meta ( $product_id, 'ovacrs_type_deposit', true );

            if ( 'percent' === $deposit_type ) {
                $sub_deposit = ( $line_total * $deposit_value ) / 100;
            } elseif ( 'value' === $deposit_type ) {
                $sub_deposit = $deposit_value;
            }

            $sub_remaining = $line_total - $sub_deposit;

            // Set cart item price
            $cart_item['data']->set_price( round( $sub_deposit, wc_get_price_decimals() ) );

            // Coupons
            $coupons = WC()->cart->get_applied_coupons();

            if ( $coupons && is_array( $coupons ) ) {
                foreach ( $coupons as $coupon_code ) {
                    $coupon = new WC_Coupon( $coupon_code );

                    if ( $coupon && is_object( $coupon ) ) {
                        $coupon_type    = $coupon->get_discount_type();
                        $coupon_amount  = $coupon->get_amount();
                        
                        if ( $coupon_type && $coupon_amount ) {
                            if ( 'fixed_cart' == $coupon_type || 'fixed_product' == $coupon_type ) {
                                $sub_deposit    -= $coupon_amount;
                                $line_total     -= $coupon_amount;
                            }

                            if ( 'percent' == $coupon_type ) {
                                $sub_deposit        -= $sub_deposit * ( $coupon_amount / 100 );
                                $sub_remaining      -= $sub_remaining * ( $coupon_amount / 100 );
                                $line_total         -= $line_total * ( $coupon_amount / 100 );
                            }
                        }
                    }
                }
            }

            // Total deposit
            $deposit_amount += $sub_deposit;

            // Total remaining
            $remaining_amount += $sub_remaining * $cart_quantity;

            $cart_item['data']->add_meta_data( 'deposit_amount', round( $sub_deposit, wc_get_price_decimals() ), true );
            $cart_item['data']->add_meta_data( 'remaining_amount', round( $sub_remaining, wc_get_price_decimals() ), true );
            $cart_item['data']->add_meta_data( 'pay_total', round( $line_total, wc_get_price_decimals() ), true );
        } else {
            $cart_item['data']->set_price( round( $line_total, wc_get_price_decimals() ) );
        }

        $cart_object->cart_contents[ $cart_item_key ]['quantity'] = $cart_quantity;

    } // End foreach

    // Deposit info
    if ( $has_deposit ) {
        $deposit_amount     = round( $deposit_amount, wc_get_price_decimals() );
        $remaining_amount   = round( $remaining_amount, wc_get_price_decimals() );

        WC()->cart->deposit_info[ '_ova_has_deposit' ]      = $has_deposit;
        WC()->cart->deposit_info[ 'ova_type_deposit' ]      = 'deposit';
        WC()->cart->deposit_info[ 'ova_deposit_amount' ]    = $deposit_amount;
        WC()->cart->deposit_info[ 'ova_remaining_amount' ]  = $remaining_amount;
    }

    // Insurance
    if ( $insurance_amount ) {
        $insurance_amount = round( $insurance_amount, wc_get_price_decimals() );
        WC()->cart->deposit_info[ 'ova_insurance_amount' ] = $insurance_amount;
    }
}

function set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val = array(), $price_type = '', $rent_time = 0 ) {

   if( $ovacrs_global_discount_duration_val ){

    foreach ($ovacrs_global_discount_duration_val as $key_dur => $value_dur) {
     $ovacrs_global_discount_duration_type = get_post_meta( $product_id, 'ovacrs_global_discount_duration_type', true );
     if( $ovacrs_global_discount_duration_type[$key_dur] == $price_type && $rent_time >= $value_dur){
        $ovacrs_global_discount_price = get_post_meta( $product_id, 'ovacrs_global_discount_price', true );
        return $ovacrs_global_discount_price[$key_dur];

    }
}
}

return false;

}


function set_price_by_rt_discount( $ovacrs_rt_discount_duration_val = array(), $ovacrs_rt_discount_duration_type = array(), $ovacrs_rt_discount_duration_price = array(), $price_type = '', $rent_time = 0 ) {

    if( $ovacrs_rt_discount_duration_val ){
        foreach ($ovacrs_rt_discount_duration_val as $key_dur => $value_dur) {
         if( $ovacrs_rt_discount_duration_type[$key_dur] == $price_type && $rent_time >=  $value_dur){
            return $ovacrs_rt_discount_duration_price[$key_dur];

        }
    }
}

return false;

}

// YOu have to insert unistamp time
function get_time_bew_2day( $start, $end ){

    $rent_time_day_raw = ( $end - $start )/(24*60*60);
    $rent_time_hour_raw = ( $end - $start )/(60*60);
    $rent_time_day = ceil( $rent_time_day_raw );
    $rent_time_hour = ceil ( $rent_time_hour_raw );

    return array( 'rent_time_day_raw' => $rent_time_day_raw, 'rent_time_hour_raw' => $rent_time_hour_raw, 'rent_time_day' => $rent_time_day, 'rent_time_hour' => $rent_time_hour );
    
}


// Quantity in Global
function ovacrs_quantity_global( $product_id, $rent_time ){

    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );
    
    if( $price_type == 'day' ){
        return (int)$rent_time['rent_time_day'];
    }else if( $price_type == 'hour' ){
        return (int)$rent_time['rent_time_hour'];
    }else{
        if( $rent_time['rent_time_day_raw'] < 1 ){
            return (int)$rent_time['rent_time_hour'];
        }else{
            return (int)$rent_time['rent_time_day'];
        }
    }
}

// Price in Global
function ovacrs_price_global( $product_id, $rent_time ){

    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

    $ovacrs_global_discount_duration_val = get_post_meta( $product_id, 'ovacrs_global_discount_duration_val', true );
    if( $ovacrs_global_discount_duration_val ){ arsort( $ovacrs_global_discount_duration_val ); }
    
    if( $price_type == 'day' ){

        // Set Price by Global Discount
        $gl_price = get_post_meta( $product_id, '_regular_price', true );
        if( $ovacrs_global_discount_duration_val ){
            $gl_set_price = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $price_type = 'days', $rent_time['rent_time_day'] );
            $gl_price = ( $gl_set_price != false ) ? $gl_set_price : $gl_price;
        }
        return $gl_price;

    }else if( $price_type == 'hour' ){

        $gl_price = get_post_meta( $product_id, 'ovacrs_regul_price_hour', true );

        if( $ovacrs_global_discount_duration_val ){
            $gl_set_price = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $price_type = 'hours', $rent_time['rent_time_hour'] );
            $gl_price = ( $gl_set_price != false ) ? $gl_set_price : $gl_price;
        }
        return $gl_price;

    }else{ // Price type is Mixed

        if( $rent_time['rent_time_day_raw'] < 1 ){

            $gl_price = get_post_meta( $product_id, 'ovacrs_regul_price_hour', true );
            if( $ovacrs_global_discount_duration_val ){
                $gl_set_price = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $price_type = 'hours', $rent_time['rent_time_hour'] );
                $gl_price = ( $gl_set_price != false ) ? $gl_set_price : $gl_price;
            }
            return $gl_price;

        }else{

            $gl_price = get_post_meta( $product_id, '_regular_price', true );

            if( $ovacrs_global_discount_duration_val ){
                $gl_set_price = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $price_type = 'days', $rent_time['rent_time_day'] );
                $gl_price = ( $gl_set_price != false ) ? $gl_set_price : $gl_price;
            }
            return $gl_price;
        }
    }

}

function ovacrs_price_global_has_special_time( $product_id, $rent_time, $quantity_special ){

    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

    $ovacrs_global_discount_duration_val = get_post_meta( $product_id, 'ovacrs_global_discount_duration_val', true );
    if ( $ovacrs_global_discount_duration_val ) arsort( $ovacrs_global_discount_duration_val );

    if( $price_type == 'day' ){

        // Set Price by Global Discount
        $gl_price = get_post_meta( $product_id, '_regular_price', true );

        if ( $ovacrs_global_discount_duration_val ) {
            $quantity       = absint( $rent_time['rent_time_day'] ) - absint( $quantity_special );
            $gl_set_price   = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $price_type = 'days', $quantity );
            $gl_price       = $gl_set_price != false ? $gl_set_price : $gl_price;
        }

        return $gl_price;

    } elseif ( $price_type == 'hour' ){

        $gl_price = get_post_meta( $product_id, 'ovacrs_regul_price_hour', true );

        return $gl_price;

    } else { // Price type is Mixed
        if ( $rent_time['rent_time_day_raw'] < 1 ) {
            $gl_price = get_post_meta( $product_id, 'ovacrs_regul_price_hour', true );
            
            return $gl_price;

        } else {
            $gl_price = get_post_meta( $product_id, '_regular_price', true );

            return $gl_price;
        }
    }
}

// Calculate in Special Time ( Range Time )
function ovacrs_price_special_time( $product_id, $rent_time, $key_rt ){


    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_price = get_post_meta( $product_id, 'ovacrs_rt_price', true );
    $ovacrs_rt_price_hour = get_post_meta( $product_id, 'ovacrs_rt_price_hour', true );
    $ovacrs_rt_discount = get_post_meta( $product_id, 'ovacrs_rt_discount', true );


    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );
    
    if( $ovacrs_rt_startdate[$key_rt] ){




            // Check if PickUp Date bettwen date of Range Time
        if( $price_type == 'day' ){

            $rt_price = $ovacrs_rt_price[$key_rt];
                // Return ST Price Discount
            if( isset( $ovacrs_rt_discount[$key_rt] ) ){
                $ovacrs_rt_discount_duration_val = $ovacrs_rt_discount[$key_rt]['duration'];
                arsort($ovacrs_rt_discount_duration_val);

                $ovacrs_rt_discount_duration_type = $ovacrs_rt_discount[$key_rt]['duration_type'];
                $ovacrs_rt_discount_duration_price = $ovacrs_rt_discount[$key_rt]['price'];
                $st_set_price = set_price_by_rt_discount($ovacrs_rt_discount_duration_val, $ovacrs_rt_discount_duration_type, $ovacrs_rt_discount_duration_price, $price_type='days', $rent_time['rent_time_day'] );
                $rt_price = $st_set_price != false ? $st_set_price : $rt_price;
            }

            return $rt_price;


        }else if( $price_type == 'hour' ){

            $rt_price = $ovacrs_rt_price_hour[$key_rt];

                // Set Price by RT(ST) Discount
            if( isset( $ovacrs_rt_discount[$key_rt] ) ){
                $ovacrs_rt_discount_duration_val = $ovacrs_rt_discount[$key_rt]['duration'];
                arsort($ovacrs_rt_discount_duration_val);
                $ovacrs_rt_discount_duration_type = $ovacrs_rt_discount[$key_rt]['duration_type'];
                $ovacrs_rt_discount_duration_price = $ovacrs_rt_discount[$key_rt]['price'];
                $st_set_price =  set_price_by_rt_discount( $ovacrs_rt_discount_duration_val, $ovacrs_rt_discount_duration_type, $ovacrs_rt_discount_duration_price, $price_type='hours', $rent_time['rent_time_hour'] );
                $rt_price = $st_set_price != false ? $st_set_price : $rt_price;
            }

            return $rt_price;

            }else{ // Price type is Mixed

                if( $rent_time['rent_time_day_raw'] < 1 ){

                    $rt_price = $ovacrs_rt_price_hour[$key_rt];
                    // Set Price by RT(ST) Discount
                    if( isset( $ovacrs_rt_discount[$key_rt] ) ){
                        $ovacrs_rt_discount_duration_val = $ovacrs_rt_discount[$key_rt]['duration'];
                        arsort($ovacrs_rt_discount_duration_val);
                        $ovacrs_rt_discount_duration_type = $ovacrs_rt_discount[$key_rt]['duration_type'];
                        $ovacrs_rt_discount_duration_price = $ovacrs_rt_discount[$key_rt]['price'];
                        $st_set_price = set_price_by_rt_discount( $ovacrs_rt_discount_duration_val, $ovacrs_rt_discount_duration_type, $ovacrs_rt_discount_duration_price, $price_type='hours', $rent_time['rent_time_hour'] );
                        $rt_price = $st_set_price != false ? $st_set_price : $rt_price;
                    }

                    return $rt_price;

                }else{

                    $rt_price = $ovacrs_rt_price[$key_rt];
                    // Set Price by RT(ST) Discount
                    if( isset( $ovacrs_rt_discount[$key_rt] ) ){
                        $ovacrs_rt_discount_duration_val = $ovacrs_rt_discount[$key_rt]['duration'];
                        arsort($ovacrs_rt_discount_duration_val);

                        $ovacrs_rt_discount_duration_type = $ovacrs_rt_discount[$key_rt]['duration_type'];
                        $ovacrs_rt_discount_duration_price = $ovacrs_rt_discount[$key_rt]['price'];
                        $st_set_price = set_price_by_rt_discount( $ovacrs_rt_discount_duration_val, $ovacrs_rt_discount_duration_type, $ovacrs_rt_discount_duration_price, $price_type='days', $rent_time['rent_time_day'] );
                        $rt_price = $st_set_price != false ? $st_set_price : $rt_price;
                    }

                    return $rt_price;

                }
            }

    } // endif
}

function get_regular_price_hour_mixed ($product_id, $quantity_hour = 0) {
    $gl_price_hour = get_post_meta( $product_id, 'ovacrs_regul_price_hour', true );

    $ovacrs_global_discount_duration_val = get_post_meta( $product_id, 'ovacrs_global_discount_duration_val', true );
    if( $ovacrs_global_discount_duration_val ){ arsort( $ovacrs_global_discount_duration_val ); }

    if( $ovacrs_global_discount_duration_val ){
        $gl_set_price = set_price_by_global_discount( $product_id, $ovacrs_global_discount_duration_val, $price_type='hours', $quantity_hour );
        $gl_price_hour = ( $gl_set_price != false ) ? $gl_set_price : $gl_price_hour;
    }
    return $gl_price_hour;
}

function get_special_price_hour_mixed ($ovacrs_rt_price_hour_key, $key_rt) {
    $rt_price_hour = $ovacrs_rt_price_hour_key;
    // Set Price by RT(ST) Discount
    if( isset( $ovacrs_rt_discount[$key_rt] ) ){
        $ovacrs_rt_discount_duration_val = $ovacrs_rt_discount[$key_rt]['duration'];
        arsort($ovacrs_rt_discount_duration_val);
        $ovacrs_rt_discount_duration_type = $ovacrs_rt_discount[$key_rt]['duration_type'];
        $ovacrs_rt_discount_duration_price = $ovacrs_rt_discount[$key_rt]['price'];
        $st_set_price = set_price_by_rt_discount( $ovacrs_rt_discount_duration_val, $ovacrs_rt_discount_duration_type, $ovacrs_rt_discount_duration_price, $price_type='hours', $quantity_hour );
        $rt_price_hour = $st_set_price != false ? $st_set_price : $rt_price_hour;
    }
    return $rt_price_hour;
}


function get_price_by_date( $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date ){

    $rent_time = get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date );

    // Get Range Time or ST
    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_enddate = get_post_meta( $product_id, 'ovacrs_rt_enddate', true );


    /* Table Price - Global *******************************************/
    $gl_price_total = ovacrs_price_global( $product_id, $rent_time );
    if ( $gl_price_total == '' ) {
        $gl_price_total = 0;
    }
    $gl_quantity_total = ovacrs_quantity_global( $product_id, $rent_time );

    $gl_price = ovacrs_price_global( $product_id, $rent_time );
    if ( $gl_price == '' ) {
        $gl_price = 0;
    }
    $gl_quantity = ovacrs_quantity_global( $product_id, $rent_time );

    $quantity = $gl_quantity;
    $line_total = $gl_price * $gl_quantity;

    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );
    if ($price_type === "mixed") {

        $quantity_day = floor($rent_time['rent_time_day_raw']);

        if ($quantity_day <= 0) {
            $quantity_hour = $rent_time['rent_time_hour_raw'];
        } elseif ($quantity_day > 0) {
            $quantity_hour = ($rent_time['rent_time_hour_raw'] - $quantity_day * 24);
        }

        $gl_price_hour = get_regular_price_hour_mixed($product_id, $quantity_hour);
        if ( $gl_price_hour == '' ) {
            $gl_price_hour = 0;
        }
        $line_total = $quantity_day * $gl_price + $quantity_hour * $gl_price_hour;
    }


    $rt_price_total = $gl_quantity_total_4 = $rt_quantity_total = $rt_quantity_total_mix = $rt_price_total_mix = 0;
    $rt_quantity_total_4 = $rt_price_total_4 = 0;
    $rt_quantity_total_3 = $rt_price_total_3 = 0;
    $rt_quantity_total_2 = $rt_price_total_2 = 0;
    $rt_quantity_total_1 = $rt_price_total_1 = 0;

    $rt_quantity_total_mix_4 = $rt_price_total_mix_4 = 0;
    $rt_quantity_total_mix_3 = $rt_price_total_mix_3 = 0;
    $rt_quantity_total_mix_2 = $rt_price_total_mix_2 = 0;
    $rt_quantity_total_mix_1 = $rt_price_total_mix_1 = 0;

    $rt_price_hour_mix = 0;


    $i = 0; $data_max = ''; $flag_max = false;
    /* Table Price - Special Time ( Range Time) *******************************************/
    if( $ovacrs_rt_startdate ){

        foreach ($ovacrs_rt_startdate as $key_rt => $value_rt) {
            
            $start_date_str = $ovacrs_rt_startdate[$key_rt];
            $end_date_str = $ovacrs_rt_enddate[$key_rt];

            $i++;

            if( $i === 1 ) {
                
                $data_max = strtotime( $end_date_str );
                $flag_max = true;

            } elseif( $data_max < strtotime( $end_date_str ) ) {

                $data_max = strtotime( $end_date_str );
                $flag_max = true;

            } else {

                $flag_max = false;

            }

            // If Special_Time_Start_Date <= pickup_date && pickoff_date <= Special_Time_End_Date
            if( $ovacrs_pickup_date >= strtotime( $start_date_str ) && $ovacrs_pickoff_date <= strtotime( $end_date_str ) ){

                $rt_price = ovacrs_price_special_time( $product_id, $rent_time, $key_rt );
                $rt_quantity = ovacrs_quantity_global( $product_id, $rent_time );

                $quantity = $rt_quantity;
                $line_total = $rt_price * $rt_quantity;

                $rt_quantity_total_1 += $rt_quantity;
                $rt_price_total_1 += $rt_quantity * $rt_price;

                if ($price_type === "mixed") {
                    $ovacrs_rt_price_hour = get_post_meta( $product_id, 'ovacrs_rt_price_hour', true );

                    if( $flag_max ) {
                        $rt_price_hour_mix = get_special_price_hour_mixed($ovacrs_rt_price_hour[$key_rt],$key_rt);
                    }
                    

                    $rt_quantity_total_mix_1 += $quantity_day;
                    $rt_price_total_mix_1 += $quantity_day * $rt_price;

                }

                // break;

            }else if( $ovacrs_pickup_date < strtotime( $start_date_str ) && $ovacrs_pickoff_date <= strtotime( $end_date_str ) && $ovacrs_pickoff_date >= strtotime( $start_date_str ) ){

               $gl_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $start_date_str ) );

               $rt_quantity_array = get_time_bew_2day( strtotime( $start_date_str ), $ovacrs_pickoff_date );
               $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity_array, $key_rt );
               $rt_quantity = ovacrs_quantity_global( $product_id, $rt_quantity_array );

               $rt_quantity_total_2 += $rt_quantity;
               $rt_price_total_2 += $rt_quantity * $rt_price;


               if ($price_type === "mixed") {
                    $ovacrs_rt_price_hour = get_post_meta( $product_id, 'ovacrs_rt_price_hour', true );
                    $gl_quantity = floor($gl_quantity_array['rent_time_day_raw']);
                    $rt_quantity = $quantity_day - $gl_quantity;

                    if( $flag_max ) {
                        $rt_price_hour_mix = get_special_price_hour_mixed($ovacrs_rt_price_hour[$key_rt],$key_rt);
                    }
                    $rt_quantity_total_mix_2 += $rt_quantity;
                    $rt_price_total_mix_2 += $rt_quantity * $rt_price;

                }

                // break;

            }else if( $ovacrs_pickup_date >= strtotime( $start_date_str ) && $ovacrs_pickup_date <= strtotime( $end_date_str ) && $ovacrs_pickoff_date >= strtotime( $end_date_str ) ){

                $rt_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $end_date_str ) );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity_array, $key_rt );
                $rt_quantity = ovacrs_quantity_global( $product_id, $rt_quantity_array );

                $rt_quantity_total_3 += $rt_quantity;
                $rt_price_total_3 += $rt_quantity * $rt_price;


                if ($price_type === "mixed") {

                    $ovacrs_rt_price_hour = get_post_meta( $product_id, 'ovacrs_rt_price_hour', true );
                    $rt_quantity = ceil($rt_quantity_array['rent_time_day_raw']);
                    $gl_quantity = $quantity_day - $rt_quantity;

                    if( $flag_max ) {
                        $rt_price_hour_mix = $gl_price_hour;
                    }

                    $rt_quantity_total_mix_3 += $rt_quantity;
                    $rt_price_total_mix_3 += $rt_quantity * $rt_price;

                }

                // break;

            }else if( $ovacrs_pickup_date < strtotime( $start_date_str ) && $ovacrs_pickoff_date > strtotime( $end_date_str ) ){

                $quantity_total = ovacrs_quantity_global( $product_id, get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date ) );

                $rt_rent_time = get_time_bew_2day( strtotime( $start_date_str ), strtotime( $end_date_str ) );
                $rt_quantity = ovacrs_quantity_global( $product_id, $rt_rent_time );
                

                $gl_price = ovacrs_price_global( $product_id, $rt_rent_time );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_rent_time, $key_rt );

                $rt_quantity_total_4 += $rt_quantity;
                $rt_price_total_4 += $rt_price * $rt_quantity;


                if ( $price_type === "mixed" ) {

                    $rt_quantity = ($rt_rent_time['rent_time_day_raw']);

                    if ( $flag_max ) {
                        $rt_price_hour_mix = $gl_price_hour;
                    }

                    $rt_quantity_total_mix_4 += $rt_quantity;
                    $rt_price_total_mix_4 += $rt_quantity * $rt_price;

 
                }


            }

        } // end foreach


        $rt_quantity_total = $rt_quantity_total_1 + $rt_quantity_total_2 + $rt_quantity_total_3 + $rt_quantity_total_4;
        $rt_price_total = $rt_price_total_1 + $rt_price_total_2 + $rt_price_total_3 + $rt_price_total_4;


        if( $rt_quantity_total ) {

            $gl_quantity = $gl_quantity_total - $rt_quantity_total;

            $gl_price_total = apply_filters( 'ovacrs_price_global_has_special_time', ovacrs_price_global_has_special_time( $product_id, $rent_time, $rt_quantity_total ) );

            $line_total = $gl_quantity * $gl_price_total + $rt_price_total;

            if ( $price_type === "mixed" ) {

                $rt_quantity_total_mix  = $rt_quantity_total_mix_1 + $rt_quantity_total_mix_2 + $rt_quantity_total_mix_3 + $rt_quantity_total_mix_4;
                $rt_price_total_mix     = $rt_price_total_mix_1 + $rt_price_total_mix_2 + $rt_price_total_mix_3 + $rt_price_total_mix_4;

                $gl_price_total = ovacrs_price_global_has_special_time( $product_id, $rent_time, $rt_quantity_total_mix );

                $gl_quantity_mix = $quantity_day - $rt_quantity_total_mix;

                $line_total = $gl_quantity_mix * $gl_price_total + $rt_price_total_mix + $rt_price_hour_mix * $quantity_hour;

            }
        }

    }

    return array( 'quantity' => $quantity, 'line_total' => $line_total );
}



if( ! function_exists( 'ovacrs_get_total_price_by_start_end_date' ) ) {
    function ovacrs_get_total_price_by_start_end_date( $product_id, $start_date, $end_date, $id_package = '', $cart_item=[] ) {

        if( is_array( $cart_item ) && ! empty( $cart_item ) ) {
            $product_id = $cart_item['product_id'];
            $rental_type = ( isset( $cart_item['rental_type'] ) && array_key_exists( 'rental_type', $cart_item ) ) ? $cart_item['rental_type'] : '';
        } else {
            $product_id = $product_id;
            $rental_type = get_post_meta( $product_id, 'ovacrs_price_type', true );
        }

        $ovacrs_pickup_date = strtotime( $start_date );
        $ovacrs_pickoff_date = strtotime( $end_date );

        $rent_time = get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date );
        
        if( $rental_type == 'period_time' ){

            if( is_array( $cart_item ) && ! empty( $cart_item ) ) {
                 $ovacrs_period_price = $cart_item['period_price'];

                 $ovacrs_resource = $cart_item['resources'];
            } else {

                if( $id_package ) {
                    $ovacrs_period_package_id = $id_package;
                } else {
                    $ovacrs_period_package_id = isset( $_POST['ovacrs_period_package_id'] ) ? sanitize_text_field( $_POST['ovacrs_period_package_id'] ) : '' ;
                }

                $rental_info_period = get_rental_info_period( $product_id, $ovacrs_pickup_date, $rental_type, $ovacrs_period_package_id );
                $ovacrs_period_price = $rental_info_period['period_price'];

                $ovacrs_resource =  isset( $_POST['ovacrs_resource_checkboxs'] ) ? $_POST['ovacrs_resource_checkboxs'] : [];
            }

            $quantity = 1;
            $line_total = floatval( $ovacrs_period_price );

            $ovacrs_amount_insurance = floatval(get_post_meta( $product_id, 'ovacrs_amount_insurance', true ));
            $line_total +=  $ovacrs_amount_insurance;

            $resource_id = get_post_meta( $product_id, 'ovacrs_resource_id', true );
            $resource_price = get_post_meta( $product_id, 'ovacrs_resource_price', true );
            $resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );

            if( is_array( $ovacrs_resource ) && ! empty( $ovacrs_resource ) ){
                foreach ( $ovacrs_resource as $key_c_re => $value_c_re) {
                    foreach ($resource_id as $key_id => $value_id) {
                        if( $key_c_re ==  $value_id ){

                            if( $resource_duration_type[$key_id] == 'total' ){
                                $line_total = $line_total + $resource_price[$key_id];
                            }else if( $resource_duration_type[$key_id] == 'days' ){

                                $line_total = $line_total + $resource_price[$key_id] * $quantity;

                            }if( $resource_duration_type[$key_id] == 'hours' ){

                                if( $rent_time['rent_time_day_raw'] < 1 ){
                                    $line_total = $line_total + $resource_price[$key_id] * $quantity;
                                }else{
                                    $line_total = $line_total + $resource_price[$key_id] * $quantity*24;
                                }

                            }

                        }
                    }
                }
            }

        } else {

            $get_price_by_date = get_price_by_date( $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date );


            $quantity = $get_price_by_date['quantity'];
            $line_total = $get_price_by_date['line_total'];


            $ovacrs_amount_insurance = floatval(get_post_meta( $product_id, 'ovacrs_amount_insurance', true ));
            $line_total +=  $ovacrs_amount_insurance;

            if( is_array( $cart_item ) && ! empty( $cart_item ) ) {
                $ovacrs_resource = $cart_item['resources'];
            } else {
                $ovacrs_resource =  isset( $_POST['ovacrs_resource_checkboxs'] ) ? $_POST['ovacrs_resource_checkboxs'] : [];
            }



            /* Price = Price + Resource Price - by Resource ********************************************/
            $resource_id = get_post_meta( $product_id, 'ovacrs_resource_id', true );
            $resource_price = get_post_meta( $product_id, 'ovacrs_resource_price', true );
            $resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );

            if( $ovacrs_resource ){
                foreach ( $ovacrs_resource as $key_c_re => $value_c_re) {
                    foreach ($resource_id as $key_id => $value_id) {
                        if( $key_c_re ==  $value_id ){

                            if( $resource_duration_type[$key_id] == 'total' ){
                                $line_total = $line_total + $resource_price[$key_id];
                            }else if( $resource_duration_type[$key_id] == 'days' ){

                                $line_total = $line_total + $resource_price[$key_id] * $quantity;

                            }if( $resource_duration_type[$key_id] == 'hours' ){

                                if( $rent_time['rent_time_day_raw'] < 1 ){
                                    $line_total = $line_total + $resource_price[$key_id] * $quantity;
                                }else{
                                    $line_total = $line_total + $resource_price[$key_id] * $quantity*24;
                                }

                            }


                        }
                    }
                }
            }

        }

        return [ 'quantity' => $quantity, 'line_total' => $line_total, 'amount_insurance' => $ovacrs_amount_insurance ];
    }
}




function ovacrs_get_price_by_start_date_transport( $product_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc ) {
    $list_price_transport = ovacrs_get_list_price_loc_transport($product_id);
    $price_transport = 0;
    if( ! empty( $list_price_transport ) && is_array( $list_price_transport ) ) {
        foreach( $list_price_transport as $pickup => $dropoff_price_arr ) {
            if( $ovacrs_pickup_loc == $pickup && ! empty( $dropoff_price_arr ) && is_array( $dropoff_price_arr ) ) {
                foreach( $dropoff_price_arr as $dropoff => $price ) {
                    if( $ovacrs_pickoff_loc ==  $dropoff ) {
                        $price_transport = $price;
                    }
                }
            }
        }
    }
    return $price_transport;

}

function ovacrs_get_total_price_by_start_date_transport( $product_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc, $cart_item = [] ) {
    $price_transport = ovacrs_get_price_by_start_date_transport( $product_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc );
    $ovacrs_amount_insurance = floatval(get_post_meta( $product_id, 'ovacrs_amount_insurance', true ));

    if( ! empty( $cart_item ) ) {
        $ovacrs_resource = $cart_item['resources'];
    } else {
        $ovacrs_resource = [];
    }

    $line_total = $price_transport;

    

    /* Price = Price + Resource Price - by Resource ********************************************/
    $resource_id = get_post_meta( $product_id, 'ovacrs_resource_id', true );
    $resource_price = get_post_meta( $product_id, 'ovacrs_resource_price', true );
    $resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );


    if( $ovacrs_resource ){
        foreach ( $ovacrs_resource as $key_c_re => $value_c_re) {
            foreach ($resource_id as $key_id => $value_id) {
                if( $key_c_re ==  $value_id ){

                    if( $resource_duration_type[$key_id] == 'total' ){
                        $line_total = $line_total + $resource_price[$key_id];

                    }else if( $resource_duration_type[$key_id] == 'days' ){

                        $line_total = $line_total + $resource_price[$key_id] * $quantity;
                        
                    }if( $resource_duration_type[$key_id] == 'hours' ){
                        $line_total = $line_total + $resource_price[$key_id] * $quantity;
                    }

                }
            }
        }
    }    

    return [ 'quantity' => 1, 'line_total' => floatval( $line_total ), 'amount_insurance' => floatval( $ovacrs_amount_insurance ) ];
}

// Get Real Price
function get_real_price_detail( $product_price, $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date ){

    $rent_time = get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date );
    $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

    $ovacrs_rt_startdate = get_post_meta( $product_id, 'ovacrs_rt_startdate', true );
    $ovacrs_rt_enddate = get_post_meta( $product_id, 'ovacrs_rt_enddate', true );


        // Global
    $gl_price = ovacrs_price_global( $product_id, $rent_time );
    $product_price =  $gl_price ;


    if( $ovacrs_rt_startdate ){
        foreach ($ovacrs_rt_startdate as $key_rt => $value_rt) {

                // If Special_Time_Start_Date <= pickup_date && pickoff_date <= Special_Time_End_Date
            if( $ovacrs_pickup_date >= strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickoff_date <= strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                $rt_price = ovacrs_price_special_time( $product_id, $rent_time, $key_rt );

                $product_price =  $rt_price.' '.ovacrs_text_time_rt( $price_type, $rent_time );

                break;
                
            }else if( $ovacrs_pickup_date < strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickoff_date <= strtotime( $ovacrs_rt_enddate[$key_rt] ) && $ovacrs_pickoff_date >= strtotime( $ovacrs_rt_startdate[$key_rt] ) ){


                $gl_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $ovacrs_rt_startdate[$key_rt] ) );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity_array );

                $rt_quantity_array = get_time_bew_2day( strtotime( $ovacrs_rt_startdate[$key_rt] ), $ovacrs_pickoff_date );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity_array, $key_rt );

                $product_price =  $gl_price .' '.ovacrs_text_time_gl( $price_type, $rent_time ).' ' . $rt_price  .' '.ovacrs_text_time_rt( $price_type, $rent_time );

                break;


            }else if( $ovacrs_pickup_date >= strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickup_date <= strtotime( $ovacrs_rt_enddate[$key_rt] ) && $ovacrs_pickoff_date >= strtotime( $ovacrs_rt_enddate[$key_rt] ) ){


                $rt_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $ovacrs_rt_enddate[$key_rt] ) );
                $rt_price = ovacrs_price_special_time( $product_id, $rt_quantity_array, $key_rt );


                $gl_quantity_array = get_time_bew_2day( strtotime( $ovacrs_rt_enddate[$key_rt] ), $ovacrs_pickoff_date );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity_array );


                $product_price =  $gl_price . ' ' . ovacrs_text_time_gl( $price_type, $rent_time ) . ' ' . $rt_price . ' ' . ovacrs_text_time_rt( $price_type, $rent_time );

                break;

            }else if( $ovacrs_pickup_date < strtotime( $ovacrs_rt_startdate[$key_rt] ) && $ovacrs_pickoff_date > strtotime( $ovacrs_rt_enddate[$key_rt] ) ){

                    // Time section 1
                $gl_quantity_array = get_time_bew_2day( $ovacrs_pickup_date, strtotime( $ovacrs_rt_startdate[$key_rt] ) );
                $gl_price = ovacrs_price_global( $product_id, $gl_quantity_array );


                $rent_time_2 = get_time_bew_2day( strtotime( $ovacrs_rt_startdate[$key_rt] ), strtotime( $ovacrs_rt_enddate[$key_rt] ) );
                $rt_price = ovacrs_price_special_time( $product_id, $rent_time_2, $key_rt );

                $product_price = $rt_price . ' ' . ovacrs_text_time_rt( $price_type, $rent_time ) . ' ' . $gl_price . ' ' . ovacrs_text_time_gl( $price_type, $rent_time );

                break;

            }

        }
    }

    return $product_price;
}

