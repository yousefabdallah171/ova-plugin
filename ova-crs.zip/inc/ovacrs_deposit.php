<?php 
defined( 'ABSPATH' ) || exit();

// Add row To pay, Remaining in Cart page
add_action( 'woocommerce_cart_totals_after_order_total',  'ovacrs_display_deposit' ); 
// Add row To pay, Remaining in checkout page
add_action( 'woocommerce_review_order_after_order_total', 'ovacrs_display_deposit' );

// Display deposit
if ( ! function_exists( 'ovacrs_display_deposit' ) ) {
    function ovacrs_display_deposit() {
        $has_deposit = isset(WC()->cart->deposit_info[ '_ova_has_deposit' ]) ? WC()->cart->deposit_info[ '_ova_has_deposit' ] : '';

        if ( isset( WC()->cart->deposit_info[ 'ova_deposit_amount' ] ) && $has_deposit ):
            $total              = WC()->cart->total;
            $deposit_amount     = WC()->cart->deposit_info[ 'ova_deposit_amount' ];
            $remaining_amount   = WC()->cart->deposit_info[ 'ova_remaining_amount' ];
        ?>
            <tr class="order-paid">
                <th><?php esc_html_e('To Pay','ova-crs'); ?></th>
                <td data-title="<?php esc_html_e('To Pay','ova-crs'); ?>">
                    <strong><?php echo wc_price ( $total ); ?></strong></td>
            </tr>
            <tr class="order-remaining">
                <th><?php esc_html_e('Remaining','ova-crs'); ?></th>
                <td data-title="<?php esc_html_e('Remaining','ova-crs'); ?>">
                    <strong><?php echo wc_price( $remaining_amount ); ?></strong></td>
            </tr>
        <?php endif;
    }
}

// Add row To pay, Remaining in success checkout 
add_filter( 'woocommerce_get_order_item_totals', 'ovacrs_get_order_item_totals', 10, 3 );
if ( ! function_exists( 'ovacrs_get_order_item_totals' ) ) {
    function ovacrs_get_order_item_totals( $total_rows, $order, $tax_display ) {
        $has_deposit        = $order->get_meta( '_ova_has_deposit' , true );
        $deposit_amount     = floatval( $order->get_meta( '_ova_deposit_amount' , true ) );
        $remaining_amount   = floatval( $order->get_meta( '_ova_remaining_amount' , true ) );

        if ( $has_deposit ) {
            if ( is_checkout() ) {
                $total_rows[ 'deposit_amount' ] = array(
                    'label' => esc_html__('To Pay:', 'ova-crs'),
                    'value' => wc_price( $deposit_amount , array( 'currency' => $order->get_currency() ) )
                );
                $total_rows[ 'remaining_amount' ] = array(
                    'label' => esc_html__('Remaining:', 'ova-crs'),
                    'value' => wc_price( $remaining_amount , array( 'currency' => $order->get_currency() ) )
                );
            }
        }

        return $total_rows;
    }
}

// Set price is deposit amount and set_meta data (deposit amount, remaining);
add_action( 'woocommerce_checkout_order_processed', 'ovacrs_checkout_order_processed', 10, 3 );
if ( ! function_exists( 'ovacrs_checkout_order_processed' ) ) {
    function ovacrs_checkout_order_processed( $order_id, $posted_data, $order ) {
        $has_deposit        = isset( WC()->cart->deposit_info[ '_ova_has_deposit' ] ) ? WC()->cart->deposit_info[ '_ova_has_deposit' ] : '';
        $insurance_amount   = isset( WC()->cart->deposit_info['ova_insurance_amount'] ) ? WC()->cart->deposit_info['ova_insurance_amount'] : 0;

        // Order add insurance amount
        if ( $insurance_amount ) {
            $order->add_meta_data( '_ova_insurance_amount', $insurance_amount, true );
        } else {
            $order->delete_meta_data( '_ova_insurance_amount' );
        }

        // Order add deposit info
        if ( $has_deposit ) {
            $original_total     = WC()->cart->total;
            $remaining_amount   = isset( WC()->cart->deposit_info['ova_remaining_amount'] ) ? WC()->cart->deposit_info['ova_remaining_amount'] : 0;

            $order->set_total( $original_total );
            $order->add_meta_data( '_ova_has_deposit', $has_deposit, true );
            $order->add_meta_data( '_ova_deposit_amount', $original_total, true );
            $order->add_meta_data( '_ova_remaining_amount', $remaining_amount, true );
            $order->add_meta_data( '_ova_original_total', $original_total, true );
            $order->save();
        } else {
            $order->delete_meta_data( '_ova_has_deposit' );
            $order->delete_meta_data( '_ova_deposit_amount' );
            $order->delete_meta_data( '_ova_remaining_amount' );
            $order->delete_meta_data( '_ova_original_total' );
            $order->save();
        }
    }
}

// Set total original if has deposit display total is checkout page, else set_total to display is order admin page
add_filter( 'woocommerce_order_get_total' ,'ovacrs_get_order_total', 10, 2 );
if ( ! function_exists( 'ovacrs_get_order_total' ) ) {
    function ovacrs_get_order_total( $total , $order ) {
        $has_deposit = $order->get_meta( '_ova_has_deposit' , true );
        $original_total = $order->get_meta( '_ova_original_total' , true );
        if ( $has_deposit && ! did_action( 'valid-paypal-standard-ipn-request' ) && ( is_order_received_page()  || ! is_checkout() ) )  {
            $total = $original_total;
            $order->set_total( $total );
        } 

        return $total;
    }
}

// Add custom order columns
add_filter( 'manage_edit-shop_order_columns', 'ovacrs_add_custom_order_column' );
add_filter( 'woocommerce_shop_order_list_table_columns', 'ovacrs_add_custom_order_column' );
if ( ! function_exists( 'ovacrs_add_custom_order_column' ) ) {
    function ovacrs_add_custom_order_column( $columns ) {
        $new_columns = array();

        foreach ( $columns as $key => $column ) {
            if ( $key === 'order_total' ) {
                $new_columns['ova_deposit_column']      = esc_html__( 'Deposit', 'ova-crs' );
                $new_columns['ova_remaining_column']    = esc_html__( 'Remaining', 'ova-crs' );
                $new_columns['ova_deposit_status']      = esc_html__( 'Deposit status', 'ova-crs' );
                $new_columns['ova_insurance_status']    = esc_html__( 'Insurance status', 'ova-crs' );
            }

            $new_columns[$key] = $column;
        }

        return $new_columns;
    }
}

// Add custom order posts columns
add_action( 'manage_shop_order_posts_custom_column', 'ovacrs_order_posts_custom_column', 10, 2 );
add_action( 'manage_woocommerce_page_wc-orders_custom_column', 'ovacrs_order_posts_custom_column', 10, 2 );
if ( ! function_exists( 'ovacrs_order_posts_custom_column' ) ) {
    function ovacrs_order_posts_custom_column( $column_id, $order ) {
        // For woocommerce order legacy
        if ( is_numeric( $order ) ) {
            $order = wc_get_order( $order );
        }
        // End
        
        if ( $order ) {
            // Deposit amount
            if ( 'ova_deposit_column' === $column_id ) {
                $deposit_amount = floatval( $order->get_meta( '_ova_deposit_amount' , true ) );

                if ( $deposit_amount ): ?>
                    <span class="tips ova_deposit_amount">
                        <?php echo wc_price( $deposit_amount, array( 'currency' => $order->get_currency() ) ); ?>
                    </span>
                <?php endif;
            }

            // Remaining amount
            if ( 'ova_remaining_column' === $column_id ) {
                $remaining_amount = floatval( $order->get_meta( '_ova_remaining_amount' , true ) );

                if ( $remaining_amount ): ?>
                    <span class="tips ova_remaining_amount">
                        <?php echo wc_price( $remaining_amount, array( 'currency' => $order->get_currency() ) ); ?>
                    </span>
                <?php endif;
            }

            // Deposit status
            if ( 'ova_deposit_status' === $column_id ) {
                $has_deposit        = $order->get_meta( '_ova_has_deposit' , true );
                $remaining_amount   = floatval( $order->get_meta( '_ova_remaining_amount' , true ) );

                if ( $has_deposit ) {
                    if ( $remaining_amount ): ?>
                        <span class="ova_amount_status_deposit_column ova_pending">
                            <?php esc_html_e( 'Pending Payment', 'ova-crs' ); ?>
                        </span>
                    <?php else: ?>
                        <span class="ova_amount_status_deposit_column ova_paid">
                            <?php esc_html_e( 'Paid', 'ova-crs' ); ?>
                        </span>
                    <?php endif;
                }
            }

            // Insurance status
            if ( 'ova_insurance_status' === $column_id ) {
                $insurance_amount = $order->get_meta( '_ova_insurance_amount', true );

                if ( $insurance_amount !== '' ) {
                    if ( floatval( $insurance_amount ) ): ?>
                        <span class="ova_amount_status_deposit_column ova_pending">
                            <?php esc_html_e( 'Pending Payment', 'ova-crs' ); ?>
                        </span>
                    <?php else: ?>
                        <span class="ova_amount_status_insurance_column ova_paid">
                            <?php esc_html_e( 'Paid', 'ova-crs' ); ?>
                        </span>
                    <?php endif;
                }
            }
        }
    }
}

// Add column and display Deposit amount and Remaining amount in detail order
add_action( 'woocommerce_admin_order_item_headers', 'ovacrs_admin_order_item_headers' );
add_action( 'woocommerce_admin_order_item_values', 'ovacrs_admin_order_item_values', 10, 3 );
if ( ! function_exists( 'ovacrs_admin_order_item_headers' ) ) {
    function ovacrs_admin_order_item_headers( $order ) {
        if ( ! $order ) return;

        // Insurance amount
        $insurance_amount = $order->get_meta( '_ova_insurance_amount' , true );

        if ( $insurance_amount !== '' ): ?>
            <th class="insurance-amount"><?php esc_html_e( 'Insurance' , 'ova-crs' ); ?></th>
        <?php endif;

        // Has deposit
        $has_deposit = $order->get_meta( '_ova_has_deposit' , true );

        if ( $has_deposit ): ?>
            <th class="deposit-paid"><?php esc_html_e( 'Deposit' , 'ova-crs' ); ?></th>
            <th class="deposit-remaining"><?php esc_html_e( 'Remaining' , 'ova-crs' ); ?></th>
        <?php endif;
    }
}
if ( ! function_exists( 'ovacrs_admin_order_item_values' ) ) {
    function ovacrs_admin_order_item_values( $product, $item, $item_id ) {
        if ( in_array( $item->get_type(), array( 'fee', 'shop_order_refund' ) ) ) {
            $parent_order = false;

            if ( 'shop_order_refund' === $item->get_type() ) {
                $parent_order = wc_get_order( $item->get_parent_id() );
            }
            if ( 'fee' === $item->get_type() ) {
                $parent_order = $item->get_order();
            }

            if ( $parent_order && is_object( $parent_order ) ) {
                $insurance_amount   = $parent_order->get_meta( '_ova_insurance_amount' , true );
                $has_deposit        = $parent_order->get_meta( '_ova_has_deposit' , true );

                if ( $insurance_amount !== '' ): ?>
                    <td class="ova-amount-insurance" width="1%"></td>
                <?php endif;

                if ( $has_deposit ): ?>
                    <td class="ova-deposit-paid" width="1%"></td>
                    <td class="deposit-remaining" width="1%"></td>
                <?php endif;
            }

            return;
        }

        $order = $item->get_order();
        if ( ! $order ) return;

        $insurance_amount   = $order->get_meta( '_ova_insurance_amount' , true );
        $has_deposit        = $order->get_meta( '_ova_has_deposit' , true );
        $item_insurance     = floatval( $item->get_meta( 'ovacrs_amount_insurance_product', true ) );
        $item_deposit       = floatval( $item->get_meta( 'ovacrs_deposit_amount_product', true ) );
        $item_remaining     = floatval( $item->get_meta( 'ovacrs_remaining_amount_product', true ) );

        // Insurance
        if ( $insurance_amount !== '' ): ?>
            <td class="ova-amount-insurance" width="1%">
                <div class="view">
                    <?php if ( $item_insurance ) {
                        echo wc_price( $item_insurance, array( 'currency' => $order->get_currency() ) );
                    } ?>
                </div>
                <?php if ( $product && $item_remaining <= 0 ): ?>
                    <div class="edit" style="display: none;">
                       <input
                            type="text"
                            name="amount_insurance[<?php echo absint( $item_id ); ?>]"
                            placeholder="<?php echo wc_format_localized_price( 0 ); ?>"
                            value="<?php echo esc_attr( $item_insurance ); ?>"
                            class="amount_insurance wc_input_price"
                            data-total="<?php echo esc_attr( $item_insurance ); ?>"
                        />
                    </div>
                <?php endif; ?>
            </td>
        <?php endif;

        // Deposit
        if ( $has_deposit ): ?>
            <td class="ova-deposit-paid" width="1%">
                <div class="view">
                    <?php if ( $item_deposit ) {
                        echo wc_price( $item_deposit, array( 'currency' => $order->get_currency() ) );
                    } ?>
                </div>
                <?php if ( $product ): ?>
                    <div class="edit" style="display: none;">
                        <input
                            type="text"
                            name="amount_deposit[<?php echo absint( $item_id ); ?>]"
                            placeholder="<?php echo wc_format_localized_price( 0 ); ?>"
                            value="<?php echo esc_attr( $item_deposit ); ?>"
                            class="amount_deposit wc_input_price"
                            data-total="<?php echo esc_attr( $item_deposit ); ?>"
                        />
                    </div>
                <?php endif; ?>
            </td>
            <td class="deposit-remaining" width="1%">
                <div class="view">
                    <?php if ( $item_remaining ) {
                        echo wc_price( $item_remaining, array( 'currency' => $order->get_currency() ) );
                    } ?>
                </div>
                <?php if ( $product ): ?>
                    <div class="edit" style="display: none;">
                        <input
                            type="text"
                            name="amount_remaining[<?php echo absint( $item_id ); ?>]"
                            placeholder="<?php echo wc_format_localized_price( 0 ); ?>"
                            value="<?php echo esc_attr( $item_remaining ); ?>"
                            class="amount_remaining wc_input_price"
                            data-total="<?php echo esc_attr( $item_remaining ); ?>"
                            disabled="disabled"
                        />
                    </div>
                <?php endif; ?>
            </td>
        <?php endif;
    }
}

// Dissplay total deposit and total ramaining in order detail
add_action( 'woocommerce_admin_order_totals_after_total' , 'ovacrs_admin_order_totals_after_total' );
if ( ! function_exists( 'ovacrs_admin_order_totals_after_total' ) ) {
    function ovacrs_admin_order_totals_after_total( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return;

        // Get order insurance amount
        $insurance_amount = floatval( $order->get_meta( '_ova_insurance_amount', true ) );

        if ( $insurance_amount ): ?>
            <tr>
                <td class="label">
                    <?php esc_html_e( ' Total Insurance Amount', 'ova-crs' ); ?>:</td>
                <td width="1%"></td>
                <td class="total">
                    <?php echo wc_price( $insurance_amount, array( 'currency' => $order->get_currency() ) ); ?>
                </td>
            </tr>
        <?php endif;

        // Has deposit
        $has_deposit        = $order->get_meta( '_ova_has_deposit' , true );
        $deposit_amount     = floatval( $order->get_meta( '_ova_deposit_amount' , true ) );
        $remaining_amount   = floatval( $order->get_meta( '_ova_remaining_amount' , true ) );

        if ( $has_deposit ): ?>
            <tr>
                <td class="label">
                    <?php esc_html_e( 'Total Deposit Amount', 'ova-crs' ); ?>
                </td>
                <td width="1%"></td>
                <td class="total">
                    <?php echo wc_price( $deposit_amount, array( 'currency' => $order->get_currency() ) ); ?>
                </td>
            </tr>
            <tr>
                <td class="label">
                    <?php esc_html_e( 'Total Remaining Amount', 'ova-crs' ); ?>:</td>
                <td width="1%"></td>
                <td class="total">
                    <?php echo wc_price( $remaining_amount, array( 'currency' => $order->get_currency() ) ); ?>
                </td>
            </tr>
        <?php endif;
    }
}

// Update items order in backend
add_action( 'woocommerce_saved_order_items' , 'ovacrs_saved_order_items' , 10 , 2 );
if ( ! function_exists( 'ovacrs_saved_order_items' ) ) {
    function ovacrs_saved_order_items( $order_id, $items ) {
        $order = wc_get_order( $order_id );
        $order->read_meta_data( true );

        $has_deposit        = $order->get_meta( '_ova_has_deposit' , true );
        $data_insurances    = isset( $items[ 'amount_insurance' ] ) ? $items[ 'amount_insurance' ] : array();
        $data_deposits      = isset( $items[ 'amount_deposit' ] ) ? $items[ 'amount_deposit' ] : array();
        $total_order        = $total_deposit_amount = $total_remaining_amount = $total_insurance_amount = 0;

        if ( isset( $items[ 'order_item_id' ] ) && $_POST[ 'action' ] === 'woocommerce_save_order_items' && ( $has_deposit || ! empty( $data_insurances ) ) ) {
            if ( $has_deposit ) {
                foreach ( $items[ 'order_item_id' ] as $item_id ) {
                    $item = WC_Order_Factory::get_order_item( absint( $item_id ) );

                    if ( ! $item ) {
                        continue;
                    }

                    $sub_remaining      = 0;
                    $item_deposit       = isset( $data_deposits[ $item_id ] ) ? floatval( wc_format_decimal( $data_deposits[ $item_id ] ) ) : null;
                    $item_remaining     = floatval( $item->get_meta( 'ovacrs_remaining_amount_product', true ) );
                    $item_total         = floatval( $item->get_total() );
                    $original_deposit   = floatval( $item->get_meta( 'ovacrs_deposit_amount_product', true ) );

                    if ( $item_deposit !== null ) {
                        $sub_remaining = $item_deposit - $item_total;

                        $item->update_meta_data( 'ovacrs_deposit_amount_product', $item_deposit );
                        $item->update_meta_data( 'ovacrs_remaining_amount_product', $item_remaining - $sub_remaining );
                        $item->set_total( $item_deposit );
                        $item->set_subtotal( $item_deposit );

                        // Save item
                        $item->save();
                    }
                    
                    // Insurance
                    if ( isset( $data_insurances[ $item_id ] )  ) {
                        $item_insurance = floatval( $item->get_meta( 'ovacrs_amount_insurance_product', true ) );
                        $new_insurance  = floatval( $data_insurances[ $item_id ] ) - $item_insurance;

                        // Update amount insurance
                        $item->update_meta_data( 'ovacrs_amount_insurance_product', floatval( $data_insurances[ $item_id ] ) );

                        // Update deposit, total
                        $item->update_meta_data( 'ovacrs_deposit_amount_product', $item_deposit + $new_insurance );
                        $item->set_total( $item_deposit + $new_insurance );
                        $item->set_subtotal( $item_deposit + $new_insurance );

                        // Save item
                        $item->save();
                    }

                    $item_total         = $item->get_total();
                    $insurance_amount   = floatval( $item->get_meta( 'ovacrs_amount_insurance_product', true ) );
                    $deposit_amount     = floatval( $item->get_meta( 'ovacrs_deposit_amount_product', true ) );
                    $remaining_amount   = floatval( $item->get_meta( 'ovacrs_remaining_amount_product', true ) );

                    $total_order            += $item_total;
                    $total_insurance_amount += $insurance_amount;
                    $total_deposit_amount   += $deposit_amount;
                    $total_remaining_amount += $remaining_amount;
                }

                $order->update_meta_data( '_ova_insurance_amount', $total_insurance_amount );
                $order->update_meta_data( '_ova_deposit_amount', $total_deposit_amount );
                $order->update_meta_data( '_ova_remaining_amount', $total_remaining_amount );
                $order->update_meta_data( '_ova_original_total', $total_deposit_amount );
                $order->set_total( $total_order );
                $order->save();
            } elseif ( ! empty( $data_insurances ) ) {
                foreach ( $items[ 'order_item_id' ] as $item_id ) {
                    $item = WC_Order_Factory::get_order_item( absint( $item_id ) );

                    if ( ! $item ) {
                        continue;
                    }

                    if ( isset( $data_insurances[ $item_id ] )  ) {
                        $item_insurance = floatval( $item->get_meta( 'ovacrs_amount_insurance_product', true ) );
                        $new_insurance  = floatval( $data_insurances[ $item_id ] ) - $item_insurance;

                        // Update amount insurance
                        $item->update_meta_data( 'ovacrs_amount_insurance_product', floatval( $data_insurances[ $item_id ] ) );

                        // Get item total
                        $item_total = $item->get_total();

                        $item->set_total( $item_total + $new_insurance );
                        $item->set_subtotal( $item_total + $new_insurance );

                        // Save item
                        $item->save();
                    }

                    $item_total             = $item->get_total();
                    $insurance_amount       = floatval( $item->get_meta( 'ovacrs_amount_insurance_product', true ) );
                    $total_order            += $item_total;
                    $total_insurance_amount += $insurance_amount;
                }

                $order->update_meta_data( '_ova_insurance_amount', $total_insurance_amount );
                $order->set_total( $total_order );
                $order->save();
            }
        }
    }
}