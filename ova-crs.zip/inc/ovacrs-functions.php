<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'dd' ) ) {
	function dd( ...$args ) {
		echo '<pre>';
		var_dump( ...$args );
		echo '</pre>';
		die;
	}
}

if( !function_exists( 'ovacrs_locate_template' ) ){
	function ovacrs_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovacrs-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ovacrs-templates/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVACRS_PLUGIN_PATH . 'ovacrs-templates/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			// ,$template_name
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovacrs_locate_template', $template, $template_name, $template_path, $default_path );
	}

}


function ovacrs_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;
	$template_file = ovacrs_locate_template( $template_name, $tempate_path, $default_path );
	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	
	include $template_file;
}

function ovacrs_woo_wp_select_multiple( $field ) {
    global $thepostid, $post, $woocommerce;

    $thepostid              = empty( $thepostid ) ? $post->ID : $thepostid;
    $field['class']         = isset( $field['class'] ) ? $field['class'] : 'select short';
    $field['wrapper_class'] = isset( $field['wrapper_class'] ) ? $field['wrapper_class'] : '';
    $field['name']          = isset( $field['name'] ) ? $field['name'] : $field['id'];
    $field['value']         = isset( $field['value'] ) ? $field['value'] : ( get_post_meta( $thepostid, $field['id'], true ) ? get_post_meta( $thepostid, $field['id'], true ) : array() );

    echo '<p class="form-field ' . esc_attr( $field['id'] ) . '_field ' . esc_attr( $field['wrapper_class'] ) . '"><label for="' . esc_attr( $field['id'] ) . '">' . wp_kses_post( $field['label'] ) . '</label><select id="' . esc_attr( $field['id'] ) . '" name="' . esc_attr( $field['name'] ) . '" class="' . esc_attr( $field['class'] ) . '" multiple="multiple">';

    foreach ( $field['options'] as $key => $value ) {

        echo '<option value="' . esc_attr( $key ) . '" ' . ( in_array( $key, $field['value'] ) ? 'selected="selected"' : '' ) . '>' . esc_html( $value ) . '</option>';

    }

    echo '</select> ';

    if ( ! empty( $field['description'] ) ) {

        if ( isset( $field['desc_tip'] ) && false !== $field['desc_tip'] ) {
            echo '<img class="help_tip" data-tip="' . esc_attr( $field['description'] ) . '" src="' . esc_url( WC()->plugin_url() ) . '/assets/images/help.png" height="16" width="16" />';
        } else {
            echo '<span class="description">' . wp_kses_post( $field['description'] ) . '</span>';
        }

    }
    echo '</p>';
}

if( ! function_exists( 'ovacrs_get_list_field_checkout' ) ) {
	function ovacrs_get_list_field_checkout( $post_id ) {
		if( ! $post_id ) return [];
		$ovacrs_manage_custom_checkout_field = get_post_meta( $post_id, 'ovacrs_manage_custom_checkout_field', true );
		$list_field_checkout = get_option( 'ovacrs_booking_form', array() );
		$list_field_checkout_in_product = get_post_meta( $post_id, 'ovacrs_product_custom_checkout_field', true );
		$list_field_checkout_in_product_arr = explode( ',', $list_field_checkout_in_product );
		$list_field_checkout_in_product_arr = array_map( 'trim', $list_field_checkout_in_product_arr );


		if( $ovacrs_manage_custom_checkout_field === 'new' ) {
			$list_ckf_output = [];
			if( ! empty( $list_field_checkout_in_product_arr ) && is_array( $list_field_checkout_in_product_arr ) ) {
				foreach( $list_field_checkout_in_product_arr as $field_name ) {
					if( array_key_exists( $field_name, $list_field_checkout ) ) {
						$list_ckf_output[$field_name] = $list_field_checkout[$field_name];
					}
				}
			} 
		} else {
			$list_ckf_output = $list_field_checkout;
		}
		return $list_ckf_output;
	}
}

if( !function_exists('ovacrs_order_status') ){
	function ovacrs_order_status(){
		return apply_filters( 'ovacrs_order_status', array( 'wc-completed', 'wc-processing' ) );		
	}
}

// Get Array Product ID with WPML
function get_arr_product_ids( $product_id_original ){
	$translated_ids = Array();

	if ( $product_id_original ) {
		// get plugin active
		$active_plugins = get_option('active_plugins');

		if ( in_array ( 'polylang/polylang.php', $active_plugins ) || in_array ( 'polylang-pro/polylang.php', $active_plugins ) ) {
			$languages = pll_languages_list();

			if ( ! isset( $languages ) ) return;

			foreach ( $languages as $lang ) {
				$product_id = pll_get_post($product_id_original, $lang);

				if ( $product_id ) {
					$translated_ids[] = $product_id;
				}
			}
		} elseif ( in_array ( 'sitepress-multilingual-cms/sitepress.php', $active_plugins ) ) {
			global $sitepress;
		
			if ( ! isset( $sitepress ) ) return;
			
			$trid 			= $sitepress->get_element_trid( $product_id_original, 'post_product' );
			$translations 	= $sitepress->get_element_translations( $trid, 'product' );

			foreach ( $translations as $lang=>$translation ) {
			    $translated_ids[] = $translation->element_id;
			}
		} else {
			$translated_ids[] = $product_id_original;
		}

		if ( empty( $translated_ids ) && $product_id_original ) {
			$translated_ids[] = $product_id_original;
		}
	}

	return apply_filters( 'ovacrs_multiple_languages', $translated_ids );  
}


// Add javascript to wp head
add_action('admin_head', 'ovacrs_hook_javascript');
add_action('wp_head', 'ovacrs_hook_javascript');
function ovacrs_hook_javascript() {
	// Calendar language
	$calendar_language = get_theme_mod( 'calendar_layout', 'en' );
	$wpml_current_lang = apply_filters( 'wpml_current_language', null );
    if ( $wpml_current_lang ) $calendar_language = $wpml_current_lang;

	// Day of week start
	$dayOfWeekStart = apply_filters( 'ovacres_calendar_dayofweekstart', 1 );
    ?>
        <script type="text/javascript">
            var dayOfWeekStart = <?php echo esc_html( $dayOfWeekStart ); ?>;
            var calendarLanguage = '<?php echo esc_attr( $calendar_language ); ?>';
        </script>
    <?php
}

// Check array exists
if ( ! function_exists( 'ovacrs_is_array_exists' ) ) {
	function ovacrs_is_array_exists( $args ) {
		$flag = false;

		if ( ! empty( $args ) && is_array( $args ) ) {
			$flag = true;
		}

		return $flag;
	}
}

// Check vehicle availability by product ID
if ( ! function_exists( 'ovacrs_check_vehicle_available' ) ) {
	function ovacrs_check_vehicle_available( $product_id = false, $pickup_date = '', $dropoff_date = '', $pickup_loc = '', $dropoff_loc = '' ) {
		if ( ! $product_id || ! absint( $pickup_date ) || ! absint( $dropoff_date ) ) return false;

		$flag 			= false;
		$statuses 		= ovacrs_order_status();
		$manage_store 	= get_post_meta( $product_id, 'ovacrs_manage_store', true );
		$stock_qty 		= absint( get_post_meta( $product_id, 'ovacrs_car_count', true ) );

		if ( $manage_store === 'store' ) {
			$stock_qty = absint( get_post_meta( $product_id, 'ovacrs_stock_quantity', true ) );
		}

		// Check Unavailable Time
		$unavailable_time_flag = true;

		$untime_startdate   = get_post_meta( $product_id, 'ovacrs_untime_startdate', true );
        $untime_enddate     = get_post_meta( $product_id, 'ovacrs_untime_enddate', true );

        if ( ovacrs_is_array_exists( $untime_startdate ) && ovacrs_is_array_exists( $untime_enddate ) ) {
        	foreach( $untime_startdate as $k => $time_startdate ) {
        		if ( $time_startdate && isset( $untime_enddate[$k] ) && $untime_enddate[$k] ) {
        			if ( ! ( $dropoff_date < strtotime( $time_startdate ) || strtotime( $untime_enddate[$k] ) < $pickup_date ) ) {
        				$unavailable_time_flag = false;
        				break;
        			}
        		}
        	}
        }

        $rental_booked 	= 0;
        $vehicle_booked = array();

        if ( $unavailable_time_flag ) {
        	$product_ids 	= get_arr_product_ids( $product_id );
        	$orders_ids 	= ovacrs_get_orders_ids_by_product_id( $product_ids, $statuses );

        	// For Order ID
            foreach( $orders_ids as $key => $value ) {
                // Get Order Detail by Order ID
                $order = wc_get_order( $value );

                // Get Meta Data type line_item of Order
                $order_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
               
                // For Meta Data
                foreach( $order_items as $item_id => $item ) {
                    $pickup_date_store 	= $pickoff_date_store = $vehicle_rented = '';
                    $qty_rented_item 	= 0;

                    // Check Line Item have item ID is Car_ID
                    if ( in_array( $item->get_product_id(), $product_ids ) ) {

                        // Check time to Prepare before delivered
                        $prepare_time = get_post_meta( $product_id, 'ovacrs_prepare_vehicle', true ) ? get_post_meta( $product_id, 'ovacrs_prepare_vehicle', true ) * 60 : 0;

                        // Get value of pickup date, pickoff date
                        $pickup_date_store 	= strtotime( $item->get_meta( 'ovacrs_pickup_date' ) );
                        $pickoff_date_store = strtotime( $item->get_meta( 'ovacrs_pickoff_date' ) );

                        if ( $manage_store === 'store' ) {
                        	$qty_rented_item = absint( $item->get_meta( 'ovacrs_quantity' ) );
	                    } else {
	                    	$vehicle_rented = trim( $item->get_meta( 'id_vehicle' ) );
	                    }

                        // Only compare date when "PickOff Date in Store" > "Current Time" becaue "PickOff Date Rent" have to > "Current Time"
                        if ( $pickoff_date_store >= current_time( 'timestamp' ) ) {
                            if ( ! ( $dropoff_date <= $pickup_date_store || $pickoff_date_store <= $pickup_date ) ){
                                if ( $manage_store === 'store' ) {
		                            $rental_booked += $qty_rented_item;
		                        } else {
		                            if ( $vehicle_rented != '' ) {
		                                $vehicle_rented_arr = explode( ',', $vehicle_rented );

		                                foreach( $vehicle_rented_arr as $value ) {
		                                    array_push( $vehicle_booked, $value );    
		                                }
		                            }
		                        }
                            }
                        }
                    }
                }
            }

            if ( $manage_store === 'store' ) {
            	if ( $rental_booked < $stock_qty ) {
            		if ( get_theme_mod( 'use_loc_filter_search', 'true' ) == 'true' ) {
            			if ( ovacrs_check_locations( $product_id, $pickup_loc, $dropoff_loc ) ) {
            				$flag = true;
            			} else {
            				$flag = false;
            			}
            		} else {
            			$flag = true;
            		}
            	}
            } else {

            	if ( count( $vehicle_booked ) < $stock_qty ) {
            		$vehicle_avai = array();

	                // List status untime
	                $vehicle_untime_flag = array();

	                // List status location
	                $vehicle_loc_flag = array();

	                // Get All Vehicle ID of product
	                $id_vehicle_available = get_post_meta( $product_id, 'ovacrs_id_vehicles', true );

	                if ( is_array( $id_vehicle_available ) ) {
	                    // loop vehicle id
	                    foreach( $id_vehicle_available as $key => $value ) {
	                        // Get info of Vehicle ID
	                        $vehicle_avai = ovacrs_get_vehicle_loc_title( $value );

	                        $id_vehicle_untime_startday = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['startdate'] ) : '';
	                        $id_vehicle_untime_enddate  = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['enddate'] ) : '';
	                        $id_vehicle_loc = isset( $vehicle_avai['loc'] ) ? trim( $vehicle_avai['loc'] ) : '';

	                        // Check Untime Vehicle ID if NOT OK
	                        if ( ! ( $dropoff_date <= $id_vehicle_untime_startday || $id_vehicle_untime_enddate <= $pickup_date ) && $id_vehicle_untime_startday != '' && $id_vehicle_untime_enddate != '' ) {
	                                $vehicle_untime_flag[] = 'false';
	                        } else {
	                            $vehicle_untime_flag[] = 'true';
	                        }

	                        // Check Location with Vehicle ID
	                        if ( $pickup_loc != '' && get_theme_mod( 'use_loc_filter_search', 'true' ) == 'true' ) {
	                            if ( $id_vehicle_loc === trim( $pickup_loc ) ) {
	                                $vehicle_loc_flag[] = 'true';    
	                            } else {
	                                $vehicle_loc_flag[] = 'false';    
	                            }
	                        } else {
	                            $vehicle_loc_flag[] = 'true';
	                        }
	                    }
	                   
	                    if ( in_array( 'true', $vehicle_untime_flag ) && in_array( 'true', $vehicle_loc_flag ) ){
	                    	$flag = true;
	                    }
	                }
            	}
            }
        }

        return $flag;
	}
}

// Check Rental by Location
if ( ! function_exists( 'ovacrs_check_product_by_location' ) ) {
	function ovacrs_check_product_by_location( $product_id = false, $pickup_loc = '', $dropoff_loc = '' ) {
		if ( $product_id && ( $pickup_loc || $dropoff_loc ) ) {
			$manage_store 	= get_post_meta( $product_id, 'ovacrs_manage_store', true );
			$rental_type 	= get_post_meta( $product_id, 'ovacrs_price_type', true );

			if ( $manage_store === 'store' ) {
				$ovacrs_pickup_location = $ovacrs_dropoff_location = array();

				if ( $rental_type === 'day' || $rental_type === 'transportation' ) {
					$ovacrs_pickup_location 	= get_post_meta( $product_id, 'ovacrs_pickup_location', true );
					$ovacrs_dropoff_location 	= get_post_meta( $product_id, 'ovacrs_dropoff_location', true );
				}

				if ( $rental_type === 'hour' || $rental_type === 'mixed' || $rental_type === 'period_time' ) {
					$ovacrs_pickup_location 	= get_post_meta( $product_id, 'ovacrs_st_pickup_location', true );
					$ovacrs_dropoff_location 	= get_post_meta( $product_id, 'ovacrs_st_dropoff_location', true );
				}

				if ( ! empty( $ovacrs_pickup_location ) && ! empty( $ovacrs_dropoff_location ) && is_array( $ovacrs_pickup_location ) && is_array( $ovacrs_dropoff_location ) ) {

					if ( $pickup_loc && $dropoff_loc ) {
						foreach ( $ovacrs_pickup_location as $k => $value ) {
							if ( $pickup_loc === $value && isset( $ovacrs_dropoff_location[$k] ) && $ovacrs_dropoff_location[$k] === $dropoff_loc ) {
								return true;
							}
						}
					}

					if ( $pickup_loc && ! $dropoff_loc ) {
						$key_pickup_loc = array_search( $pickup_loc, $ovacrs_pickup_location );

						if ( $key_pickup_loc !== false ) {
							return true;
						}
					}

					if ( ! $pickup_loc && $dropoff_loc ) {
						$key_dropoff_loc = array_search( $dropoff_loc, $ovacrs_pickup_location );

						if ( $key_dropoff_loc !== false ) {
							return true;
						}
					}
				}
			}
		}

		return false;
	}
}


if ( ! function_exists( 'ovacrs_check_locations' ) ) {
	function ovacrs_check_locations( $product_id = false, $pickup_loc = '', $dropoff_loc = '' ) {
		if ( ! $product_id || ! $pickup_loc || ! $dropoff_loc ) return false;

		$flag 				= false;
		$rental_type 		= get_post_meta( $product_id, 'ovacrs_price_type', true );
		$pickup_locations 	= $dropoff_locations = array();

		if ( $rental_type === 'day' || $rental_type === 'transportation' ) {
			$pickup_locations 	= get_post_meta( $product_id, 'ovacrs_pickup_location', true );
			$dropoff_locations 	= get_post_meta( $product_id, 'ovacrs_dropoff_location', true );
		} else {
			$pickup_locations 	= get_post_meta( $product_id, 'ovacrs_st_pickup_location', true );
			$dropoff_locations 	= get_post_meta( $product_id, 'ovacrs_st_dropoff_location', true );
		}

		if ( ovacrs_is_array_exists( $pickup_locations ) && ovacrs_is_array_exists( $dropoff_locations ) ) {
			foreach( $pickup_locations as $k => $loc ) {
				if ( $loc === $pickup_loc && isset( $dropoff_locations[$k] ) && $dropoff_locations[$k] === $dropoff_loc ) {
					$flag = true;
					break;
				}
			}
		}

		return $flag;
	}
}

// Check High-Performance Order Storage for Woocommerce
if ( ! function_exists( 'ovacrs_wc_custom_orders_table_enabled' ) ) {
	function ovacrs_wc_custom_orders_table_enabled() {
		if ( get_option( 'woocommerce_custom_orders_table_enabled', 'no' ) === 'yes' ) {
			return true;
		}

		return false;
	}
}

// Check WPML active
if ( ! function_exists( 'ovacrs_is_wpml_active' ) ) {
	function ovacrs_is_wpml_active() {
		if ( is_plugin_active( 'sitepress-multilingual-cms/sitepress.php' ) ) {
        	return true;
    	} else {
    		return false;
    	}
	}
}

// Check Polylang active
if ( ! function_exists( 'ovacrs_is_polylang_active' ) ) {
	function ovacrs_is_polylang_active() {
		if ( is_plugin_active( 'polylang/polylang.php' ) || is_plugin_active( 'polylang-pro/polylang.php' ) ) {
        	return true;
    	} else {
    		return false;
    	}
	}
}

// reCAPTCHA enabled
if ( !function_exists( 'ovacrs_recaptcha_enabled' ) ) {
	function ovacrs_recaptcha_enabled( $current_form = 'booking' ) {
		// Recaptcha enabled
		$enabled = false;

		if ( 'yes' === get_theme_mod( 'rd_recaptcha_enabled', 'no' ) ) {
			if ( 'both' === ovacrs_get_recaptcha_form() ) {
				$enabled = true;
			} elseif ( 'booking' === ovacrs_get_recaptcha_form() && 'booking' === $current_form ) {
				$enabled = true;
			} elseif ( 'request' === ovacrs_get_recaptcha_form() && 'request' === $current_form ) {
				$enabled = true;
			}
		}

		return apply_filters( 'ovacrs_recaptcha_enabled', $enabled );
	}
}

// Get reCAPTCHA form
if ( !function_exists( 'ovacrs_get_recaptcha_form' ) ) {
	function ovacrs_get_recaptcha_form() {
		return apply_filters( 'ovacrs_get_recaptcha_form', get_theme_mod( 'rd_recaptcha_form', 'both' ) );
	}
}

// Get reCAPTCHA type
if ( !function_exists( 'ovacrs_get_recaptcha_type' ) ) {
	function ovacrs_get_recaptcha_type() {
		return apply_filters( 'ovacrs_get_recaptcha_type', get_theme_mod( 'rd_recaptcha_type', 'v2' ) );
	}
}

// Get reCAPTCHA site key
if ( !function_exists( 'ovacrs_get_recaptcha_site_key' ) ) {
	function ovacrs_get_recaptcha_site_key() {
		return apply_filters( 'ovacrs_get_recaptcha_site_key', get_theme_mod( 'rd_recaptcha_site_key', '' ) );
	}
}

// Get reCAPTCHA secret key
if ( !function_exists( 'ovacrs_get_recaptcha_secret_key' ) ) {
	function ovacrs_get_recaptcha_secret_key() {
		return apply_filters( 'ovacrs_get_recaptcha_secret_key', get_theme_mod( 'rd_recaptcha_secret_key', '' ) );
	}
}

/**
 * Verify reCAPTCHA
 * @param 	string 	$token
 * @return 	string 	$error
 */
if ( ! function_exists( 'ovacrs_verify_recaptcha_token' ) ) {
	function ovacrs_verify_recaptcha_token( $token ) {
		$error = ovacrs_get_recaptcha_error();

		if ( 'v2' == ovacrs_get_recaptcha_type() ) {
			$error = ovacrs_verify_recaptcha_v2( $token );
		} elseif ( 'v3' == ovacrs_get_recaptcha_type() ) {
			$error = ovacrs_verify_recaptcha_v3( $token );
		}

		return apply_filters( 'ovacrs_verify_recaptcha_token', $error, $token );
	}
}

/**
 * Get reCAPTCHA client IP
 */
if ( ! function_exists( 'ovacrs_get_recaptcha_client_ip' ) ) {
	function ovacrs_get_recaptcha_client_ip() {
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = $_SERVER['REMOTE_ADDR'];
		} elseif ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} else {
			$ip = '0.0.0.0';
		}

		return apply_filters( 'ovacrs_get_recaptcha_client_ip', $ip );
	}
}

/**
 * Get reCAPTCHA host
 */
if ( ! function_exists( 'ovacrs_get_recaptcha_host' ) ) {
	function ovacrs_get_recaptcha_host() {
		$host 	= '';
		$url 	= parse_url( site_url() );

		if ( isset( $url['host'] ) && $url['host'] ) {
			$host = $url['host'];
		}

		return apply_filters( 'ovacrs_get_recaptcha_host', $host );
	}
}

/**
 * Get reCAPTCHA error
 */
if ( ! function_exists( 'ovacrs_get_recaptcha_error' ) ) {
	function ovacrs_get_recaptcha_error( $code = '' ) {
		$mesg = apply_filters( 'ovabrw_recaptcha_error_message', [
			'default' 					=> esc_html__( 'An error occurred with reCAPTCHA. Please try again later.', 'ova-crs' ),
			'missing-input-secret' 		=> esc_html__( 'The secret parameter is missing.', 'ova-crs' ),
			'invalid-input-secret' 		=> esc_html__( 'The secret parameter is invalid or malformed.', 'ova-crs' ),
			'missing-input-response' 	=> esc_html__( 'The response parameter is missing.', 'ova-crs' ),
			'invalid-input-response' 	=> esc_html__( 'The response parameter is invalid or malformed.', 'ova-crs' ),
			'bad-request' 				=> esc_html__( 'The request is invalid or malformed.', 'ova-crs' ),
			'timeout-or-duplicate' 		=> esc_html__( 'The response is no longer valid: either is too old or has been used previously.', 'ova-crs' )
		]);

		$error = isset( $mesg[$code] ) ? $mesg[$code] : $mesg['default'];

		return apply_filters( 'ovacrs_get_recaptcha_error', $error );
	}
}

/**
 * reCAPTCHA response
 */
if ( ! function_exists( 'ovacrs_recaptcha_api_response' ) ) {
	function ovacrs_recaptcha_api_response( $token = '' ) {
		// Params
		$params = [
			'secret'   => ovacrs_get_recaptcha_secret_key(),
			'response' => $token,
			'remoteip' => ovacrs_get_recaptcha_client_ip()
		];

		// Options
		$opts = [
			'http' => [
				'method'  => 'POST',
				'header'  => 'Content-type: application/x-www-form-urlencoded',
				'content' => http_build_query( $params )
			]
		];

		$context = stream_context_create( $opts );
		$res     = file_get_contents( 'https://www.google.com/recaptcha/api/siteverify', false, $context );
		$res     = json_decode( $res, true );

		return apply_filters( 'ovacrs_recaptcha_api_response', $res, $token );
	}
}

/**
 * Verify reCAPTCHA v2
 */
if ( ! function_exists( 'ovacrs_verify_recaptcha_v2' ) ) {
	function ovacrs_verify_recaptcha_v2( $token = '' ) {
		// Get recaptcha error
		$error = ovacrs_get_recaptcha_error();

		// Get api response
		if ( $token ) {
			$response 	= ovacrs_recaptcha_api_response( $token );
			$success 	= isset( $response['success'] ) ? $response['success'] : false;
			$hostname 	= isset( $response['hostname'] ) ? $response['hostname'] : '';

			if ( $success && $hostname == ovacrs_get_recaptcha_host() ) {
				$error = '';
			} else {
				if ( isset( $res['error-codes'][0] ) && $res['error-codes'][0] ) {
			        $error = ovacrs_get_recaptcha_error( $res['error-codes'][0] );
			    }
			}
		}

		return apply_filters( 'ovacrs_verify_recaptcha_v2', $error, $token );
	}
}

/**
 * Verify reCAPTCHA v3
 */
if ( ! function_exists( 'ovacrs_verify_recaptcha_v3' ) ) {
	function ovacrs_verify_recaptcha_v3( $token = '' ) {
		// Get recaptcha error
		$error = ovacrs_get_recaptcha_error();

		// Score
		$score = apply_filters( 'ovacrs_recaptcha_score', 0.5 );

		// Get api response
		if ( $token ) {
			$response 	= ovacrs_recaptcha_api_response( $token );
			$success 	= isset( $response['success'] ) ? $response['success'] : false;
			$hostname 	= isset( $response['hostname'] ) ? $response['hostname'] : '';
			$action 	= isset( $response['action'] ) ? $response['action'] : '';
			$res_score 	= isset( $response['score'] ) ? (float)$response['score'] : 0;

			if ( $success && $hostname == ovacrs_get_recaptcha_host() && $action == 'ovacrsVerifyForm' && $res_score > $score ) {
				$error = '';
			} else {
				if ( isset( $res['error-codes'][0] ) && $res['error-codes'][0] ) {
			        $error = ovacrs_get_recaptcha_error( $res['error-codes'][0] );
			    }
			}
		}

		return apply_filters( 'ovacrs_verify_recaptcha_v3', $error, $token );
	}
}