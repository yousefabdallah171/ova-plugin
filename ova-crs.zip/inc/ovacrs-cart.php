<?php
defined( 'ABSPATH' ) || exit();

// Validate Rent Day Min
if ( ! function_exists( 'ovacrs_val_day_min' ) ) {
    function ovacrs_val_day_min( $ovacrs_pickoff_date, $ovacrs_pickup_date, $ovacrs_rent_day_min ){
        $is_day = ( $ovacrs_pickoff_date - $ovacrs_pickup_date ) < $ovacrs_rent_day_min*24*60*60 ? true : false;
        return apply_filters( 'ovacrs_rent_day_min', $is_day );
    }
}

// Validate Rent Hour Min
if ( ! function_exists( 'ovacrs_val_hour_min' ) ) {
    function ovacrs_val_hour_min( $ovacrs_pickoff_date, $ovacrs_pickup_date, $ovacrs_rent_hour_min ){
        $is_hour = ( $ovacrs_pickoff_date - $ovacrs_pickup_date ) < $ovacrs_rent_hour_min*60*60 ? true : false;
        return apply_filters( 'ovacrs_rent_hour_min', $is_hour );
    }
}

// Step 0: Validate Booking Form And Rent Time
add_filter( 'woocommerce_add_to_cart_validation', 'ovacrs_validation_booking_form', 10, 5 );
function ovacrs_validation_booking_form( $passed ) {
    // Check product type is ovacrs_car_rental
    $custom_product_type = filter_input( INPUT_POST, 'custom_product_type' );
    if ( $custom_product_type != 'ovacrs_car_rental' ) return true;
    
    // Get Value From Booking Form
    $ovacrs_pickup_loc      = trim( filter_input( INPUT_POST, 'ovacrs_pickup_loc' ) );
    $ovacrs_pickoff_loc     = trim( filter_input( INPUT_POST, 'ovacrs_pickoff_loc' ) );
    $ovacrs_pickup_date     = filter_input( INPUT_POST, 'ovacrs_pickup_date' ) ? strtotime( filter_input( INPUT_POST, 'ovacrs_pickup_date' ) ) : '';
    $ovacrs_pickoff_date    = filter_input( INPUT_POST, 'ovacrs_pickoff_date' ) ? strtotime( filter_input( INPUT_POST, 'ovacrs_pickoff_date' ) ) : '';
    $car_id                 = filter_input( INPUT_POST, 'car_id' );

    $ovacrs_quantity        = filter_input( INPUT_POST, 'ovacrs_quantity' );
    $ovacrs_quantity        = ! empty( $ovacrs_quantity ) ? absint( $ovacrs_quantity ) : 1;

    // When Rental Type is Period, We have to Set Start Time, End Time again.
    $ovacrs_rental_type = get_post_meta( $car_id, 'ovacrs_price_type', true );

    // Manager Store
    $manage_store = get_post_meta( $car_id, 'ovacrs_manage_store', true );

    if ( $ovacrs_rental_type === 'transportation' ) {
        $time_dropoff = ovacrs_get_time_by_pick_up_off_loc_transport( $car_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc );
        $time_dropoff = 60 * $time_dropoff;
        
        $ovacrs_pickoff_date = $ovacrs_pickup_date + $time_dropoff;
    }
    
    if ( $ovacrs_rental_type == 'period_time' ) {
        $start_date             = filter_input( INPUT_POST, 'ovacrs_pickup_date' );
        $period_package_id      = filter_input( INPUT_POST, 'ovacrs_period_package_id' );
        $rental_time_period     = get_rental_info_period( $car_id, $start_date, $ovacrs_rental_type, $period_package_id );
        $ovacrs_pickup_date     = $rental_time_period['start_time'];
        $ovacrs_pickoff_date    = $rental_time_period['end_time'];
    }

    // Total Car in the Store
    $total_car_store = absint( get_post_meta( $car_id, 'ovacrs_car_count', true ) );

    if ( $manage_store === 'store' ) {
        $total_car_store = absint( get_post_meta( $car_id, 'ovacrs_stock_quantity', true ) );
    }

    // Check Price Type
    $price_type = get_post_meta( $car_id, 'ovacrs_price_type', true );

    // Rent day min
    $ovacrs_rent_day_min = (int)get_post_meta( $car_id, 'ovacrs_rent_day_min', true );

    // Rent hour min
    $ovacrs_rent_hour_min = (int)get_post_meta( $car_id, 'ovacrs_rent_hour_min', true );

    // Error: Empty fields
    if ( get_theme_mod( 'rd_bf_show_pickup_loc', 'true' ) == 'true' && empty( $ovacrs_pickup_loc ) ) {
        wc_clear_notices();
        echo wc_add_notice( esc_html__("Insert PickUp Location", 'ova-crs'), 'error');
        $passed = false;
    }

    if ( get_theme_mod( 'rd_bf_show_pickoff_loc', 'true' ) == 'true' && empty( $ovacrs_pickoff_loc ) ) {
        wc_clear_notices();
        echo wc_add_notice( esc_html__("Insert PickOff Location", 'ova-crs'), 'error');
        $passed = false;
    }

    // Error Pick Up Date < Current Time
    if ( $ovacrs_quantity < 1 ){
        wc_clear_notices();
        echo wc_add_notice( esc_html__("Please choose quantity greater 0", 'ova-crs'), 'error');   
        $passed = false;
    }
  
    // Error Pick Up Date < Current Time
    if( $ovacrs_pickup_date < current_time('timestamp') ){
        wc_clear_notices();
        echo wc_add_notice( esc_html__("Pick-up Date must be greater than Current Time", 'ova-crs'), 'error');   
        $passed = false;
    }
    
    if ( $ovacrs_rental_type !== 'transportation' ) {
        //check eror price_type not transportation
        
        // Error empty Pick Up Date or Pick Off Date
        if ( empty( $ovacrs_pickup_date ) || empty( $ovacrs_pickoff_date ) ) {
            wc_clear_notices();
            echo wc_add_notice( esc_html__("Insert PickUp, PickOff date", 'ova-crs'), 'error');
            $passed = false;
            return $passed;
        }

        // Error Pick Up Date > Pick Off Date
        if ( $ovacrs_pickup_date > $ovacrs_pickoff_date){
            wc_clear_notices();
            echo wc_add_notice( esc_html__("Drop-off Date must be greater than Pick-up Date", 'ova-crs'), 'error');
            $passed = false;
            return $passed;
        }
    } else {
        //Error price_type transportation

        //Error pickup loc not exists in product
        if ( ! ovacrs_check_pickup_dropoff_loc_transport( $car_id, $ovacrs_pickup_loc, 'pickup' ) ){
            wc_clear_notices();
            echo wc_add_notice( esc_html__("PickUp Location Is Wrong", 'ova-crs'), 'error');
            $passed = false;
            return $passed;
        }

        //Error dropoff loc not exists in product
        if( ! ovacrs_check_pickup_dropoff_loc_transport( $car_id, $ovacrs_pickoff_loc, 'dropoff' ) ){
            wc_clear_notices();
            echo wc_add_notice( esc_html__("DropOff Location Is Wrong", 'ova-crs'), 'error');
            $passed = false;
            return $passed;
        }

        // Error empty Pick Up Date or Pick Off Date
        if ( empty( $ovacrs_pickup_date ) ) {
            wc_clear_notices();
            echo wc_add_notice( esc_html__("Insert PickUp", 'ova-crs'), 'error');
            $passed = false;
            return $passed;
        }
    }

    // Error Rent Time Min
    switch ( $price_type ) {
        case 'day':
        if( ovacrs_val_day_min( $ovacrs_pickoff_date, $ovacrs_pickup_date, $ovacrs_rent_day_min ) ){
            wc_clear_notices();
            echo wc_add_notice( sprintf( esc_html__( 'Rent Day Min: %d day', 'ova-crs' ), $ovacrs_rent_day_min ), 'error');   
            $passed = false;
        }
        break;

        case 'hour':
        if( ovacrs_val_hour_min( $ovacrs_pickoff_date, $ovacrs_pickup_date, $ovacrs_rent_hour_min ) ){
            wc_clear_notices();
            echo wc_add_notice( sprintf( esc_html__( 'Rent Hour Min %d hour', 'ova-crs' ), $ovacrs_rent_hour_min ), 'error');   
            $passed = false;
        }
        break;


        case 'mixed':
        if ( ovacrs_val_hour_min( $ovacrs_pickoff_date, $ovacrs_pickup_date, $ovacrs_rent_hour_min ) ) {
            wc_clear_notices();
            echo wc_add_notice( sprintf( esc_html__( 'Rent Hour Min %d hour', 'ova-crs' ), $ovacrs_rent_hour_min ), 'error');   
            $passed = false;
        }
        break;
    }

    // Error: Unvailable time for renting
    $ovacrs_untime_startdate    = get_post_meta( $car_id, 'ovacrs_untime_startdate', true );
    $ovacrs_untime_enddate      = get_post_meta( $car_id, 'ovacrs_untime_enddate', true );

    if ( $ovacrs_untime_startdate ) {
        foreach( $ovacrs_untime_startdate as $key => $value ) {
            if ( ! ( $ovacrs_pickoff_date < strtotime( $ovacrs_untime_startdate[$key] ) || strtotime( $ovacrs_untime_enddate[$key] ) < $ovacrs_pickup_date ) ){
                wc_clear_notices();
                echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-crs' ), 'error');
                $passed = false;
                break;
            }
        }
    }

    // Error: Disabled Week Days
    if ( apply_filters( 'ovacrs_ft_disabled_week_days', true ) ) {
        $disable_week_day = str_replace( ' ', '', get_theme_mod( 'calendar_dis_weekend', '0,6' ) );
        $disable_week_day = '' !== $disable_week_day ? array_map( 'trim', explode( ',', $disable_week_day ) ) : '';

        if ( $disable_week_day && $ovacrs_pickup_date && $ovacrs_pickoff_date ) {
            if ( 'yes' === get_theme_mod( 'overcoms_disabled_weekdays', 'yes' ) ) {
                $pickup_date_of_week    = date('w', $ovacrs_pickup_date );
                $dropoff_date_of_week   = date('w', $ovacrs_pickoff_date );

                if ( in_array( $pickup_date_of_week, $disable_week_day ) || in_array( $dropoff_date_of_week, $disable_week_day ) ) {
                    wc_clear_notices();
                    echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-crs' ), 'error');
                    $passed = false;
                }
            } else {
                $datediff       = (int)$ovacrs_pickoff_date - (int)$ovacrs_pickup_date;
                $total_datediff = round( $datediff / (60 * 60 * 24), wc_get_price_decimals() ) + 1;

                // get number day
                $pickup_date_of_week   = date('w', $ovacrs_pickup_date );
                $pickup_date_timestamp = $ovacrs_pickup_date;
                
                $i = 0;

                while ( $i <= $total_datediff ) {
                    if ( in_array( $pickup_date_of_week, $disable_week_day ) ) {
                        wc_clear_notices();
                        echo wc_add_notice( esc_html__( 'This time is not available for renting', 'ova-crs' ), 'error');
                        $passed = false;
                        break;
                    }

                    $pickup_date_of_week    = date('w', $pickup_date_timestamp );
                    $pickup_date_timestamp  = strtotime('+1 day', $pickup_date_timestamp);

                    $i++;
                }
            }
        }
    }

    $passed = apply_filters( 'ovacrs_ft_check_disabled_week_days', $passed, $car_id, $ovacrs_pickup_date, $ovacrs_pickoff_date );

    // Verify reCAPTCHA
    if ( ovacrs_recaptcha_enabled( 'booking' ) ) {
        $recaptcha_token = isset( $_REQUEST['ovacrs-booking-recaptcha-token'] ) ? $_REQUEST['ovacrs-booking-recaptcha-token'] : '';

        $error_mesg = ovacrs_verify_recaptcha_token( $recaptcha_token );

        if ( $error_mesg ) {
            wc_clear_notices();
            echo wc_add_notice( $error_mesg, 'error' );   
            return false;
        }
    }
    // End

    // Compare Rent Day with database
    // Set the orders statuses
    
    // Get array ID when use WPML
    $post_id_array  = get_arr_product_ids( $car_id );
    $statuses       = ovacrs_order_status();
    $orders_ids     = ovacrs_get_orders_ids_by_product_id( $post_id_array, $statuses );
    
    $cart_vehicle_rented_array  = $store_vehicle_rented_array = array();
    $qty_rented = 0;
   
    foreach( $orders_ids as $key => $value ) {
        // Get Order Detail by Order ID
        $order = wc_get_order($value);

        // Get Meta Data type line_item of Order
        $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
        
        // For Meta Data
        foreach ( $order_line_items as $item_id => $item ) {
            $ovacrs_pickup_date_store = $ovacrs_pickoff_date_store = $id_vehicle_rented = '';
            $qty_rented_item = 0;
            
            // Check Line Item have item ID is Car_ID
            if ( in_array( $item->get_product_id(), $post_id_array ) ) {

                // Check time to Prepare before delivered
                $prepare_time = get_post_meta( $car_id, 'ovacrs_prepare_vehicle', true ) ? get_post_meta( $car_id, 'ovacrs_prepare_vehicle', true ) * 60 : 0;

                // Get value of pickup date, pickoff date
                $ovacrs_pickup_date_store = strtotime( $item->get_meta( 'ovacrs_pickup_date' ) );

                if ( $ovacrs_rental_type === 'transportation' ) {
                    $ovacrs_pickup_date_store = strtotime( date( 'Y-m-d', $ovacrs_pickup_date_store ) . ' 00:00' );
                }

                $ovacrs_pickoff_date_store = strtotime( $item->get_meta( 'ovacrs_pickoff_date' ) ) + $prepare_time;

                if ( $manage_store === 'store' ) {
                    $qty_rented_item = absint( $item->get_meta( 'ovacrs_quantity' ) );
                } else {
                    $id_vehicle_rented = trim( $item->get_meta( 'id_vehicle' ) );
                }
                
                // Only compare date when "PickOff Date in Store" > "Current Time" becaue "PickOff Date Rent" have to > "Current Time"
                if ( $ovacrs_pickoff_date_store >= current_time( 'timestamp' ) ){
                    if ( ! ( $ovacrs_pickoff_date <= $ovacrs_pickup_date_store || $ovacrs_pickoff_date_store <= $ovacrs_pickup_date ) ) {
                        if ( $manage_store === 'store' ) {
                            $qty_rented += $qty_rented_item;
                        } else {
                            if ( $id_vehicle_rented != '' ){
                                $id_vehicle_rented_array = explode( ',', $id_vehicle_rented );

                                foreach( $id_vehicle_rented_array as $value ) {
                                    array_push( $store_vehicle_rented_array, $value );    
                                }
                            }
                        }
                    }
                }
            }
        } 
    }

    if ( $store_vehicle_rented_array != null && $manage_store != 'store' ) {
        $store_vehicle_rented_array = array_unique( $store_vehicle_rented_array );  
    }

    // Check Count car in Cart current
    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
        if( in_array( $product_id, $post_id_array ) ){
            // Check time to Prepare before delivered
            $prepare_time = get_post_meta( $car_id, 'ovacrs_prepare_vehicle', true ) ? get_post_meta( $car_id, 'ovacrs_prepare_vehicle', true ) * 60 : 0;

            if ( ! ( $ovacrs_pickoff_date <= strtotime( $cart_item['ovacrs_pickup_date'] ) || strtotime( $cart_item['ovacrs_pickoff_date'] ) + $prepare_time <= $ovacrs_pickup_date ) ) {
                if ( $manage_store === 'store' ) {
                    if ( isset( $cart_item['ovacrs_quantity'] ) && absint( $cart_item['ovacrs_quantity'] ) ) {
                        $qty_rented += absint( $cart_item['ovacrs_quantity'] );
                    }
                } else {
                    if ( $cart_item['id_vehicle'] != '' ) {
                        $cart_item_id_vehicle_array = explode( ',', $cart_item['id_vehicle'] );

                        foreach( $cart_item_id_vehicle_array as $value ) {
                            array_push( $cart_vehicle_rented_array, $value );
                        }
                    }
                }
            }
        }
    }

    if ( $cart_vehicle_rented_array != null && $manage_store != 'store' ) {
        $cart_vehicle_rented_array = array_unique( $cart_vehicle_rented_array );
    }

    if ( $manage_store === 'store' ) {
        $qty_available = $total_car_store - absint( $qty_rented );

        if ( $qty_available > 0 && $ovacrs_quantity > $qty_available ) {
            wc_clear_notices();
            echo wc_add_notice( sprintf( esc_html__( 'Available vehicle is %s', 'ova-crs'  ), $qty_available ), 'error');
            $passed = false;
        } elseif ( absint( $qty_rented ) >= $total_car_store || ( $total_car_store - absint( $qty_rented ) < $ovacrs_quantity ) ){
            wc_clear_notices();
            echo wc_add_notice( esc_html__( 'Vehicle is unavailable for this time, Please book other time.', 'ova-crs' ), 'error');   
            $passed = false;
        }
    } else {
        $id_rented = array_unique( array_merge( $store_vehicle_rented_array, $cart_vehicle_rented_array ) );

        if ( count( $id_rented ) >= $total_car_store || ( $total_car_store - count( $id_rented )  < $ovacrs_quantity ) ){
            wc_clear_notices();
            echo wc_add_notice( esc_html__( 'Vehicle is unavailable for this time, Please book other time.', 'ova-crs' ), 'error');   
            $passed = false;
        }

        // Set id_vehicle_available
        $ovacrs_id_vehicles     = is_array( get_post_meta( $car_id, 'ovacrs_id_vehicles', true ) ) ? get_post_meta( $car_id, 'ovacrs_id_vehicles', true ) : array();
        $id_vehicle_available   = array_diff( $ovacrs_id_vehicles, $id_rented );
        $vehicle_avai           = $id_vehicle_ok = '';
        $vehicle_avai_flag      = false;
        $vehicle_untime_flag    = true;

        if ( get_theme_mod( 'use_loc_filter', 'true' ) == 'true' ) {
            foreach( $id_vehicle_available as $key => $value ) {
                $vehicle_avai = ovacrs_get_vehicle_loc_title($value);

                $id_vehicle_untime_startday = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['startdate'] ) : '';
                $id_vehicle_untime_enddate  = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['enddate'] ) : '';

                // Location is ok
                if ( $ovacrs_pickup_loc == $vehicle_avai['loc'] ) {
                    // Vehicle with Untime
                    if ( ! ( $ovacrs_pickoff_date < $id_vehicle_untime_startday || $id_vehicle_untime_enddate < $ovacrs_pickup_date ) && $id_vehicle_untime_startday != '' && $id_vehicle_untime_enddate != '' ) {
                        $vehicle_avai_flag      = true;
                        $vehicle_untime_flag    = false;
                    } else {
                        $vehicle_avai_flag      = true;
                        $vehicle_untime_flag    = true;
                        $id_vehicle_ok          = $value;

                        // Create ID vehicle and check with quantity
                        if ( WC()->session->__isset( 'id_vehicle_available' ) ) {
                            $id_v_available = WC()->session->get( 'id_vehicle_available' );

                            if ( count( explode( ',',$id_v_available ) ) < $ovacrs_quantity ) {
                                WC()->session->__unset( 'id_vehicle_available' );
                                WC()->session->set( 'id_vehicle_available' , $id_v_available.','.trim( $value ) );
                            } else {
                                break;
                            }
                        } else {
                            WC()->session->set( 'id_vehicle_available' , trim( $value ) );    
                        }
                    }
                }
            }
        } else {
            foreach( $id_vehicle_available as $key => $value ) {
                $vehicle_avai = ovacrs_get_vehicle_loc_title($value);

                $id_vehicle_untime_startday = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['startdate'] ) : '';
                $id_vehicle_untime_enddate  = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['enddate'] ) : '';

                if ( ! ( $ovacrs_pickoff_date < $id_vehicle_untime_startday || $id_vehicle_untime_enddate < $ovacrs_pickup_date ) && $id_vehicle_untime_startday != '' && $id_vehicle_untime_enddate != '' ) {
                    $vehicle_untime_flag = false;
                } else {
                    $vehicle_untime_flag = true;
                    
                    // Create ID vehicle and check with quantity
                    if ( WC()->session->__isset( 'id_vehicle_available' ) ) {
                        $id_v_available = WC()->session->get( 'id_vehicle_available' );

                        if ( count( explode( ',', $id_v_available ) ) < $ovacrs_quantity ) {
                            WC()->session->set( 'id_vehicle_available' , $id_v_available.','.trim( $value ) );
                        } else {
                            break;
                        }
                    } else {
                        WC()->session->set( 'id_vehicle_available' , trim( $value ) );    
                    }
                }
            }
        }

        if ( ! WC()->session->__isset( 'id_vehicle_available' ) ) {
            wc_clear_notices();
            echo wc_add_notice( esc_html__( 'This Vehicle is unavailable', 'ova-crs' ), 'error');   
            $passed = false;
        }

        if ( WC()->session->__isset( 'id_vehicle_available' ) ) {
            $id_v_available         = WC()->session->get( 'id_vehicle_available' );
            $id_v_available_array   = explode( ",",  $id_v_available );

            if ( count( $id_v_available_array ) < $ovacrs_quantity ) {
                wc_clear_notices();
                echo wc_add_notice( esc_html__( 'This Vehicle is unavailable this time. Please decrease quantity and check again.', 'ova-crs' ), 'error');   
                $passed = false;
                WC()->session->__unset( 'id_vehicle_available' );
            }
        }
    }
    
    return $passed;
}

// 1: Add Extra Data To Cart Item
add_filter( 'woocommerce_add_cart_item_data', 'ovacrs_add_extra_data_to_cart_item', 1, 10 );
function ovacrs_add_extra_data_to_cart_item( $cart_item_data, $product_id, $variation_id ) {
    $ova_type_deposit       = filter_input( INPUT_POST, 'ova_type_deposit' );
    $ovacrs_pickup_loc      = filter_input( INPUT_POST, 'ovacrs_pickup_loc' );
    $ovacrs_pickoff_loc     = filter_input( INPUT_POST, 'ovacrs_pickoff_loc' );
    $ovacrs_pickup_date     = filter_input( INPUT_POST, 'ovacrs_pickup_date' );
    $ovacrs_pickoff_date    = filter_input( INPUT_POST, 'ovacrs_pickoff_date' );
    $car_id                 = filter_input( INPUT_POST, 'car_id' );
    $ovacrs_quantity        = filter_input( INPUT_POST, 'ovacrs_quantity' );
    $ovacrs_quantity        = ! empty( $ovacrs_quantity ) ? absint( $ovacrs_quantity ) : 1;

    // Manage Store
    $manage_store = get_post_meta( $product_id, 'ovacrs_manage_store', true );

    $list_fields = get_option( 'ovacrs_booking_form', array() );

    if ( is_array( $list_fields ) && ! empty( $list_fields ) ) {
        foreach( $list_fields as $key => $field ) {
            if( $field['enabled'] == 'on' ) {
                $cart_item_data[$key] = filter_input( INPUT_POST, $key );
            }
        }
    }

    $ovacrs_period_label = '';

    // When Rental Type is Period, We have to Set Start Time, End Time again.
    $ovacrs_rental_type = get_post_meta( $product_id, 'ovacrs_price_type', true );
    $cart_item_data['rental_type'] = $ovacrs_rental_type;


    $date_format = get_theme_mod( 'rd_bf_dateformat', 'Y-m-d' );
    $time_format = get_theme_mod( 'rd_bf_timeformat', 'H:i' );

    // If rental type is Transportation
    if ( $ovacrs_rental_type === 'transportation' ) {
        $time_dropoff = ovacrs_get_time_by_pick_up_off_loc_transport( $car_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc );

        // Get Second
        $time_dropoff_seconds   = 60 * $time_dropoff;
        $dropoff_date_timestamp =  strtotime( $ovacrs_pickup_date ) + $time_dropoff_seconds;
        $ovacrs_pickoff_date    = date( $date_format . ' ' . $time_format, $dropoff_date_timestamp );

        $cart_item_data['rental_type'] = $ovacrs_rental_type;
        $cart_item_data['price_transport'] = ovacrs_get_price_by_start_date_transport( $car_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc );
    }

    if ( $ovacrs_rental_type == 'period_time' ) {
        $start_date         = filter_input( INPUT_POST, 'ovacrs_pickup_date' );
        $period_package_id  = filter_input( INPUT_POST, 'ovacrs_period_package_id' );
        $rental_info_period = get_rental_info_period( $car_id, $start_date, $ovacrs_rental_type, $period_package_id );

        if ( $rental_info_period['package_type'] == 'inday' ) {
            $date_time_format_start = $date_format.' '.$time_format;    
            $date_time_format_endate = $date_format.' '.$time_format;
        } else {
            $date_time_format_start = $date_format.' '.$time_format;
            $date_time_format_endate = $date_format.' '.$time_format;
        }
        
        $ovacrs_pickup_date     = $rental_info_period['start_time'] ? date( $date_time_format_start, $rental_info_period['start_time'] ) : '';
        $ovacrs_pickoff_date    = $rental_info_period['end_time'] ? date( $date_time_format_endate, $rental_info_period['end_time'] ) : '';
        $ovacrs_period_label    = $rental_info_period['period_label'];
        $ovacrs_period_price    = $rental_info_period['period_price'];
        $ovacrs_package_type    = $rental_info_period['package_type'];
    }

    if ( $ovacrs_rental_type == 'day' ) {
        $location_fee = ovacrs_get_price_fee_location_by_pickup_dropoff($car_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc);

        if ( $location_fee > 0 ) {
            $cart_item_data['ovacrs_location_fee'] = $location_fee;
        }
    }

    $ovacrs_resource_checkboxs = isset( $_POST['ovacrs_resource_checkboxs'] ) ? $_POST['ovacrs_resource_checkboxs'] : '';

    if ( isset( $_POST['booking_form_ajax_get_extra_resource'] ) && $_POST['booking_form_ajax_get_extra_resource'] == 'booking-form' ) {
        $data = $_POST['ovacrs_resource_checkboxs'];
        $data = str_replace('\\', '', $data);
        $data = json_decode( $data, true );
        $ovacrs_resource_checkboxs = $data;
    }
    
    if ( empty( $ovacrs_pickup_loc ) && empty( $ovacrs_pickoff_loc ) && empty( $ovacrs_pickup_date ) && empty( $ovacrs_pickoff_date ) ) {
        return $cart_item_data;
    }
    
    if ( get_theme_mod( 'rd_bf_show_pickup_loc', 'true' ) == 'true' ) {
        $cart_item_data['ovacrs_pickup_loc'] = $ovacrs_pickup_loc;    
    }

    if ( get_theme_mod( 'rd_bf_show_pickoff_loc', 'true' ) == 'true' ) {
        $cart_item_data['ovacrs_pickoff_loc'] = $ovacrs_pickoff_loc;    
    }
    
    $cart_item_data['ovacrs_pickup_date']   = $ovacrs_pickup_date;
    $cart_item_data['ovacrs_pickoff_date']  = $ovacrs_pickoff_date;
    $cart_item_data['resources']            = $ovacrs_resource_checkboxs;
    
    if ( $ovacrs_period_label ) {
        $cart_item_data['rental_type']  = $ovacrs_rental_type;
        $cart_item_data['period_label'] = $ovacrs_period_label;    
        $cart_item_data['period_price'] = $ovacrs_period_price;
        $cart_item_data['package_type'] = $ovacrs_package_type;
    }
    
    if ( $manage_store != 'store' ) {
        $id_vehicle_available = '';

        if ( WC()->session->__isset( 'id_vehicle_available' ) ) {
            $id_vehicle_available = WC()->session->get( 'id_vehicle_available' );
            WC()->session->__unset( 'id_vehicle_available' );
        }

        $cart_item_data['id_vehicle'] = trim( $id_vehicle_available );
    }
    
    if ( get_post_meta( $product_id, 'ovacrs_amount_insurance', true ) ) {
        $cart_item_data['ovacrs_amount_insurance'] = floatval(get_post_meta( $product_id, 'ovacrs_amount_insurance', true ));
    }

    $deposit_enable = get_post_meta ( $product_id, 'ovacrs_enable_deposit', true );

    $ova_type_deposit = ( $ova_type_deposit && trim( $ova_type_deposit ) === 'deposit' ) ? 'deposit' : 'full';
    $cart_item_data['ova_type_deposit'] = $ova_type_deposit;

    // Add quantity
    $cart_item_data['ovacrs_quantity'] = $ovacrs_quantity;
    
    return $cart_item_data;
}

// 2: Display Extra Data in the Cart
add_filter( 'woocommerce_get_item_data', 'ovacrs_display_extra_data_cart', 10, 2 );
function ovacrs_display_extra_data_cart( $item_data, $cart_item ) {
    if ( !$cart_item['data']->is_type('ovacrs_car_rental') ) return $item_data;

    if ( empty( $cart_item['ovacrs_pickup_loc'] ) && empty( $cart_item['ovacrs_pickoff_loc'] ) && empty( $cart_item['ovacrs_pickup_date'] ) && empty( $cart_item['ovacrs_pickoff_date'] ) ) {
        wc_clear_notices();
        wc_add_notice( esc_html__("Insert full data in booking form", 'ova-crs'), 'notice');
        return false;
    }

    if ( get_theme_mod( 'rd_bf_show_pickup_loc', 'true' ) == 'true' ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Pick-up Location', 'ova-crs' ),
            'value'   => wc_clean( $cart_item['ovacrs_pickup_loc'] ),
            'display' => '',
        );
    }

    if ( get_theme_mod( 'rd_bf_show_pickoff_loc', 'true' ) == 'true' ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Drop-off Location', 'ova-crs' ),
            'value'   => wc_clean( $cart_item['ovacrs_pickoff_loc'] ),
            'display' => '',
        );
    }

    $item_data[] = array(
        'key'     => esc_html__( 'Pick-up Date', 'ova-crs' ),
        'value'   => wc_clean( $cart_item['ovacrs_pickup_date'] ),
        'display' => '',
    );

    $item_data[] = array(
        'key'     => esc_html__( 'Drop-off Date', 'ova-crs' ),
        'value'   => wc_clean( $cart_item['ovacrs_pickoff_date'] ),
        'display' => '',
    );

    if ( $cart_item['resources'] ) {
        foreach ( $cart_item['resources'] as $key_re => $value_re ) {
            $item_data[] = array(
                'key'     => esc_html__( 'Extra Resource', 'ova-crs' ),
                'value'   => wc_clean( $value_re ),
                'display' => '',
            );
        }
    }

    if ( isset( $cart_item['id_vehicle'] ) && $cart_item['id_vehicle'] ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Id Vehicle', 'ova-crs' ),
            'value'   => wc_clean( trim( $cart_item['id_vehicle'] ) ),
            'display' => '',
        );
    }
    
    if ( isset( $cart_item['period_label'] ) ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Package', 'ova-crs' ),
            'value'   => wc_clean( trim( $cart_item['period_label'] ) ),
            'display' => '',
        );
    }

    $list_fields = get_option( 'ovacrs_booking_form', array() );
    if ( is_array( $list_fields ) && ! empty( $list_fields ) ) {
        foreach( $list_fields as $key => $field ) {
            $value = array_key_exists( $key, $cart_item ) ? $cart_item[$key] : '';
            if( ! empty( $value ) && $field['enabled'] == 'on' ) {
                $item_data[] = array(
                    'key'     => $field['label'],
                    'value'   => wc_clean( $value ),
                    'display' => '',
                );
            }
            
        }
    }

    if ( isset( $cart_item['ovacrs_quantity'] ) && absint( $cart_item['ovacrs_quantity'] ) ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Quantity', 'ova-crs' ),
            'value'   => wc_clean( trim( $cart_item['ovacrs_quantity'] ) ),
            'display' => '',
        );
    }

    if ( isset( $cart_item['ovacrs_location_fee'] ) ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Location Fee', 'ova-crs' ),
            'value'   => wc_price( $cart_item['ovacrs_location_fee'] ),
            'display' => '',
        );
    }

    if ( isset( $cart_item['ovacrs_amount_insurance'] ) ) {
        $item_data[] = array(
            'key'     => esc_html__( 'Amount Of Insurance', 'ova-crs' ),
            'value'   => wc_price( $cart_item['ovacrs_amount_insurance'] ),
            'display' => '',
        );
    }

    return $item_data;
}


// 3: Save to Order
add_action( 'woocommerce_checkout_create_order_line_item', 'ovacrs_add_extra_data_to_order_items', 10, 4 );
function ovacrs_add_extra_data_to_order_items( $item, $cart_item_key, $values, $order ) {
    $product_id = $item->get_product_id();

    if ( empty( $values['ovacrs_pickup_loc'] ) && empty( $values['ovacrs_pickoff_loc'] ) && empty( $values['ovacrs_pickup_date'] ) && empty( $values['ovacrs_pickoff_date'] ) ) {
        return;
    }

    if ( get_theme_mod( 'rd_bf_show_pickup_loc', 'true' ) == 'true' ) {
        $item->add_meta_data( 'ovacrs_pickup_loc', $values['ovacrs_pickup_loc'] );
    }

    if ( get_theme_mod( 'rd_bf_show_pickoff_loc', 'true' ) == 'true' ) {
        $item->add_meta_data( 'ovacrs_pickoff_loc', $values['ovacrs_pickoff_loc'] );
    }

    $item->add_meta_data( 'ovacrs_pickup_date', $values['ovacrs_pickup_date'] );
    $item->add_meta_data( 'ovacrs_pickoff_date', $values['ovacrs_pickoff_date'] );
    
    if ( isset( $values['ovacrs_location_fee'] ) ) {
        $item->add_meta_data( 'ovacrs_location_fee', wc_price( $values['ovacrs_location_fee'] ) );
    }

    if ( isset( $values['rental_type'] ) && ( $values['rental_type'] == 'period_time' || $values['rental_type'] == 'period_hour' ) ) {
        $item->add_meta_data( 'ovacrs_price_detail', strip_tags( wc_price( $values['period_price'] ) ) );
    } else {
        if ( $values['rental_type'] == 'transportation' ) {
            $item->add_meta_data( 'ovacrs_price_detail', wc_price( $values['price_transport'] ) );
        } else {
            $real_quantity  = get_real_quantity( 1, $product_id, strtotime( $values['ovacrs_pickup_date'] ), strtotime( $values['ovacrs_pickoff_date'] ) );

            $real_price = get_real_price( 1, $product_id, strtotime( $values['ovacrs_pickup_date'] ), strtotime( $values['ovacrs_pickoff_date'] ) );
            $item->add_meta_data( 'ovacrs_price_detail', $real_price );
        }
    }

    if ( $values['resources'] ) {
        foreach( $values['resources'] as $key_re => $value_re ) {
            $item->add_meta_data( esc_html__( 'Extra Resource: ', 'ova-crs' ), $value_re );
        }    
    }

    if ( isset( $values['rental_type'] ) ) {
        $item->add_meta_data( 'rental_type', $values['rental_type'] );
    }

    if ( isset( $values['package_type'] ) ) {
        $item->add_meta_data( 'package_type', $values['package_type'] );
    }

    if ( isset( $values['period_label'] ) ) {
        $item->add_meta_data( 'period_label', $values['period_label'] );
    }
    
    $list_fields = get_option( 'ovacrs_booking_form', array() );

    if ( is_array( $list_fields ) && ! empty( $list_fields ) ) {
        foreach( $list_fields as $key => $field ) {
            $value = array_key_exists( $key, $values ) ? $values[$key] : '';
            if( ! empty( $value ) && $field['enabled'] == 'on' ) {
                $item->add_meta_data( $key, $value );
            }
        }
    }

    if ( isset( $values['id_vehicle'] ) && $values['id_vehicle'] ) {
        $item->add_meta_data( 'id_vehicle', trim( $values['id_vehicle'] ) );
    }

    if ( isset( $values['ovacrs_quantity'] ) && absint( $values['ovacrs_quantity'] ) ) {
        $item->add_meta_data( 'ovacrs_quantity', absint( $values['ovacrs_quantity'] ) );
    } else {
        $item->add_meta_data( 'ovacrs_quantity', 1 );
    }

    // Insurance
    if ( isset( $values['ovacrs_amount_insurance'] ) ) {
        $item->add_meta_data( 'ovacrs_amount_insurance_product', $values['ovacrs_amount_insurance'] );
    } else {
        $item->add_meta_data( 'ovacrs_amount_insurance_product', 0 );
    }

    // Deposit
    $has_deposit = isset( WC()->cart->deposit_info[ '_ova_has_deposit' ] ) ? WC()->cart->deposit_info[ '_ova_has_deposit' ] : '';
    if ( $has_deposit ) {
        $deposit_amount     = $values['data']->get_meta('deposit_amount');
        $remaining_amount   = $values['data']->get_meta('remaining_amount');

        $item->add_meta_data( 'ovacrs_deposit_amount_product', $deposit_amount );
        $item->add_meta_data( 'ovacrs_remaining_amount_product', $remaining_amount );
    }
}

// 4: Checkout Validate
add_action('woocommerce_after_checkout_validation', 'ovacrs_after_checkout_validation');
if ( ! function_exists( 'ovacrs_after_checkout_validation' ) ) {
    function ovacrs_after_checkout_validation( $posted ) {
        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
            if ( ! $cart_item['data']->is_type('ovacrs_car_rental') ) continue;

            $car_id             = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );
            $ovacrs_quantity    = absint( $cart_item['ovacrs_quantity'] );
            $product            = wc_get_product( $car_id );

            // Manager Store
            $manage_store = get_post_meta( $car_id, 'ovacrs_manage_store', true );

            if ( $product->is_type( 'ovacrs_car_rental' ) ) {
                $ovacrs_pickup_date     = strtotime( $cart_item['ovacrs_pickup_date'] );
                $ovacrs_pickoff_date    = strtotime( $cart_item['ovacrs_pickoff_date'] );

                // Total Car in the Store
                $total_car_store = absint( get_post_meta( $car_id, 'ovacrs_car_count', true ) );

                if ( $manage_store === 'store' ) {
                    $total_car_store = absint( get_post_meta( $car_id, 'ovacrs_stock_quantity', true ) );
                }

                $ovacrs_rental_type = get_post_meta( $car_id, 'ovacrs_price_type', true );

                // Compare Rent Day with database
                // Set the orders statuses
                
                // Get array ID when use WPML
                $post_id_array = get_arr_product_ids( $car_id );

                $statuses   = ovacrs_order_status();
                $orders_ids = ovacrs_get_orders_ids_by_product_id( $post_id_array, $statuses );
                
                $store_vehicle_rented_array = array();
                $qty_rented = 0;
               
                foreach( $orders_ids as $key => $value ) {
                    // Get Order Detail by Order ID
                    $order = wc_get_order($value);

                    // Get Meta Data type line_item of Order
                    $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
                    
                    // For Meta Data
                    foreach ( $order_line_items as $item_id => $item ) {
                        $ovacrs_pickup_date_store = $ovacrs_pickoff_date_store = $id_vehicle_rented = '';
                        $qty_rented_item = 0;

                        // Check Line Item have item ID is Car_ID
                        if ( in_array( $item->get_product_id(), $post_id_array ) ) {

                            // Check time to Prepare before delivered
                            $prepare_time = get_post_meta( $car_id, 'ovacrs_prepare_vehicle', true ) ? get_post_meta( $car_id, 'ovacrs_prepare_vehicle', true ) * 60 : 0;

                            // Get value of pickup date, pickoff date
                            $ovacrs_pickup_date_store = strtotime( $item->get_meta( 'ovacrs_pickup_date' ) );
                            if ( $ovacrs_rental_type === 'transportation' ) {
                                $ovacrs_pickup_date_store = strtotime( date( 'Y-m-d', $ovacrs_pickup_date_store ) . ' 00:00' );
                            }

                            $ovacrs_pickoff_date_store = strtotime( $item->get_meta( 'ovacrs_pickoff_date' ) ) + $prepare_time;

                            if ( $manage_store === 'store' ) {
                                $qty_rented_item = absint( $item->get_meta( 'ovacrs_quantity' ) );
                            } else {
                                $id_vehicle_rented = trim( $item->get_meta( 'id_vehicle' ) );
                            }
                            
                            // Only compare date when "PickOff Date in Store" > "Current Time" becaue "PickOff Date Rent" have to > "Current Time"
                            if ( $ovacrs_pickoff_date_store >= current_time( 'timestamp' ) ) {
                                if ( ! ( $ovacrs_pickoff_date <= $ovacrs_pickup_date_store || $ovacrs_pickoff_date_store <= $ovacrs_pickup_date ) ) {
                                    if ( $manage_store === 'store' ) {
                                        $qty_rented += $qty_rented_item;
                                    } else {
                                        if ( $id_vehicle_rented != '' ) {
                                            array_push( $store_vehicle_rented_array, $id_vehicle_rented );    
                                        }
                                    }
                                }
                            }
                        }
                    } 
                }

                if ( $manage_store === 'store' ) {
                    if ( absint( $qty_rented ) >= $total_car_store || ( $total_car_store - absint( $qty_rented ) < $ovacrs_quantity ) ){
                        wc_clear_notices();
                        echo wc_add_notice( esc_html__( 'Vehicle is unavailable for this time, Please book other time.', 'ova-crs' ), 'error');
                        return false;
                    }
                } else {
                    if ( $store_vehicle_rented_array != null ) {
                        $store_vehicle_rented_array = array_unique( $store_vehicle_rented_array );
                    }

                    $id_vehicle = $cart_item['id_vehicle'];

                    if ( count( $store_vehicle_rented_array ) >= $total_car_store || in_array( $id_vehicle, $store_vehicle_rented_array ) || ( $total_car_store - count( $store_vehicle_rented_array ) < $ovacrs_quantity ) ){
                        wc_clear_notices();
                        echo wc_add_notice( esc_html__( 'Vehicle is unavailable for this time, Please book other time.', 'ova-crs' ), 'error');
                        return false;
                    }
                }
            }
        }

        return true;
    }
}

function ova_calculate_deposit_remaining_amount ($cart_item) {
    $remaining_amount   = $deposit_amount = 0;
    $has_deposit        = false;
    $product_id         = absint( $cart_item['product_id'] );
    $ovacrs_rental_type = get_post_meta( $product_id, 'ovacrs_price_type', true );

    // Calculate Rent Time
    $ovacrs_pickup_date     = strtotime( $cart_item['ovacrs_pickup_date'] );
    $ovacrs_pickoff_date    = strtotime( $cart_item['ovacrs_pickoff_date'] );
    $ovacrs_pickup_loc      = isset( $cart_item['ovacrs_pickup_loc'] ) ? $cart_item['ovacrs_pickup_loc'] : '';
    $ovacrs_pickoff_loc     = isset( $cart_item['ovacrs_pickoff_loc'] ) ? $cart_item['ovacrs_pickoff_loc'] : '';
    $rent_time              = get_time_bew_2day( $ovacrs_pickup_date, $ovacrs_pickoff_date );

    if ( isset( $cart_item['rental_type'] ) && $cart_item['rental_type'] == 'period_time' ) {
        $line_total = floatval( $cart_item['period_price'] );
        $ovacrs_amount_insurance = get_post_meta( $product_id, 'ovacrs_amount_insurance', true );
        $line_total +=  floatval($ovacrs_amount_insurance);

        $cart_re        = $cart_item['resources'];
        $resource_id    = get_post_meta( $product_id, 'ovacrs_resource_id', true );
        $resource_price = get_post_meta( $product_id, 'ovacrs_resource_price', true );
        $resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );
        
        if ( $cart_re ) {
            foreach( $cart_re as $key_c_re => $value_c_re ) {
                foreach( $resource_id as $key_id => $value_id ) {
                    if ( $key_c_re ==  $value_id ) {
                        if ( $resource_duration_type[$key_id] == 'total' ) {
                            $line_total = $line_total + $resource_price[$key_id];
                        } elseif( $resource_duration_type[$key_id] == 'days' ) {
                            $line_total = $line_total + $resource_price[$key_id] * $quantity;
                        } elseif ( $resource_duration_type[$key_id] == 'hours' ){
                            if ( $rent_time['rent_time_day_raw'] < 1 ) {
                                $line_total = $line_total + $resource_price[$key_id] * $quantity;
                            } else {
                                $line_total = $line_total + $resource_price[$key_id] * $quantity*24;
                            }
                        }
                    }
                }
            }
        }
    } else {
        if ( $ovacrs_rental_type === 'transportation' ) {
            $get_price_by_date = ovacrs_get_total_price_by_start_date_transport( $product_id, $ovacrs_pickup_loc, $ovacrs_pickoff_loc, $cart_item );
        } else {
           $get_price_by_date = get_price_by_date( $product_id, $ovacrs_pickup_date, $ovacrs_pickoff_date ); 
        }

        $quantity   = $get_price_by_date['quantity'];
        $line_total = $get_price_by_date['line_total'];
        
        $ovacrs_amount_insurance = get_post_meta( $product_id, 'ovacrs_amount_insurance', true );
        $line_total +=  floatval($ovacrs_amount_insurance);

        /* Price = Price + Resource Price - by Resource ********************************************/
        $cart_re        = $cart_item['resources'];
        $resource_id    = get_post_meta( $product_id, 'ovacrs_resource_id', true );
        $resource_price = get_post_meta( $product_id, 'ovacrs_resource_price', true );
        $resource_duration_type = get_post_meta( $product_id, 'ovacrs_resource_duration_type', true );

        if ( $cart_re ) {
            foreach( $cart_re as $key_c_re => $value_c_re ) {
                foreach( $resource_id as $key_id => $value_id ) {
                    if ( $key_c_re ==  $value_id ) {
                        if ( $resource_duration_type[$key_id] == 'total' ) {
                            $line_total = $line_total + $resource_price[$key_id];
                        } elseif ( $resource_duration_type[$key_id] == 'days' ) {
                            $line_total = $line_total + $resource_price[$key_id] * $quantity;
                        } elseif(  $resource_duration_type[$key_id] == 'hours' ){
                            if ( $rent_time['rent_time_day_raw'] < 1 ) {
                                $line_total = $line_total + $resource_price[$key_id] * $quantity;
                            } else {
                                $line_total = $line_total + $resource_price[$key_id] * $quantity*24;
                            }
                        }
                    }
                }
            }
        }
    }

    $deposit_enable = get_post_meta ( $product_id, 'ovacrs_enable_deposit', true );
    $value_deposit  = get_post_meta ( $product_id, 'ovacrs_amount_deposit', true );
    $value_deposit  = ! empty( $value_deposit ) ? floatval( $value_deposit ) : 0;

    $deposit_type_deposit   = get_post_meta ( $product_id, 'ovacrs_type_deposit', true );
    $sub_remaining_amount   = 0;
    $sub_deposit_amount     = $line_total;

    if ( $deposit_enable === 'yes' ) {
        $has_deposit = true;

        if ( isset( $cart_item['ova_type_deposit'] ) && $cart_item['ova_type_deposit'] === 'full' ) {
            $sub_remaining_amount = 0;
            $sub_deposit_amount = $line_total;
        } elseif ( $cart_item['ova_type_deposit'] === 'deposit' ) {
            if ( $deposit_type_deposit === 'percent' ) {
                $sub_deposit_amount     = ( $line_total * $value_deposit ) / 100;
                $sub_remaining_amount   = $line_total - $sub_deposit_amount;
            } elseif ( $deposit_type_deposit === 'value' ) {
                $sub_deposit_amount     = $value_deposit;
                $sub_remaining_amount   = $line_total - $sub_deposit_amount;
            }
        }
    }

    $deposit_amount     += $sub_deposit_amount;
    $remaining_amount   += $sub_remaining_amount;

    $deposit_remaining_amount[0] = $deposit_amount;
    $deposit_remaining_amount[1] = $remaining_amount;

    return $deposit_remaining_amount;
}