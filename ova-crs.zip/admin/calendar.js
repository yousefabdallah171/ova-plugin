(function($){
	"use strict";
	$(document).ready(function(){

		var day_of_week_start = 1;
        if (typeof(dayOfWeekStart) != "undefined"){
            day_of_week_start = dayOfWeekStart;
        }

		if( typeof order_time != 'undefined' ){
		
			$('.ireca__product_calendar').each(function(){
				var that = $(this)[0];
				var nav = $(this).data('nav');
				var default_view = $(this).data('default_view');
				var more_text = $(this).data( 'more_text' );
				var event_background = $(this).data( 'event_background' );
				var text_color = $(this).data( 'text_color' );
				var cal_lang = $(this).data( 'lang' ).replace(/\s/g, '');

				/* Show/hide read more */
				var eventLimit = true;
				var view_eventLimit = 2;

				var show_read_more_date = $(this).data('show_read_more_date');

				if( show_read_more_date == 'hide_read_more_date' ){
					eventLimit = false;
					view_eventLimit = 0;
				}

				if ( default_view == 'month' ) {
					default_view = 'dayGridMonth';
				} else if ( default_view == 'agendaWeek' ) {
					default_view = 'timeGridWeek';
				} else if ( default_view == 'agendaDay' ) {
					default_view = 'timeGridDay';
				}

				var srcCalendar = new FullCalendar.Calendar( that, {
		            headerToolbar: {
		                left: 'prev,next,today',
						center: 'title',
						right: nav
		            },
		            initialView: default_view,
		            eventBackgroundColor: event_background,
		            eventTextColor: text_color,
		            eventDisplay: 'block',
		            displayEventTime : false,
		            events: order_time,
		            firstDay: day_of_week_start,
		            moreLinkContent: more_text,
					showNonCurrentDates: true,
					locale: cal_lang,
					dayMaxEventRows: eventLimit,
					views: {
						dayGrid: {
		                    dayMaxEventRows: view_eventLimit
		                },
		                timeGrid: {
		                    dayMaxEventRows: view_eventLimit
		                },
		                week: {
		                    dayMaxEventRows: view_eventLimit
		                },
		                day: {
		                    dayMaxEventRows: view_eventLimit
		                }
					},
				});

				srcCalendar.render();
				
			});

		}
	});

}) (jQuery);