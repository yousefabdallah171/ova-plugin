<?php
if ( ! defined( 'ABSPATH' ) ) exit();

//check product no empty
$flag_product = true;
if( isset( $_POST['ovacrs_name_product'] ) && is_array( $_POST['ovacrs_name_product'] )  && ! empty( $_POST['ovacrs_name_product'] ) ) {
	foreach(  $_POST['ovacrs_name_product'] as $name_product ) {
		if( empty( $name_product ) ) {
			$flag_product = false;
		}
	}
} else {
	$flag_product = false;
}

if ( isset( $_POST['ovacrs_create_order'] ) && $_POST['ovacrs_create_order'] === 'create_order' && $flag_product ) {
	$ovacrs_first_name 	= isset( $_POST['ovacrs_first_name'] ) ? sanitize_text_field( $_POST['ovacrs_first_name'] ) : '';
	$ovacrs_last_name 	= isset( $_POST['ovacrs_last_name'] ) ? sanitize_text_field( $_POST['ovacrs_last_name'] ) : '';
	$ovacrs_company 	= isset( $_POST['ovacrs_company'] ) ? sanitize_text_field( $_POST['ovacrs_company'] ) : '';
	$ovacrs_email 		= isset( $_POST['ovacrs_email'] ) ? sanitize_text_field( $_POST['ovacrs_email'] ) : '';
	$ovacrs_phone 		= isset( $_POST['ovacrs_phone'] ) ? sanitize_text_field( $_POST['ovacrs_phone'] ) : '';
	$ovacrs_address_1 	= isset( $_POST['ovacrs_address_1'] ) ? sanitize_text_field( $_POST['ovacrs_address_1'] ) : '';
	$ovacrs_address_2 	= isset( $_POST['ovacrs_address_2'] ) ? sanitize_text_field( $_POST['ovacrs_address_2'] ) : '';
	$ovacrs_city 		= isset( $_POST['ovacrs_city'] ) ? sanitize_text_field( $_POST['ovacrs_city'] ) : '';
	$ovacrs_country 	= isset( $_POST['ovacrs_country'] ) ? sanitize_text_field( $_POST['ovacrs_country'] ) : '';

	global $woocommerce;

	$address = array(
		'first_name' => $ovacrs_first_name,
		'last_name'  => $ovacrs_last_name,
		'company'    => $ovacrs_company,
		'email'      => $ovacrs_email,
		'phone'      => $ovacrs_phone,
		'address_1'  => $ovacrs_address_1,
		'address_2'  => $ovacrs_address_2,
		'city'       => $ovacrs_city,
	);
	// Now we create the order
	$order = wc_create_order();

	// The add_product() function below is located in /plugins/woocommerce/includes/abstracts/abstract_wc_order.php
	$products = isset( $_POST['ovacrs_name_product'] ) ? $_POST['ovacrs_name_product'] : [];

	$total = 0;
	
	if ( !empty( $products ) ) {
		foreach( $products as $key => $product ) {
			$product 	= trim( sanitize_text_field( $product ) );
			$id_product = substr( $product, strpos( $product, '(#' ) );
			$id_product = str_replace('(#', '', $id_product);
			$id_product = str_replace(')', '', $id_product);
			$ovacrs_total_product = isset( $_POST['ovacrs_total_product'][$key] ) ? (float)$_POST['ovacrs_total_product'][$key] : "";

			if ( wc_prices_include_tax() && $ovacrs_total_product ) {
				$product_data 	= wc_get_product($id_product);
				$tax_rates_data = WC_Tax::get_rates( $product_data->get_tax_class() );
				$rate_data 		= reset($tax_rates_data);

				if ( $rate_data && isset( $rate_data['rate'] ) ) {
					$rate 		= $rate_data['rate'];
					$tax_rates 	= $ovacrs_total_product - ( $ovacrs_total_product / ( ( $rate / 100 ) + 1 ) );
					$ovacrs_total_product = $ovacrs_total_product - round( $tax_rates, 2 );
				}
			}

			$total += $ovacrs_total_product;
			
			$order->add_product( wc_get_product( $id_product ), 1, [ 'total' => $ovacrs_total_product ]);
		}
	}

	$order_item = $order->get_items();
	$i = 0;
	$total_remaining = $total_amount_insurance = 0;

	foreach( $order_item as $item_id => $product ) {
		$product_id 				= $product->get_product_id();
		$ovacrs_pickup_loc 			= isset( $_POST['ovacrs_pickup_loc'][$i] ) ? sanitize_text_field( $_POST['ovacrs_pickup_loc'][$i] ) : "";
		$ovacrs_pickoff_loc 		= isset( $_POST['ovacrs_pickoff_loc'][$i] ) ? sanitize_text_field( $_POST['ovacrs_pickoff_loc'][$i] ) : "";
		$ovacrs_pickup_date 		= isset( $_POST['ovacrs_pickup_date'][$i] ) ? sanitize_text_field( $_POST['ovacrs_pickup_date'][$i] ) : "";
		$ovacrs_pickoff_date 		= isset( $_POST['ovacrs_pickoff_date'][$i] ) ? sanitize_text_field( $_POST['ovacrs_pickoff_date'][$i] ) : "";
		$ovacrs_total_product 		= isset( $_POST['ovacrs_total_product'][$i] ) ? (float)$_POST['ovacrs_total_product'][$i] : 0;
		$ovacrs_rental_type 		= isset( $_POST['ovacrs_rental_type'][$i] ) ? sanitize_text_field( $_POST['ovacrs_rental_type'][$i] ) : "";
		$ovacrs_id_vehicle 			= isset( $_POST['ovacrs_id_vehicle'][$i] ) ? sanitize_text_field( $_POST['ovacrs_id_vehicle'][$i] ) : "";
		$ovacrs_quantity 			= isset( $_POST['ovacrs_quantity'][$i] ) ? sanitize_text_field( $_POST['ovacrs_quantity'][$i] ) : 0;
		$ovacrs_package 			= isset( $_POST['ovacrs_package'][$i] ) ? sanitize_text_field( $_POST['ovacrs_package'][$i] ) : "";
		$ovacrs_total_time 			= isset( $_POST['ovacrs_total_time'][$i] ) ? sanitize_text_field( $_POST['ovacrs_total_time'][$i] ) : "";
		$ovacrs_price_detail 		= isset( $_POST['ovacrs_price_detail'][$i] ) ? sanitize_text_field( $_POST['ovacrs_price_detail'][$i] ) : "";
		$ovacrs_resources 			= isset( $_POST['ovacrs_resource_checkboxs'][$product_id] ) ? $_POST['ovacrs_resource_checkboxs'][$product_id] : array();
		$ovacrs_amount_insurance 	= isset( $_POST['ovacrs_amount_insurance'][$i] ) ? (float)$_POST['ovacrs_amount_insurance'][$i] : 0;
		$manage_store 				= get_post_meta( $product_id, 'ovacrs_manage_store', true );

		$total = $total + $ovacrs_amount_insurance;
		$total *= absint( $ovacrs_quantity );
		
		$ovacrs_amount_deposite = ( isset( $_POST['ovacrs_amount_deposite'][$i] ) && ! empty( $_POST['ovacrs_amount_deposite'][$i] ) ) ? (float) $_POST['ovacrs_amount_deposite'][$i] : 0;

		$ovacrs_amount_remaining = $ovacrs_total_product - $ovacrs_amount_deposite;
		$total_remaining += $ovacrs_amount_remaining;

		$total_amount_insurance += floatval( $ovacrs_amount_insurance );

		if ( $ovacrs_rental_type == 'period_time' ) {
			wc_add_order_item_meta($item_id, 'period_label', $ovacrs_package, false);
			$ovacrs_unfixed 		= get_post_meta( $_POST['ovacrs_name_product'][$i], 'ovacrs_unfixed_time', true );
			$ovacrs_pickup_date 	= $ovacrs_unfixed == 'yes' ? $ovacrs_pickup_date : date( 'Y-m-d', strtotime( $ovacrs_pickup_date ) );
			$rental_time_period 	= get_rental_info_period( $_POST['ovacrs_name_product'][$i], $ovacrs_pickup_date, $ovacrs_rental_type, $ovacrs_package );
	        $ovacrs_pickup_date 	= $rental_time_period['start_time'];
	        $ovacrs_pickoff_date 	= $rental_time_period['end_time'];

	        if ( $rental_time_period['package_type'] == 'inday' ) {
	            $date_time_format = 'Y/m/d H:i';    
	        } else {
	            $date_time_format = 'Y/m/d';
	        }

	        $ovacrs_pickup_date 	= date( $date_time_format, $ovacrs_pickup_date );
	        $ovacrs_pickoff_date 	= date( $date_time_format, $ovacrs_pickoff_date );
		}

		wc_add_order_item_meta( $item_id, 'ovacrs_pickup_loc', $ovacrs_pickup_loc, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_pickoff_loc', $ovacrs_pickoff_loc, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_pickup_date', $ovacrs_pickup_date, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_pickoff_date', $ovacrs_pickoff_date, false );
		wc_add_order_item_meta( $item_id, 'rental_type', $ovacrs_rental_type, false );

		if ( $manage_store != 'store' ) {
			wc_add_order_item_meta( $item_id, 'id_vehicle', $ovacrs_id_vehicle, false );
		}

		wc_add_order_item_meta( $item_id, 'ovacrs_quantity', $ovacrs_quantity, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_price_detail', $ovacrs_price_detail, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_amount_insurance_product', $ovacrs_amount_insurance, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_deposit_amount_product', $ovacrs_amount_deposite, false );
		wc_add_order_item_meta( $item_id, 'ovacrs_remaining_amount_product', $ovacrs_amount_remaining, false );

		if ( !empty( $ovacrs_resources ) && is_array( $ovacrs_resources ) ) {
			foreach ( $ovacrs_resources as $rs_key => $rs_value ) {
                wc_add_order_item_meta( $item_id, 'Extra Resource', $rs_value );
            }
		}
		
		$i++;
	}

	$order->set_total($total);	
	$order->set_address( $address, 'billing' );
	$order->set_address( $address, 'shipping' );
	$order->update_meta_data( '_ova_remaining_amount', $total_remaining );
	$order->update_meta_data( '_ova_insurance_amount', $total_amount_insurance );
	$status_order = isset( $_POST['status_order'] ) ? sanitize_text_field( $_POST['status_order'] ) : '';
	$order->calculate_totals();

	if ( $status_order ) {
		$order->update_status( $status_order );
	}
}
  
// Display Manage Booking
function ovacrs_create_order() {
	// Datetimepicker language
	$language = get_theme_mod( 'calendar_layout', 'en' );

	// Disabled weekdays
	$disabled_weekdays = apply_filters( 'ovacrs_create_order_disable_weekend', get_theme_mod( 'calendar_dis_weekend', '0,6' ) );

	// Group times
	$group_times = get_theme_mod( 'calendar_time', '07:00, 07:30, 08:00, 08:30, 09:00, 09:30, 10:00, 10:30, 11:00, 11:30, 12:00, 12:30, 13:00, 13:30, 14:00, 14:30, 15:00, 15:30, 16:00, 16:30, 17:00, 17:30, 18:00' );

	// Default hour
	$default_hour = get_theme_mod( 'rd_bf_hour_default', '09:00' );

	// Time step
	$time_step = get_theme_mod( 'rd_bf_time_step', '30' );

	$args = array(
        'post_type'      	=> 'product',
        'fields' 			=> 'ids', 
        'posts_per_page' 	=> '-1',
        'tax_query' 		=> array(
	        array(
	            'taxonomy' => 'product_type',
	            'field'    => 'slug',
	            'terms'    => 'ovacrs_car_rental', 
	        ),
	    ),
    );

    $loop = new WP_Query( $args );

    $html_list_option_product = '<option value="">'.esc_html__("Select Product", "ova-crs" ).'</option>';

    while ( $loop->have_posts() ) : $loop->the_post();
        global $product;
        $html_list_option_product .= '<option value="'.get_the_id().'">'.get_the_title().'</option>';
    endwhile;

    wp_reset_query();
	?>
	<div class="wrap">
    <form id="booking-filter" method="POST" action="<?php echo admin_url('/edit.php?post_type=product&page=manage-booking'); ?>">
    	<h2><?php esc_html_e( 'Create Order', 'ova-crs' ); ?></h2>
    	<div class="ovacrs-wrap">
    		<div class="ovacrs-row">
    			<label for="stattus-order"><?php esc_html_e( 'Status', 'ova-crs' ) ?></label>
    			<select name="status_order" id="stattus-order">
    				<option value="completed" selected><?php esc_html_e( 'Completed', 'ova-crs' ) ?></option>
    				<option value="processing"><?php esc_html_e( 'Processing', 'ova-crs' ) ?></option>
    				<option value="pending"><?php esc_html_e( 'Pending payment', 'ova-crs' ) ?></option>
    				<option value="on-hold"><?php esc_html_e( 'On hold', 'ova-crs' ) ?></option>
    				<option value="cancelled"><?php esc_html_e( 'Cancelled', 'ova-crs' ) ?></option>
    				<option value="refunded"><?php esc_html_e( 'Refunded', 'ova-crs' ) ?></option>
    				<option value="failed"><?php esc_html_e( 'Failed', 'ova-crs' ) ?></option>
    			</select>
    		</div>
            <div class="ovacrs-row ova-column-3">
            	<div class="item">
            		<input type="text" name="ovacrs_first_name" placeholder="<?php esc_html_e( 'First Name', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_last_name" placeholder="<?php esc_html_e( 'Last Name', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_company" placeholder="<?php esc_html_e( 'Company', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="email" name="ovacrs_email" placeholder="<?php esc_html_e( 'Email', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_phone" placeholder="<?php esc_html_e( 'Phone', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_address_1" placeholder="<?php esc_html_e( 'Address 1', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_address_2" placeholder="<?php esc_html_e( 'Address 2', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_city" placeholder="<?php esc_html_e( 'City', 'ova-crs' ) ?>">
            	</div>
            	<div class="item">
            		<input type="text" name="ovacrs_country" placeholder="<?php esc_html_e( 'Country', 'ova-crs' ) ?>">
            	</div>
            </div>
            <div class="wrap_item">
            	<div class="ovacrs-order">
	            	<div class="item">
	            		<div class="sub-item">
	            			<h3 class="title"><?php esc_html_e('Product', 'ova-crs') ?></h3>
	            			<div class="rental_item">
	            				<label for="ovacrs-name-product"><?php esc_html_e( 'Name Product', 'ova-crs' ); ?></label>
	            				<select id="ovacrs-name-product" data-symbol="<?php echo get_woocommerce_currency_symbol() ?>" class="ovacrs_name_product" name="ovacrs_name_product[]" ><?php echo $html_list_option_product ?></select>
	            			</div>
	            		</div>
	            		<div class="sub-item ovabrw-meta">
	            			<h3 class="title"><?php esc_html_e('Add Meta', 'ova-crs') ?></h3>
							<div class="rental_item ovacrs-price-detial">
								<label for="ovacrs-price-detail"><?php esc_html_e( 'Price detail', 'ova-crs' ); ?></label>
								<input id="ovacrs-price-detail" type="text" name="ovacrs_price_detail[]" class="required ovacrs_price_detail" readonly />
							</div>
	            			<div class="rental_item">
								<label ><?php esc_html_e( 'Pick-up Location', 'ova-crs' ); ?></label>
								<?php echo ovacrs_get_locations_html( $name = 'ovacrs_pickup_loc[]', $required = 'required', $selected = '' ); ?>
							</div>
							<div class="rental_item">
								<label><?php esc_html_e( 'Drop-off Location', 'ova-crs' ); ?></label>
								<?php echo ovacrs_get_locations_html( $name = 'ovacrs_pickoff_loc[]', $required = 'required', $selected = '' ); ?>
							</div>
							<div class="rental_item">
								<label for="ovacrs-pickup-date"><?php esc_html_e( 'Pick-up Date *', 'ova-crs' ); ?></label>
								<input
									id="ovacrs-pickup-date"
									type="text"
									name="ovacrs_pickup_date[]"
									class="required ovacrs_start_date ovacrs_datetimepicker datetimepicker"
									placeholder="<?php echo esc_attr__( 'Y/m/d H:i', 'ova-crs' ); ?>"
									autocomplete="off"
									data-disabled-weekdays="<?php echo esc_attr( $disabled_weekdays ); ?>"
									data-group-times="<?php echo esc_attr( $group_times ); ?>"
									data-default-hour="<?php echo esc_attr( $default_hour ); ?>"
								/>
							</div>
							<div class="rental_item ovacrs-dropoff">
								<label><?php esc_html_e( 'Drop-off Date *', 'ova-crs' ); ?></label>
								<input
									type="text"
									name="ovacrs_pickoff_date[]"
									class="required ovacrs_end_date ovacrs_datetimepicker datetimepicker"
									placeholder="<?php echo esc_attr__( 'Y/m/d H:i', 'ova-crs' ); ?>"
									autocomplete="off"
									data-disabled-weekdays="<?php echo esc_attr( $disabled_weekdays ); ?>"
									data-group-times="<?php echo esc_attr( $group_times ); ?>"
									data-default-hour="<?php echo esc_attr( $default_hour ); ?>"
								/>
							</div>
							<div class="rental_item rental_type">
								<label for="ovacrs-rental-type"><?php esc_html_e( 'Rental Type', 'ova-crs' ); ?></label>
								<select id="ovacrs-rental-type" name="ovacrs_rental_type[]" >
									<option value="day"><?php esc_html_e( 'Day', 'ova-crs' ); ?></option>
									<option value="hour"><?php esc_html_e( 'Hour', 'ova-crs' ); ?></option>
									<option value="mixed"><?php esc_html_e( 'Mixed ', 'ova-crs' ); ?></option>
									<option value="period_time"><?php esc_html_e( 'Period of Time ', 'ova-crs' ); ?></option>
								</select>
							</div>
							<div class="rental_item ovacrs-package">
								<label for="ovacrs-package"><?php esc_html_e( 'Package', 'ova-crs' ); ?></label>
								<span class="ovacrs-package-span"></span>
							</div>
							<div class="rental_item ovacrs-id-vehicle">
								<label for="ovacrs-id-vehicle"><?php esc_html_e( 'ID Vehicle', 'ova-crs' ); ?></label>
								<span class="ovacrs-id-vehicle-span"></span>
							</div>
							<div class="rental_item ovacrs-qty">
								<label for="ovacrs-id-vehicle"><?php esc_html_e( 'Quantity', 'ova-crs' ); ?></label>
								<input id="ovacrs_quantity" type="number" name="ovacrs_quantity[]" class="required ovacrs_quantity" value="1" min="1" />
							</div>
							<div class="rental_item ovacrs-resources">
								<label for="ovacrs-resources"><?php esc_html_e( 'Extra Service', 'ova-crs' ); ?></label>
								<span class="ovacrs-resources-span"></span>
							</div>
							<div class="rental_item">
								<label for="ovacrs-amount-insurance"><?php esc_html_e( 'Amount of insurance', 'ova-crs' ); ?></label>
								<input id="ovacrs-amount-insurance" readonly type="text" name="ovacrs_amount_insurance[]" class="required ovacrs_amoun_insurance" placeholder="0" />
							</div>
							<div class="rental_item">
								<label for="ovacrs-amount-deposite"><?php esc_html_e( 'Deposit Amount', 'ova-crs' ); ?></label>
								<input id="ovacrs-amount-deposite" type="text" name="ovacrs_amount_deposite[]" class="required ovacrs_amoun_deposite" placeholder="0"  />
							</div>
							<div class="rental_item">
								<a href="javascript:void(0)" data-symbol="<?php echo get_woocommerce_currency_symbol() ?>" class="button view_total_cost"><?php esc_html_e( 'View total cost:', 'ova-crs' ) ?></a>
							</div>
							<div class="rental_item ovacrs-error">
								<span class="ovacrs-error-span"></span>
							</div>
							<div class="rental_item ovacrs-total-time">
								<label for="ovacrs-ovacrs-total-time"><?php esc_html_e( 'Total time', 'ova-crs' ); ?></label>
								<input id="ovacrs-ovacrs-total-time" type="text" name="ovacrs_total_time[]" class="required ovacrs_total_time"  />
							</div>
							<div class="rental_item ovacrs-total-cost">
	            				<label for="ovacrs-total-product"><?php esc_html_e( 'Cost', 'ova-crs' ); ?></label>
	            				<input id="ovacrs-total-product" type="text" name="ovacrs_total_product[]" class="required ovacrs_total_product"  />
	            			</div>
	            		</div>
	            	</div>
	            	<a href="#" class="delete_order">x</a>
	            </div>
            </div>
			<div class="ovacrs-row">
				<a href="#" class="button insert_wrap_item" data-row="
					<?php
						ob_start();
						?>
							<div class="ovacrs-order">
				            	<div class="item">
				            		<div class="sub-item">
				            			<h3 class="title"><?php esc_html_e('Product', 'ova-crs') ?></h3>
				            			<div class="rental_item">
				            				<label for="ovacrs-name-product"><?php esc_html_e( 'Name Product', 'ova-crs' ); ?></label>
				            				<select id="ovacrs-name-product" data-symbol="<?php echo get_woocommerce_currency_symbol() ?>" class="ovacrs_name_product" name="ovacrs_name_product[]" ><?php echo $html_list_option_product; ?></select>
				            			</div>
				            		</div>
				            		<div class="sub-item ovabrw-meta">
				            			<h3 class="title"><?php esc_html_e('Add Meta', 'ova-crs') ?></h3>
										<div class="rental_item ovacrs-price-detial">
											<label for="ovacrs-price-detail"><?php esc_html_e( 'Price detail', 'ova-crs' ); ?></label>
											<input id="ovacrs-price-detail" type="text" name="ovacrs_price_detail[]" class="required ovacrs_price_detail" readonly />
										</div>
				            			<div class="rental_item">
											<label ><?php esc_html_e( 'Pick-up Location', 'ova-crs' ); ?></label>
											<?php echo ovacrs_get_locations_html( $name = 'ovacrs_pickup_loc[]', $required = 'required', $selected = '' ); ?>
										</div>
										<div class="rental_item">
											<label><?php esc_html_e( 'Drop-off Location', 'ova-crs' ); ?></label>
											<?php echo ovacrs_get_locations_html( $name = 'ovacrs_pickoff_loc[]', $required = 'required', $selected = '' ); ?>
										</div>
										<div class="rental_item">
											<label for="ovacrs-pickup-date"><?php esc_html_e( 'Pick-up Date *', 'ova-crs' ); ?></label>
											<input
												id="ovacrs-pickup-date"
												type="text"
												name="ovacrs_pickup_date[]"
												class="required ovacrs_start_date ovacrs_datetimepicker datetimepicker"
												placeholder="<?php echo esc_attr__( 'Y/m/d H:i', 'ova-crs' ); ?>"
												autocomplete="off"
												data-disabled-weekdays="<?php echo esc_attr( $disabled_weekdays ); ?>"
												data-group-times="<?php echo esc_attr( $group_times ); ?>"
												data-default-hour="<?php echo esc_attr( $default_hour ); ?>"
											/>
										</div>
										<div class="rental_item ovacrs-dropoff">
											<label><?php esc_html_e( 'Drop-off Date *', 'ova-crs' ); ?></label>
											<input
												type="text"
												name="ovacrs_pickoff_date[]"
												class="required ovacrs_end_date ovacrs_datetimepicker datetimepicker"
												placeholder="<?php echo esc_attr__( 'Y/m/d H:i', 'ova-crs' ); ?>"
												autocomplete="off"
												data-disabled-weekdays="<?php echo esc_attr( $disabled_weekdays ); ?>"
												data-group-times="<?php echo esc_attr( $group_times ); ?>"
												data-default-hour="<?php echo esc_attr( $default_hour ); ?>"
											/>
										</div>
										<div class="rental_item rental_type">
											<label for="ovacrs-rental-type"><?php esc_html_e( 'Rental Type', 'ova-crs' ); ?></label>
											<select id="ovacrs-rental-type" name="ovacrs_rental_type[]" >
												<option value="day"><?php esc_html_e( 'Day', 'ova-crs' ); ?></option>
												<option value="hour"><?php esc_html_e( 'Hour', 'ova-crs' ); ?></option>
												<option value="mixed"><?php esc_html_e( 'Mixed ', 'ova-crs' ); ?></option>
												<option value="period_time"><?php esc_html_e( 'Period of Time ', 'ova-crs' ); ?></option>
											</select>
										</div>
										<div class="rental_item ovacrs-package">
											<label for="ovacrs-package"><?php esc_html_e( 'Package', 'ova-crs' ); ?></label>
											<span class="ovacrs-package-span"></span>
										</div>
										<div class="rental_item ovacrs-id-vehicle">
											<label for="ovacrs-id-vehicle"><?php esc_html_e( 'ID Vehicle', 'ova-crs' ); ?></label>
											<span class="ovacrs-id-vehicle-span"></span>
										</div>
										<div class="rental_item ovacrs-qty">
											<label for="ovacrs-id-vehicle"><?php esc_html_e( 'Quantity', 'ova-crs' ); ?></label>
											<input id="ovacrs_quantity" type="number" name="ovacrs_quantity[]" class="required ovacrs_quantity" value="1" min="1" />
										</div>
										<div class="rental_item ovacrs-resources">
											<label for="ovacrs-resources"><?php esc_html_e( 'Extra Service', 'ova-crs' ); ?></label>
											<span class="ovacrs-resources-span"></span>
										</div>
										<div class="rental_item">
											<label for="ovacrs-amount-insurance"><?php esc_html_e( 'Amount of insurance', 'ova-crs' ); ?></label>
											<input id="ovacrs-amount-insurance" type="text" name="ovacrs_amount_insurance[]" class="required ovacrs_amoun_insurance" placeholder="0"  />
										</div>
										<div class="rental_item">
											<label for="ovacrs-amount-deposite"><?php esc_html_e( 'Deposit Amount', 'ova-crs' ); ?></label>
											<input id="ovacrs-amount-deposite" type="text" name="ovacrs_amount_deposite[]" class="required ovacrs_amoun_deposite" placeholder="0"  />
										</div>
										<div class="rental_item">
											<a href="javascript:void(0)" data-symbol="<?php echo get_woocommerce_currency_symbol() ?>" class="button view_total_cost"><?php esc_html_e( 'View total cost:', 'ova-crs' ) ?></a>
										</div>
										<div class="rental_item ovacrs-error">
											<span class="ovacrs-error-span"></span>
										</div>
										<div class="rental_item ovacrs-total-time">
											<label for="ovacrs-ovacrs-total-time"><?php esc_html_e( 'Total time', 'ova-crs' ); ?></label>
											<input id="ovacrs-ovacrs-total-time" type="text" name="ovacrs_total_time[]" class="required ovacrs_total_time"  />
										</div>
										<div class="rental_item ovacrs-total-cost">
				            				<label for="ovacrs-total-product"><?php esc_html_e( 'Cost', 'ova-crs' ); ?></label>
				            				<input id="ovacrs-total-product" type="text" name="ovacrs_total_product[]" class="required ovacrs_total_product"  />
				            			</div>
				            		</div>
				            	</div>
				            	<a href="#" class="delete_order">x</a>
				            </div>
						<?php
						echo esc_attr( ob_get_clean() );
					?>
				">
				<?php esc_html_e( 'Add Item', 'ova-crs' ); ?></a>
				</a>
			</div>

			<!-- &nbsp;&nbsp;&nbsp; -->
			<button type="submit" class="button"><?php esc_html_e( 'Create Order', 'ova-crs' ); ?></button>

    	</div>
        <!-- For plugins, we also need to ensure that the form posts back to our current page -->
        <input type="hidden" name="post_type" value="product" />
        <input type="hidden" name="ovacrs_create_order" value="create_order" />
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
        <!-- Now we can render the completed list table -->
    </form>
</div>
<?php
}