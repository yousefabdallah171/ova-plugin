<?php if ( !defined( 'ABSPATH' ) ) exit();

if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class List_Booking extends WP_List_Table {

    function __construct(){

        global $page;

        
                
        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'bookings',     //singular name of the listed records
            'plural'    => 'bookings',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );
        
    }

    function column_default($item, $column_name){
        switch($column_name){
            case 'id':
            case 'customer':
            case 'check-in-check-out':
            case 'pickup-pickoff-loc':
            case 'status-deposit':
            case 'status-insurance':
            case 'room-code':
            case 'room-name':
            case 'order_status':
            case 'order_id':
                return $item[$column_name];
            default:
                return print_r($item,true); //Show the whole array for troubleshooting purposes
        }
    }

    function column_order_status($item){

        switch ($item['order_status']) {
            case 'processing':
                $order_status_text = esc_html__( 'Processing', 'ova-crs' );
                break;
            case 'completed':
                $order_status_text = esc_html__( 'Completed', 'ova-crs' );
                break;
            case 'on-hold':
                $order_status_text = esc_html__( 'On hold', 'ova-crs' );
                break;
            case 'cancelled':
                $order_status_text = esc_html__( 'Cancel', 'ova-crs' );
                break;            
            case 'closed':
                $order_status_text = esc_html__( 'Closed', 'ova-crs' );
                break;
            default:
                $order_status_text = esc_html__( 'Update Order', 'ova-crs' );
                break;
        }
        
        //Build row actions
        $selected_action = sprintf( '<select ="update_order_status" class="update_order_status" data-order_id="'.$item['id'].'">
            <option value="">'.esc_html__( 'Update Status', 'ova-crs' ).'</option>
            <option value="wc-completed">'.esc_html__( 'Completed', 'ova-crs' ).'</option>
            <option value="wc-processing">'.esc_html__( 'Processing', 'ova-crs' ).'</option>
            <option value="wc-on-hold">'.esc_html__( 'On hold', 'ova-crs' ).'</option>
            <option value="wc-cancelled">'.esc_html__( 'Cancel', 'ova-crs' ).'</option>
            <option value="wc-closed">'.esc_html__( 'Closed', 'ova-crs' ).'</option>
        </select>' );

        return sprintf('<span>%1$s</span>%2$s',
            '<mark class="order-status status-'.$item['order_status'].' tips"><span>'.$order_status_text.'</span></mark>',
            $selected_action
        );
        
        
    }

    function column_id($item){
    	//Build row actions
        
    	return sprintf('<span>%1$s</span>',
            '<a target="_blank" href="'.home_url('/').'wp-admin/post.php?post='.$item['id'].'&action=edit">'.$item['id'].'</a>'
        );
    }

    

    

    function get_columns(){
        $columns = array(
            'id'     	=> __( 'Order ID','ova-crs' ),
            'customer'  => __( 'Customer','ova-crs' ),
            'check-in-check-out'	=> __( 'Check-in - Check-out','ova-crs' ),
            'pickup-pickoff-loc'  => __( 'Pick-up, Drop-off Location','ova-crs' ),
            'status-deposit'  => __( 'Status Deposit','ova-crs' ),
            'status-insurance'	=> __( 'Status Insurance','ova-crs' ),
            'room-code' => __( 'ID Vehicle','ova-crs' ),
            'room-name'	=> __( 'Vehicle','ova-crs' ),
            'order_status'    => __( 'Order Status','ova-crs' ),
          
        );
        return $columns;
    }

    function get_sortable_columns() {
        $sortable_columns = array(
            'id'    		=> array('id',true),
            'customer' 		=> array('customer',false),
            'check-in-check-out'     	=> array('check-in-check-out',false),  //true means it's already sorted
            'pickup-pickoff-loc'      => array('pickup-pickoff-loc',false),  //true means it's already sorted
            'status-deposit'      => array('status-deposit',false),  
            'status-insurance'		=> array('status-insurance',false),  
            'room-code'     => array('room-code',false),  //true means it's already sorted
            'room-name'		=> array('room-name',false),  //true means it's already sorted
            'order_status'  		=> array('order_status',false),
            
        );
        return $sortable_columns;
    }

    function pagination( $which ) {
        if ( empty( $this->_pagination_args ) ) {
            return;
        }

        $parameters     = array();
        $fields_data    = $_REQUEST;

        // check_in_out
        if ( isset( $fields_data['check_in_out'] ) && $fields_data['check_in_out'] ) {
            $parameters['check_in_out'] = $fields_data['check_in_out'];
        }

        // from_day
        if ( isset( $fields_data['from_day'] ) && $fields_data['from_day'] ) {
            $parameters['from_day'] = $fields_data['from_day'];
        }

        // to_day
        if ( isset( $fields_data['to_day'] ) && $fields_data['to_day'] ) {
            $parameters['to_day'] = $fields_data['to_day'];
        }

        // room_code
        if ( isset( $fields_data['room_code'] ) && $fields_data['room_code'] ) {
            $parameters['room_code'] = $fields_data['room_code'];
        }

        // pickup_loc
        if ( isset( $fields_data['pickup_loc'] ) && $fields_data['pickup_loc'] ) {
            $parameters['pickup_loc'] = $fields_data['pickup_loc'];
        }

        // pickoff_loc
        if ( isset( $fields_data['pickoff_loc'] ) && $fields_data['pickoff_loc'] ) {
            $parameters['pickoff_loc'] = $fields_data['pickoff_loc'];
        }

        // room_id
        if ( isset( $fields_data['room_id'] ) && $fields_data['room_id'] ) {
            $parameters['room_id'] = $fields_data['room_id'];
        }

        // filter_order_status
        if ( isset( $fields_data['filter_order_status'] ) && $fields_data['filter_order_status'] ) {
            $parameters['filter_order_status'] = $fields_data['filter_order_status'];
        }

        $total_items     = $this->_pagination_args['total_items'];
        $total_pages     = $this->_pagination_args['total_pages'];
        $infinite_scroll = false;
        if ( isset( $this->_pagination_args['infinite_scroll'] ) ) {
            $infinite_scroll = $this->_pagination_args['infinite_scroll'];
        }

        if ( 'top' === $which && $total_pages > 1 ) {
            $this->screen->render_screen_reader_content( 'heading_pagination' );
        }

        $output = '<span class="displaying-num">' . sprintf(
            /* translators: %s: Number of items. */
            _n( '%s item', '%s items', $total_items ),
            number_format_i18n( $total_items )
        ) . '</span>';

        $current              = $this->get_pagenum();
        $removable_query_args = wp_removable_query_args();

        $current_url = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] );

        $current_url = remove_query_arg( $removable_query_args, $current_url );

        $page_links = array();

        $total_pages_before = '<span class="paging-input">';
        $total_pages_after  = '</span></span>';

        $disable_first = false;
        $disable_last  = false;
        $disable_prev  = false;
        $disable_next  = false;

        if ( 1 == $current ) {
            $disable_first = true;
            $disable_prev  = true;
        }
        if ( $total_pages == $current ) {
            $disable_last = true;
            $disable_next = true;
        }

        if ( $disable_first ) {
            $page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&laquo;</span>';
        } else {
            $page_links[] = sprintf(
                "<a class='first-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
                esc_url( remove_query_arg( 'paged', $current_url ) ),
                __( 'First page' ),
                '&laquo;'
            );
        }

        if ( $disable_prev ) {
            $page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&lsaquo;</span>';
        } else {
            $parameters['paged'] = max( 1, $current - 1 );
            $page_links[] = sprintf(
                "<a class='prev-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
                esc_url( add_query_arg( $parameters, $current_url ) ),
                __( 'Previous page' ),
                '&lsaquo;'
            );
        }

        if ( 'bottom' === $which ) {
            $html_current_page  = $current;
            $total_pages_before = '<span class="screen-reader-text">' . __( 'Current Page' ) . '</span><span id="table-paging" class="paging-input"><span class="tablenav-paging-text">';
        } else {
            $html_current_page = sprintf(
                "%s<input class='current-page' id='current-page-selector' type='text' name='paged' value='%s' size='%d' aria-describedby='table-paging' /><span class='tablenav-paging-text'>",
                '<label for="current-page-selector" class="screen-reader-text">' . __( 'Current Page' ) . '</label>',
                $current,
                strlen( $total_pages )
            );
        }
        $html_total_pages = sprintf( "<span class='total-pages'>%s</span>", number_format_i18n( $total_pages ) );
        $page_links[]     = $total_pages_before . sprintf(
            /* translators: 1: Current page, 2: Total pages. */
            _x( '%1$s of %2$s', 'paging' ),
            $html_current_page,
            $html_total_pages
        ) . $total_pages_after;

        if ( $disable_next ) {
            $page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&rsaquo;</span>';
        } else {
            $parameters['paged'] = min( $total_pages, $current + 1 );
            $page_links[] = sprintf(
                "<a class='next-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
                esc_url( add_query_arg( $parameters, $current_url ) ),
                __( 'Next page' ),
                '&rsaquo;'
            );
        }

        if ( $disable_last ) {
            $page_links[] = '<span class="tablenav-pages-navspan button disabled" aria-hidden="true">&raquo;</span>';
        } else {
            $parameters['paged'] = $total_pages;
            $page_links[] = sprintf(
                "<a class='last-page button' href='%s'><span class='screen-reader-text'>%s</span><span aria-hidden='true'>%s</span></a>",
                esc_url( add_query_arg( $parameters, $current_url ) ),
                __( 'Last page' ),
                '&raquo;'
            );
        }

        $pagination_links_class = 'pagination-links';
        if ( ! empty( $infinite_scroll ) ) {
            $pagination_links_class .= ' hide-if-js';
        }
        $output .= "\n<span class='$pagination_links_class'>" . implode( "\n", $page_links ) . '</span>';

        if ( $total_pages ) {
            $page_class = $total_pages < 2 ? ' one-page' : '';
        } else {
            $page_class = ' no-pages';
        }
        $this->_pagination = "<div class='tablenav-pages{$page_class}'>$output</div>";

        echo $this->_pagination;
    }

    function prepare_items() {
        global $wpdb; //This is used only if making any database queries

        /**
         * First, lets decide how many records per page to show
         */
        $per_page = '20';
        
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        
        $this->_column_headers = array($columns, $hidden, $sortable);
        
        // $this->process_bulk_action();

        $data = array();

        $filter_order_status =  isset( $_POST['filter_order_status'] ) ? $_POST['filter_order_status'] : '';
        if ( !$filter_order_status && isset( $_GET['filter_order_status'] ) && $_GET['filter_order_status'] ) {
            $filter_order_status = $_GET['filter_order_status'];
        }

        if ( $filter_order_status != '' ) {
            $order_status = array( $filter_order_status );
        } else {
            $order_status = array( 'wc-processing','wc-completed', 'wc-half-completed', 'wc-on-hold', 'wc-cancelled', 'wc-closed' );    
        }

        $room_id = isset( $_POST['room_id'] ) ? $_POST['room_id'] : '';
        if ( !$room_id && isset( $_GET['room_id'] ) && $_GET['room_id'] ) {
            $room_id = $_GET['room_id'];
        }

        if ( ovacrs_wc_custom_orders_table_enabled() ) {
            $room_query = $room_id ? 'AND oitem_meta.meta_value = '.$room_id : '';

            $result = $wpdb->get_col("
                SELECT DISTINCT o.id
                FROM {$wpdb->prefix}wc_orders AS o
                LEFT JOIN {$wpdb->prefix}woocommerce_order_items AS oitems
                ON o.id = oitems.order_id
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                ON oitems.order_item_id = oitem_meta.order_item_id
                WHERE oitems.order_item_type = 'line_item'
                AND oitem_meta.meta_key = '_product_id'
                AND o.status IN ( '" . implode( "','", $order_status ) . "' )
                $room_query
            ");
        } else {
            $room_query = $room_id ? 'AND oitem_meta.meta_value = '.$room_id : '';

            $result = $wpdb->get_col("
                SELECT DISTINCT oitems.order_id
                FROM {$wpdb->prefix}woocommerce_order_items AS oitems
                LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS oitem_meta
                ON oitems.order_item_id = oitem_meta.order_item_id
                LEFT JOIN {$wpdb->posts} AS posts ON oitems.order_id = posts.ID
                WHERE posts.post_type = 'shop_order'
                AND oitems.order_item_type = 'line_item'
                AND oitem_meta.meta_key = '_product_id'
                AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
                $room_query
            ");
        }

        $room_code_filter = isset( $_POST['room_code'] ) ? $_POST['room_code'] : '';
        if ( !$room_code_filter && isset( $_GET['room_code'] ) && $_GET['room_code'] ) {
            $room_code_filter = $_GET['room_code'];
        }

	    $from_day = isset( $_POST['from_day'] ) ? strtotime( $_POST['from_day'] ) : '';
        if ( !$from_day && isset( $_GET['from_day'] ) && $_GET['from_day'] ) {
            $from_day = strtotime( $_GET['from_day'] );
        }

    	$to_day = isset( $_POST['to_day'] ) ? strtotime( $_POST['to_day'] ) : '';
        if ( !$to_day && isset( $_GET['to_day'] ) && $_GET['to_day'] ) {
            $to_day = strtotime( $_GET['to_day'] );
        }
	    
	    $check_in_out = isset( $_POST['check_in_out'] ) ? $_POST['check_in_out'] : '';
        if ( !$check_in_out && isset( $_GET['check_in_out'] ) && $_GET['check_in_out'] ) {
            $check_in_out = $_GET['check_in_out'];
        }

        $check = $check_in_flag = $check_out_flag = $pickup_loc_flag = $pickoff_loc_flag = true;

        $current_pickup_loc = isset( $_POST['pickup_loc'] ) ? $_POST['pickup_loc'] : '';
        if ( !$current_pickup_loc && isset( $_GET['pickup_loc'] ) && $_GET['pickup_loc'] ) {
            $current_pickup_loc = $_GET['pickup_loc'];
        }

        $current_pickoff_loc = isset( $_POST['pickoff_loc'] ) ? $_POST['pickoff_loc'] : '';
        if ( !$current_pickoff_loc && isset( $_GET['pickoff_loc'] ) && $_GET['pickoff_loc'] ) {
            $current_pickoff_loc = $_GET['pickoff_loc'];
        }

	    foreach ($result as $key => $value) {

	        // Get Order Detail by Order ID
	        $order = wc_get_order($value);
	        

	        // Get Meta Data type line_item of Order
	        $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );

	        // For Meta Data
	        foreach ( $order_line_items as $item_id => $item ) {
                $room_check_in  = $room_check_out = $room_code = $pickup_loc = $pickoff_loc = '';
                $room_name      = $item->get_name();
                $product_id     = $item->get_product_id();
                $manage_store  = get_post_meta( $product_id, 'ovacrs_manage_store', true );

	            // Get value of check-in, check-out
                $room_check_in  = $item->get_meta( 'ovacrs_pickup_date' );
                $room_check_out = $item->get_meta( 'ovacrs_pickoff_date' );

                $room_code = '';

                if ( $manage_store === 'store' ) {
                    $room_code = $item->get_meta( 'ovacrs_quantity' );
                } else {
                    if ( $room_code_filter != '' && $room_code_filter == $meta->value ) {
                        $room_code = $item->get_meta( 'id_vehicle' );
                    } elseif ( $room_code_filter == '' ) {
                        $room_code = $item->get_meta( 'id_vehicle' );
                    }
                }

                $pickup_loc     = $item->get_meta( 'ovacrs_pickup_loc' );
                $pickoff_loc    = $item->get_meta( 'ovacrs_pickoff_loc' );

                $room_check_in_timep = strtotime( $room_check_in );
                $room_check_out_timep = strtotime( $room_check_out );

                if( $check_in_out == 'check_in' && $from_day != '' && $to_day != '' ){
                    $check = ( $from_day <=  $room_check_in_timep && $room_check_in_timep <= $to_day ) ? true : false;
                }else if( $check_in_out == 'check_out' ){
                    $check = ( $from_day <=  $room_check_out_timep &&  $room_check_out_timep <= $to_day ) ? true : false;
                }else if( $from_day != '' && $to_day != '' ){
                    $check_in_flag = ( $from_day <=  $room_check_in_timep && $room_check_in_timep <= $to_day ) ? true : false;
                    $check_out_flag = ( $from_day <=  $room_check_out_timep &&  $room_check_out_timep <= $to_day ) ? true : false;
                } else if ( $from_day != '' && $to_day == '' ) {
                    $check_in_flag = ( $from_day <=  $room_check_out_timep && $room_check_in_timep <= $from_day ) ? true : false;
                } else if ( $from_day == '' && $to_day != '' ) {
                    $check_out_flag = ( $to_day <=  $room_check_out_timep &&  $room_check_in_timep <= $to_day ) ? true : false;
                }

                if( $current_pickup_loc != '' && $pickup_loc != $current_pickup_loc ){
                    $pickup_loc_flag = false;
                }else{
                    $pickup_loc_flag = true;
                }

                if( $current_pickoff_loc != '' && $pickoff_loc != $current_pickoff_loc ){
                    $pickoff_loc_flag = false;
                }else{
                    $pickoff_loc_flag = true;
                }

                $order_amount_insurance = $item['ovacrs_amount_insurance_product'];
                if ($order_amount_insurance == 0) {
                    $status_insurance = '<span class="ova_amount_status_insurance_column ova_paid">'.esc_html__("Returned", "ova-crs").'</span>';
                } else {
                    $status_insurance = '<span class="ova_amount_status_insurance_column ova_pending">'.esc_html__("Deposited", "ova-crs").'</span>';
                }

                $order_amount_remaining = $item['ovacrs_remaining_amount_product'];

                if ( absint( $order_amount_remaining ) == 0 ) {
                    $status_deposit = '<span class="ova_amount_status_insurance_column ova_paid">'.esc_html__("Paid", "ova-crs").'</span>';
                } else {
                    $status_deposit = '<span class="ova_amount_status_insurance_column ova_pending">'.esc_html__("Pending Remaining", "ova-crs").'</span>';
                }

	            if ( $room_code && $check && $check_in_flag && $check_out_flag && $pickup_loc_flag && $pickoff_loc_flag ) {
	            	$data[] = array(
		                'id'            => $order->get_ID(),
		                'customer'     	=> $order->get_formatted_billing_full_name(),
		                'check-in-check-out'      => $room_check_in . ' @ ' . $room_check_out,
                        'pickup-pickoff-loc'      => $pickup_loc . ' @ ' . $pickoff_loc,
                        'status-deposit'      => $status_deposit,
                        'status-insurance'      => $status_insurance,
		                'room-code'		=> $room_code,
		                'room-name'		=> $room_name,
		                'order_status'   => $order->get_status(),
		                
		            );
	            }
	            
	            
	        }
	    }





        function usort_reorder($a,$b){
            $orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'id'; //If no sort, default to title
            $order = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'asc'; //If no order, default to asc
            $result = strcmp($a[$orderby], $b[$orderby]); //Determine sort order
            return ($order==='asc') ? -$result : $result; //Send final sort direction to usort
        }
        usort($data, 'usort_reorder');

        
        $current_page = $this->get_pagenum();
        
        $total_items = count($data);
        
       
        $data = array_slice($data,(($current_page-1)*$per_page),$per_page);
       
        $this->items = $data;
        
       
        $this->set_pagination_args( array(
            'total_items' => $total_items,                  //WE have to calculate the total number of items
            'per_page'    => $per_page,                     //WE have to determine how many items to show on a page
            'total_pages' => ceil($total_items/$per_page)   //WE have to calculate the total number of pages
        ) );
    }


}
