<?php
// Display Calendar Booking
function ovacrs_display_calendar_booking() {
    $all_rooms          = get_all_rooms();
    $all_vehicles       = ovacrs_get_all_id_vehicles();
    $current_product_id = isset( $_GET['product_id'] ) ? $_GET['product_id'] : '';

    // Get main color
    $main_color         = get_theme_mod('main_color', '#e9a31b');
    $event_background   = get_theme_mod('calendar_event_background', '#ceac61');
    $text_color         = get_theme_mod('calendar_text_color', '#ffffff');

    // Quantity
    $qty = 0;
    $manage_store = '';

    if ( $current_product_id ) {
        // Manager Store
        $manage_store = get_post_meta( $current_product_id, 'ovacrs_manage_store', true );
    }

    if ( $manage_store === 'store' ) {
        $qty = absint( get_post_meta( $current_product_id, 'ovacrs_stock_quantity', true ) );
    } else {
        $qty = absint( get_post_meta( $current_product_id, 'ovacrs_car_count', true ) );
    }

?>

<div class="wrap">
    <form id="booking-filter" method="GET" action="<?php echo admin_url('/edit.php?post_type=product&page=calendar-booking'); ?>">
    	<div class="booking_filter">
            <h2><?php esc_html_e( 'Calendar Booking', 'ova-crs' ); ?></h2>
    		<select name="product_id">
    			<option value="" <?php selected( '', $current_product_id, 'selected'); ?>><?php esc_html_e( '-- Choose Vehicle --', 'ova-crs' ); ?></option>
    			<?php 
    				if ( $all_rooms->have_posts() ) : while ( $all_rooms->have_posts() ) : $all_rooms->the_post(); ?>
    					<option value="<?php the_id(); ?>" <?php selected( get_the_id(), $current_product_id, 'selected'); ?>><?php the_title(); ?></option>
    				<?php endwhile;endif;wp_reset_postdata();
    			?>
    			
    		</select>
			<button type="submit" class="button"><?php esc_html_e( 'Display Calendar', 'ova-crs' ); ?></button>
            <h3>
                <?php esc_html_e( 'Total Vehicle ID','ova-crs' ); ?>:
                <?php echo esc_html( $qty ); ?>
            </h3>
    	</div>
        <!-- For plugins, we also need to ensure that the form posts back to our current page -->
        <input type="hidden" name="post_type" value="product" />
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />

        <?php
        if ( $current_product_id ) {

            // Get array ID when use WPML
            $post_id_array  = get_arr_product_ids( $current_product_id );
            $statuses       = ovacrs_order_status();
            $order_date     = get_order_rent_time( $post_id_array, $statuses );


            if ( $order_date ) {
                $script  = 'var order_time ='. $order_date .';';
                wp_add_inline_script('calendar_booking', $script, 'before');
            }

            $lang       = get_theme_mod( 'calendar_layout', 'en' ); 
            $nav_month  = get_theme_mod( 'rd_ca_nav_month', 'true' ) == 'true' ? 'dayGridMonth' : '';
            $nav_week   = get_theme_mod( 'rd_ca_nav_week', 'true' ) == 'true' ? 'timeGridWeek' : '';
            $nav_day    = get_theme_mod( 'rd_ca_nav_day', 'true' ) == 'true' ? 'timeGridDay' : '';
            $nav_list   = get_theme_mod( 'rd_ca_nav_list', 'true' ) == 'true' ? 'listWeek' : '';
            $nav        =  $nav_month.','.$nav_week.','.$nav_day.','.$nav_list;

            $default_view = ( get_theme_mod( 'rd_ca_default_view', 'dayGridMonth' ) != '' ) ? get_theme_mod( 'rd_ca_default_view', 'dayGridMonth' ) : 'dayGridMonth';

            $rd_ca_show_read_more_date = get_theme_mod( 'rd_ca_show_read_more_date', 'yes' ) == 'yes' ? 'show_read_more_date' : 'hide_read_more_date';

            ?>

            <div id="calendar" class="<?php echo 'ireca__product_calendar '.$rd_ca_show_read_more_date; ?>"  data-lang="<?php echo esc_attr( $lang ); ?>" data-nav="<?php echo esc_attr( $nav ); ?>" data-default_view="<?php echo esc_attr( $default_view ); ?>" data-more_text="<?php esc_html_e( 'more', 'ova-crs' ); ?>" data-show_read_more_date="<?php echo $rd_ca_show_read_more_date; ?>" data-event_background="<?php echo esc_attr( $event_background ); ?>" data-text_color="<?php echo esc_attr( $text_color ); ?>">
            
                <ul class="intruction">
                    <li>
                        <span class="pink"></span>
                        <span class="white"></span>
                        <span><?php esc_html_e( 'Available','ova-crs' ) ?></span>     
                    </li>
                    <li>
                        <span class="yellow" style="background-color:<?php echo $main_color; ?>;"></span>
                        <span><?php esc_html_e( 'Rent full day: No . Rent Hour: Yes','ova-crs' ) ?></span>        
                    </li>
                </ul>
            </div>
        <?php } ?>
    </form>
    <br>
    <hr>
    <br>

    <!-- Find Vehicle ID -->
    <form id="available-vehicle" method="GET" action="<?php echo admin_url('/edit.php?post_type=product&page=calendar-booking'); ?>" >
        <?php 
            $product_id = isset( $_GET['product_id'] ) ? $_GET['product_id'] : ''; 

            // Get array ID when use WPML
            $post_id_array = get_arr_product_ids( $product_id );
            
            $from_day   = isset( $_GET['from_day'] ) ? $_GET['from_day'] : '';
            $to_day     = isset( $_GET['to_day'] ) ? $_GET['to_day'] : '';
            
            $from_day_totime    = strtotime( $from_day );
            $to_day_totime      = strtotime( $to_day );

            $id_rented = $qty_vehicle_available = 0;
            $all_locations = get_all_locations();
            $current_pickup_loc = isset( $_GET['pickup_loc'] ) ? $_GET['pickup_loc'] : '';
            $id_vehicle_available = $vehicles_available = array();

            $total_car_store = get_post_meta( $product_id, 'ovacrs_car_count', true );
            // Check Price Type
            $price_type = get_post_meta( $product_id, 'ovacrs_price_type', true );
            // Rent day min
            $ovacrs_rent_day_min = (int)get_post_meta( $product_id, 'ovacrs_rent_day_min', true );

            // Rent hour min
            $ovacrs_rent_hour_min = (int)get_post_meta( $product_id, 'ovacrs_rent_hour_min', true );

            $cart_vehicle_rented_array = $store_vehicle_rented_array = array();

            // Compare Rent Day with database
            // Set the orders statuses
            $statuses   = ovacrs_order_status();
            $orders_ids = ovacrs_get_orders_ids_by_product_id( $post_id_array, $statuses );

            // For Order ID
            foreach( $orders_ids as $key => $value ) {
                
                // Get Order Detail by Order ID
                $order = wc_get_order($value);

                // Get Meta Data type line_item of Order
                $order_line_items = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
                

                // For Meta Data
                foreach ( $order_line_items as $item_id => $item ) {
                    
                    $ovacrs_pickup_date_store = $ovacrs_pickoff_date_store = $id_vehicle_rented = '';
                    $qty_rented_item = 0;

                    // Check Line Item have item ID is Car_ID
                    if( in_array( $item->get_product_id(), $post_id_array ) ){

                        // Check time to Prepare before delivered
                        $prepare_time = get_post_meta( $product_id, 'ovacrs_prepare_vehicle', true ) ? get_post_meta( $product_id, 'ovacrs_prepare_vehicle', true ) * 60 : 0;

                        // Get value of pickup date, pickoff date
                        $ovacrs_pickup_date_store   = strtotime( $item->get_meta( 'ovacrs_pickup_date' ) );
                        $ovacrs_pickoff_date_store  = strtotime( $item->get_meta( 'ovacrs_pickoff_date' ) ) + $prepare_time;

                        if ( $manage_store === 'store' ) {
                            $qty_rented_item = absint( $item->get_meta( 'ovacrs_quantity' ) );
                        } else {
                            $id_vehicle_rented = trim( $item->get_meta( 'id_vehicle' ) );
                        }

                        // Only compare date when "PickOff Date in Store" > "Current Time" becaue "PickOff Date Rent" have to > "Current Time"
                        if ( $ovacrs_pickoff_date_store >= current_time( 'timestamp' ) ){
                            if ( ! ( $to_day_totime <= $ovacrs_pickup_date_store || $ovacrs_pickoff_date_store <= $from_day_totime ) ) {
                                if ( $manage_store === 'store' ) {
                                    $id_rented += $qty_rented_item;
                                } else {
                                    if ( $id_vehicle_rented != '' ) {
                                        if ( str_contains( $id_vehicle_rented ,',' ) ) {
                                            $store_vehicle_rented_array = array_merge( $store_vehicle_rented_array, explode( ',', $id_vehicle_rented ) );
                                        } else {
                                            array_push( $store_vehicle_rented_array, $id_vehicle_rented ); 
                                        }
                                    }
                                }
                            }
                        }
                    }
                } 
            }

            if ( $manage_store === 'store' ) {
                $qty_vehicle_available = absint( $qty ) - absint( $id_rented );
            } else {
                if ( $store_vehicle_rented_array != null ){
                    $store_vehicle_rented_array = array_unique( $store_vehicle_rented_array );
                    $id_rented = count( $store_vehicle_rented_array );    
                }
                
                if ( $id_rented < $total_car_store ) {
                    $ovacrs_id_vehicles     = is_array( get_post_meta( $product_id, 'ovacrs_id_vehicles', true ) ) ? get_post_meta( $product_id, 'ovacrs_id_vehicles', true ) : array();
                    $id_vehicle_available   = array_diff( $ovacrs_id_vehicles, $store_vehicle_rented_array );
                }

                if ( $current_pickup_loc ) {
                    foreach( $id_vehicle_available as $key => $value ) {
                        $vehicle_avai               = ovacrs_get_vehicle_loc_title($value);
                        $id_vehicle_untime_startday = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['startdate'] ) : '';
                        $id_vehicle_untime_enddate  = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['enddate'] ) : '';

                        // Location is ok
                        if ( $current_pickup_loc == $vehicle_avai['loc'] ) {

                            // Vehicle with Untime
                            if ( ! ( $to_day_totime < $id_vehicle_untime_startday || $id_vehicle_untime_enddate < $from_day_totime  ) && $id_vehicle_untime_startday != '' && $id_vehicle_untime_enddate != '' ){
                                $vehicle_avai_flag      = true;
                                $vehicle_untime_flag    = false;
                            } else {
                                array_push($vehicles_available, $vehicle_avai);
                            }
                        }
                    }
                } else {
                    foreach( $id_vehicle_available as $key => $value ) {
                        $vehicle_avai               = ovacrs_get_vehicle_loc_title($value);
                        $id_vehicle_untime_startday = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['startdate'] ) : '';
                        $id_vehicle_untime_enddate  = !empty( $vehicle_avai['untime'] ) ? strtotime( $vehicle_avai['untime']['enddate'] ) : '';
                        
                        // Vehicle with Untime
                        if ( ! ( $to_day_totime < $id_vehicle_untime_startday  ||  $id_vehicle_untime_enddate < $from_day_totime  ) && $id_vehicle_untime_startday != '' && $id_vehicle_untime_enddate != '' ) {
                            $vehicle_avai_flag = true;
                            $vehicle_untime_flag = false;
                        } else {
                            array_push($vehicles_available, $vehicle_avai);
                        }
                    }
                }
            }
        ?>
        <h3><?php esc_html_e( 'The Available ID Vehicle','ova-crs' ); ?></h3>
        <div class="booking_filter">
            <?php if ( $manage_store != 'store' ): ?>
            <select name="pickup_loc">
                <option value="" <?php selected( '', $current_pickup_loc, 'selected'); ?>><?php esc_html_e( '-- Pick-up Location --', 'ova-crs' ); ?></option>
                <?php 
                    if ( $all_locations->have_posts() ) : while ( $all_locations->have_posts() ) : $all_locations->the_post(); ?>
                        <option value="<?php the_title(); ?>" <?php selected( get_the_title(), $current_pickup_loc, 'selected'); ?>><?php the_title(); ?></option>
                    <?php endwhile;endif;wp_reset_postdata();
                ?>
            </select>
            <?php endif; ?>
            <input type="text" name="from_day" value="<?php echo $from_day ?>" placeholder="<?php esc_html_e('From day', 'ova-crs'); ?>" class="ovacrs_rt_startdate date_book" autocomplete="off"/>
            <?php esc_html_e('to','ova-crs'); ?>
            <input type="text" name="to_day" value="<?php echo $to_day ?>" placeholder="<?php esc_html_e('To day', 'ova-crs'); ?>" class="ovacrs_rt_enddate date_book" autocomplete="off" />
            <select name="product_id">
                <option value="" <?php selected( '', $product_id, 'selected'); ?>><?php esc_html_e( '-- Choose Vehicle --', 'ova-crs' ); ?></option>
                <?php 
                    if ( $all_rooms->have_posts() ) : while ( $all_rooms->have_posts() ) : $all_rooms->the_post(); ?>
                        <option value="<?php the_id(); ?>" <?php selected( get_the_id(), $product_id, 'selected'); ?>><?php the_title(); ?></option>
                    <?php endwhile;endif;wp_reset_postdata();
                ?>
            </select>
            <button type="submit" class="button"><?php esc_html_e( 'Find ID Vehicle', 'ova-crs' ); ?></button>
            <br/><br/>
            <?php if ( $vehicles_available ) { ?>
            <table>
                <thead>
                    <tr>
                        <td> <strong> <?php esc_html_e( 'Vehicle Name', 'ova-crs' ); ?></strong></td>
                        <td><strong><?php esc_html_e( 'Vehicle ID', 'ova-crs' ); ?></strong></td>
                        <td><strong><?php esc_html_e( 'Pick-up Location', 'ova-crs' ); ?></strong></td>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vehicles_available as $key => $value) { ?>
                        <tr>
                        <td><?php echo $value['title'] ?></td>
                        <td><?php echo $value['id_vehicle'] ?></td>
                        <td><?php echo $value['loc'] ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <?php } elseif ( $qty_vehicle_available && $qty_vehicle_available > 0 ) { ?>
                <?php echo sprintf( esc_html__( 'Available vehicle is: %s', 'ova-crs'  ), $qty_vehicle_available ); ?>
            <?php } else { esc_html_e( 'Not Found ID Vehicle','ova-crs' ); } ?>
        </div>
        <!-- For plugins, we also need to ensure that the form posts back to our current page -->
        <input type="hidden" name="post_type" value="product" />
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
    </form>
</div>
<?php }