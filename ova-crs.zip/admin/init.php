<?php if ( !defined( 'ABSPATH' ) ) exit();


// Add Css in admin
// add_action( 'admin_print_styles', 'load_custom_admin_css' );
add_action( 'admin_footer', 'ova_crs_add_scripts', 10, 2 );
add_action('admin_enqueue_scripts', 'ovacrs_enqueue_calendar_scripts');


function ova_crs_add_scripts(){

    wp_enqueue_style( 'ovacrs_woo_admin', plugins_url().'/woocommerce/assets/css/admin.css');
    wp_enqueue_style( 'ovacrs_booking_admin', OVACRS_PLUGIN_URI.'admin/admin-style.css');

    wp_enqueue_script('admin_script', OVACRS_PLUGIN_URI.'admin/admin_script.js', array('jquery'),false,true);
    wp_localize_script( 'admin_script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));

}

function ovacrs_enqueue_calendar_scripts(){
    
    wp_enqueue_script('moment', OVACRS_PLUGIN_URI.'admin/fullcalendar/moment.min.js', array('jquery'),null,true);
    wp_enqueue_script('fullcalendar', OVACRS_PLUGIN_URI.'admin/fullcalendar/main.js', array('jquery'),null,true);
    wp_enqueue_script('locale-all', OVACRS_PLUGIN_URI.'admin/fullcalendar/locales-all.js', array('jquery'),null,true);
    wp_enqueue_style('fullcalendar', OVACRS_PLUGIN_URI.'admin/fullcalendar/main.min.css', array(), null);

    wp_enqueue_script('calendar_booking', OVACRS_PLUGIN_URI.'admin/calendar.js', array('jquery'), false, true );
}



function get_all_rooms(){
    $args = array(
        'post_type'         => 'product',
        'posts_per_page'    => '-1',
        'post_status'       => 'publish',
        'tax_query'         => array(
            array(
                'taxonomy' => 'product_type',
                'field'    => 'slug',
                'terms'    => 'ovacrs_car_rental', 
            ),
        )
    );

    $rooms = new WP_Query( $args );

    return $rooms;
}


function get_all_locations(){
	$args = array(
        'post_type' => 'location',
        'posts_per_page' => '-1',
        'post_status'   => 'publish'
    );
    $location = new WP_Query( $args );
    return $location;	
}

require_once( OVACRS_PLUGIN_PATH.'/admin/class_render_table_booking.php' );
require_once( OVACRS_PLUGIN_PATH.'/admin/class_admin_ajax.php' );
require_once( OVACRS_PLUGIN_PATH.'/admin/class_display_table_booking.php' );

require_once( OVACRS_PLUGIN_PATH.'/admin/class_display_calendar_booking.php' );
require_once( OVACRS_PLUGIN_PATH.'/admin/class_display_create_order.php' );
require_once( OVACRS_PLUGIN_PATH.'/admin/ovacrs_display_custom_checkout_field.php' );




// Create Sub-Menu-Page in Woo
add_action('admin_menu', 'ovacrs_schedule_menu');
function ovacrs_schedule_menu() {
	add_submenu_page(
	    'edit.php?post_type=product',
	    __( 'Manage Booking', 'ova-crs' ),
	    __( 'Manage Booking', 'ova-crs' ),
	    'edit_posts',
	    'manage-booking',
	    'ovacrs_display_booking'
	);

    add_submenu_page(
        'edit.php?post_type=product',
        __( 'Calendar Booking', 'ova-crs' ),
        __( 'Calendar Booking', 'ova-crs' ),
        'edit_posts',
        'calendar-booking',
        'ovacrs_display_calendar_booking'
    );

    add_submenu_page(
        'edit.php?post_type=product',
        __( 'Create Order', 'ova-crs' ),
        __( 'Create Order', 'ova-crs' ),
        'edit_posts',
        'create-order',
        'ovacrs_create_order'
    );

    add_submenu_page(
        'edit.php?post_type=product',
        __( 'Custom Checkout Field', 'ova-crs' ),
        __( 'Custom Checkout Field', 'ova-crs' ),
        'edit_posts',
        'custom-checkout-field',
        'ovacrs_display_custom_checkout_field'
    );
}

